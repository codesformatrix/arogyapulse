/**
 * Small response helpers shared by every controller.
 *
 * @module controllers/respond
 */

import { etagFor, isFresh } from '../utils/etag.js';

/**
 * Send a JSON payload with an ETag, honouring If-None-Match.
 *
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {unknown} payload
 * @param {number} [status]
 * @returns {void}
 */
export function sendJson(req, res, payload, status = 200) {
  const etag = etagFor(payload);
  res.set('ETag', etag);
  if (isFresh(req.get('if-none-match'), etag)) {
    res.status(304).end();
    return;
  }
  res.status(status).json(payload);
}

/**
 * Shape a paginated repository page for the API.
 *
 * @param {{items: object[], total: number, limit: number, offset: number}} page
 * @param {object} [extra]
 * @returns {object}
 */
export function sendPage(page, extra = {}) {
  return {
    items: page.items,
    pagination: {
      total: page.total,
      limit: page.limit,
      offset: page.offset,
      hasMore: page.offset + page.items.length < page.total,
    },
    ...extra,
  };
}

/**
 * Envelope for AI responses so the UI can show the "basic mode" badge.
 *
 * @param {{data: object, mode: string, model: string}} result
 * @param {object} [extra]
 * @returns {object}
 */
export function aiEnvelope(result, extra = {}) {
  return {
    ...result.data,
    meta: { mode: result.mode, model: result.model, basicMode: result.mode !== 'gemini', ...extra },
  };
}
