/**
 * Supply-chain controllers: indents, transfers and referrals.
 *
 * @module controllers/supplyChainController
 */

import { asyncHandler } from '../middleware/asyncHandler.js';
import { NotFoundError } from '../utils/errors.js';
import { sendJson, sendPage } from './respond.js';
import {
  createIndent,
  createTransfer,
  transferSuggestions,
  transitionIndent,
  transitionTransfer,
} from '../services/supplyChainService.js';
import { createReferral, decideReferral, receivingFacilities } from '../services/referralService.js';

/** GET /api/indents */
export const listIndents = asyncHandler(async (req, res) => {
  const page = await req.repository.listIndents(
    { filters: { facilityId: req.query.facilityId, status: req.query.status } },
    { limit: req.query.limit, offset: req.query.offset },
  );
  sendJson(req, res, sendPage(page));
});

/** POST /api/indents */
export const indentCreate = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await createIndent(req.repository, { ...req.body, facilityId: req.facilityId }, req.actor),
    201,
  );
});

/** POST /api/indents/:id/status */
export const indentStatus = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await transitionIndent(req.repository, req.params.id, req.body.status, req.actor, req.body.note),
  );
});

/** GET /api/transfers */
export const listTransfers = asyncHandler(async (req, res) => {
  const page = await req.repository.listTransfers(
    { filters: { status: req.query.status } },
    { limit: req.query.limit, offset: req.query.offset },
  );
  sendJson(req, res, sendPage(page));
});

/** GET /api/transfers/suggestions */
export const transferSuggest = asyncHandler(async (req, res) => {
  const suggestions = await transferSuggestions(req.repository);
  sendJson(req, res, {
    surplusToDeficit: suggestions.surplusToDeficit,
    expiryRisk: suggestions.expiryRisk,
  });
});

/** POST /api/transfers */
export const transferCreate = asyncHandler(async (req, res) => {
  sendJson(req, res, await createTransfer(req.repository, req.body, req.actor), 201);
});

/** POST /api/transfers/:id/status */
export const transferStatus = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await transitionTransfer(req.repository, req.params.id, req.body.status, req.actor, req.body.note),
  );
});

/** GET /api/referrals */
export const listReferrals = asyncHandler(async (req, res) => {
  const page = await req.repository.listReferrals(
    { filters: { status: req.query.status, facilityId: req.facilityId } },
    { limit: req.query.limit, offset: req.query.offset },
  );
  sendJson(req, res, sendPage(page));
});

/** GET /api/referrals/options - CHCs with live bed availability. */
export const referralOptions = asyncHandler(async (req, res) => {
  sendJson(req, res, {
    facilities: await receivingFacilities(req.repository, req.query.excludeFacilityId),
  });
});

/** POST /api/referrals */
export const referralCreate = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    // fromFacilityId is the session facility, never a client-supplied value.
    await createReferral(req.repository, { ...req.body, fromFacilityId: req.facilityId }, req.actor),
    201,
  );
});

/** POST /api/referrals/:id/status */
export const referralStatus = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await decideReferral(req.repository, req.params.id, req.body, req.actor),
  );
});

/** GET /api/alerts */
export const listAlerts = asyncHandler(async (req, res) => {
  const page = await req.repository.listAlerts(
    { filters: { facilityId: req.query.facilityId } },
    { limit: req.query.limit, offset: req.query.offset },
  );
  sendJson(req, res, sendPage(page));
});

/** POST /api/alerts/:id/acknowledge */
export const acknowledgeAlert = asyncHandler(async (req, res) => {
  const alert = await req.repository.getAlert?.(req.params.id);
  const updated = await req.repository.updateAlert(req.params.id, {
    acknowledged: true,
    acknowledgedBy: req.actor.subject,
    acknowledgedAt: new Date().toISOString(),
  });
  if (!updated && !alert) throw new NotFoundError(`Alert not found: ${req.params.id}`);
  sendJson(req, res, updated ?? { id: req.params.id, acknowledged: true });
});
