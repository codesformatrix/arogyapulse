/**
 * Offline queue replay.
 *
 * A 2G-connected phone keeps its mutations in IndexedDB and replays them when
 * connectivity returns. Replay is deliberately conservative:
 *
 *   - only POST/PUT/PATCH/DELETE against an allowlist of paths is accepted;
 *   - each operation is replayed through the *real* route middleware stack, so
 *     validation, RBAC and audit logging behave exactly as they do online;
 *   - one bad operation never blocks the rest, and each result is reported
 *     individually so the client can drop or retry just that entry.
 *
 * @module controllers/offlineController
 */

import { asyncHandler } from '../middleware/asyncHandler.js';
import { sendJson } from './respond.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('offline.controller');

/** Paths a replayed operation may target. Anything else is rejected. */
const ALLOWED_PATHS = Object.freeze([
  '/api/stock/adjust',
  '/api/dispensing',
  '/api/tokens',
  '/api/beds',
  '/api/counters',
  '/api/attendance/check-in',
  '/api/attendance/check-out',
  '/api/indents',
]);

/**
 * Does a replayed path match the allowlist?
 *
 * @param {string} path
 * @returns {boolean}
 */
export function isAllowedReplayPath(path) {
  const clean = String(path ?? '').split('?')[0];
  return ALLOWED_PATHS.some((allowed) => clean === allowed || clean.startsWith(`${allowed}/`));
}

/**
 * POST /api/offline/replay
 *
 * @param {import('express').Router} router - The mounted API router, used to
 *   dispatch each replayed operation through the real middleware chain.
 * @returns {import('express').RequestHandler}
 */
export function replay(router) {
  return asyncHandler(async (req, res) => {
    const results = [];

    for (const operation of req.body.operations) {
      if (!isAllowedReplayPath(operation.path)) {
        results.push({ id: operation.id, ok: false, status: 403, code: 'PATH_NOT_REPLAYABLE' });
        continue;
      }

      const status = await dispatch(router, req, operation);
      results.push({ id: operation.id, ...status });
    }

    const succeeded = results.filter((entry) => entry.ok).length;
    log.info('Offline replay', {
      total: results.length,
      succeeded,
      failed: results.length - succeeded,
      actor: req.actor.subject,
    });

    sendJson(req, res, { results, succeeded, failed: results.length - succeeded });
  });
}

/**
 * Dispatch one replayed operation through the router and capture its status.
 *
 * @param {import('express').Router} router
 * @param {import('express').Request} original
 * @param {{method: string, path: string, body?: object}} operation
 * @returns {Promise<{ok: boolean, status: number, code?: string, message?: string}>}
 */
async function dispatch(router, original, operation) {
  return new Promise((resolve) => {
    const fakeRequest = Object.create(original, {
      method: { value: operation.method, enumerable: true },
      url: { value: operation.path, enumerable: true },
      originalUrl: { value: operation.path, enumerable: true },
      path: { value: operation.path.split('?')[0], enumerable: true },
      body: { value: operation.body ?? {}, enumerable: true, writable: true },
      query: { value: {}, enumerable: true, writable: true, configurable: true },
      params: { value: {}, enumerable: true, writable: true, configurable: true },
    });

    let settled = false;
    const fakeResponse = {
      headersSent: false,
      statusCode: 200,
      status(code) {
        this.statusCode = code;
        return this;
      },
      set() {
        return this;
      },
      setHeader() {
        return this;
      },
      json(payload) {
        finish(payload);
        return this;
      },
      end() {
        finish(null);
        return this;
      },
      send(payload) {
        finish(payload);
        return this;
      },
    };

    const finish = (payload) => {
      if (settled) return;
      settled = true;
      const code = fakeResponse.statusCode;
      resolve({
        ok: code >= 200 && code < 300,
        status: code,
        code: payload?.error?.code,
        message: payload?.error?.message,
      });
    };

    const next = (error) => {
      if (!error) return;
      finish({ error: { code: error.code ?? 'ERROR', message: error.message } });
    };

    try {
      router.handle(fakeRequest, fakeResponse, next);
    } catch (error) {
      finish({ error: { code: 'ERROR', message: error.message } });
    }
  });
}

export { ALLOWED_PATHS };
