/**
 * Facility, medicine, stock, queue, bed and attendance controllers.
 *
 * Each handler is thin: validate (done in the route), resolve scope (done by
 * RBAC middleware), call a service, shape the response.
 *
 * @module controllers/facilityController
 */

import { asyncHandler } from '../middleware/asyncHandler.js';
import { NotFoundError } from '../utils/errors.js';
import { sendJson, sendPage } from './respond.js';
import { inventoryView, adjustStock, recordDispensing, expiryWatch, autoIndent } from '../services/stockService.js';
import { queueState, issueToken, serveToken, setCounter, footfallReport, publicCrowding } from '../services/queueService.js';
import { bedAvailability, updateBed, upsertWard } from '../services/bedService.js';
import { attendanceBoard, checkIn, checkOut, recordLeave } from '../services/attendanceService.js';
import { facilityDashboard, districtDashboard } from '../services/dashboardService.js';

/** GET /api/facilities */
export const listFacilities = asyncHandler(async (req, res) => {
  const page = await req.repository.listFacilities({
    filters: req.query.type ? { type: req.query.type } : {},
    limit: req.query.limit,
    offset: req.query.offset,
  });
  const items = req.query.q
    ? page.items.filter((facility) =>
        `${facility.name} ${facility.block}`.toLowerCase().includes(req.query.q.toLowerCase()),
      )
    : page.items;
  sendJson(req, res, sendPage({ ...page, items }));
});

/** GET /api/facilities/:id */
export const getFacility = asyncHandler(async (req, res) => {
  const facility = await req.repository.getFacility(req.params.id);
  if (!facility) throw new NotFoundError(`Facility not found: ${req.params.id}`);
  sendJson(req, res, { facility });
});

/** GET /api/medicines */
export const listMedicines = asyncHandler(async (req, res) => {
  const page = await req.repository.listMedicines({
    limit: req.query.limit,
    offset: req.query.offset,
  });
  let items = page.items;
  if (req.query.category) items = items.filter((medicine) => medicine.category === req.query.category);
  if (req.query.coldChain !== undefined) {
    items = items.filter((medicine) => Boolean(medicine.coldChain) === req.query.coldChain);
  }
  if (req.query.q) {
    const needle = req.query.q.toLowerCase();
    items = items.filter(
      (medicine) =>
        medicine.name.toLowerCase().includes(needle) ||
        (medicine.nameHi ?? '').includes(req.query.q),
    );
  }
  sendJson(req, res, sendPage({ ...page, items }));
});

/** GET /api/stock?facilityId=... */
export const listStock = asyncHandler(async (req, res) => {
  // req.facilityId is the RBAC-resolved scope, not the raw query value.
  const lines = await inventoryView(req.repository, req.facilityId);
  let items = lines;
  if (req.query.status) items = items.filter((line) => line.status === req.query.status);
  if (req.query.q) {
    const needle = req.query.q.toLowerCase();
    items = items.filter(
      (line) =>
        line.medicineName.toLowerCase().includes(needle) ||
        line.medicineNameHi.includes(req.query.q),
    );
  }
  if (req.query.sort === 'name') items = [...items].sort((a, b) => a.medicineName.localeCompare(b.medicineName));
  if (req.query.sort === 'cover') {
    items = [...items].sort((a, b) => (a.daysOfCover ?? 9999) - (b.daysOfCover ?? 9999));
  }
  if (req.query.sort === 'expiry') {
    items = [...items].sort((a, b) => String(a.nextExpiry ?? '9999').localeCompare(String(b.nextExpiry ?? '9999')));
  }

  const start = req.query.offset;
  sendJson(req, res, {
    facilityId: req.facilityId,
    items: items.slice(start, start + req.query.limit),
    pagination: {
      total: items.length,
      limit: req.query.limit,
      offset: start,
      hasMore: start + req.query.limit < items.length,
    },
    counts: {
      RED: lines.filter((line) => line.status === 'RED').length,
      AMBER: lines.filter((line) => line.status === 'AMBER').length,
      EXPIRY_RISK: lines.filter((line) => line.status === 'EXPIRY_RISK').length,
      GREEN: lines.filter((line) => line.status === 'GREEN').length,
    },
  });
});

/** POST /api/stock/adjust */
export const stockAdjust = asyncHandler(async (req, res) => {
  const result = await adjustStock(
    req.repository,
    { ...req.body, facilityId: req.facilityId },
    req.actor,
  );
  if (result.forecast.reorderNeeded) {
    await autoIndent(req.repository, req.facilityId, { actor: req.actor });
  }
  sendJson(req, res, result, 201);
});

/** POST /api/dispensing */
export const dispensing = asyncHandler(async (req, res) => {
  const result = await recordDispensing(
    req.repository,
    { ...req.body, facilityId: req.facilityId },
    req.actor,
  );
  if (result.forecast.reorderNeeded) {
    await autoIndent(req.repository, req.facilityId, { actor: req.actor });
  }
  sendJson(req, res, result, 201);
});

/** GET /api/stock/expiry?facilityId=... */
export const expiry = asyncHandler(async (req, res) => {
  sendJson(req, res, {
    facilityId: req.facilityId,
    items: await expiryWatch(req.repository, req.facilityId),
  });
});

/** GET /api/dashboard/facility?facilityId=... */
export const facility = asyncHandler(async (req, res) => {
  sendJson(req, res, await facilityDashboard(req.repository, req.facilityId));
});

/** GET /api/dashboard/district */
export const district = asyncHandler(async (req, res) => {
  sendJson(req, res, await districtDashboard(req.repository));
});

/** GET /api/queue?facilityId=... */
export const queue = asyncHandler(async (req, res) => {
  sendJson(req, res, await queueState(req.repository, req.facilityId));
});

/** POST /api/tokens */
export const tokenIssue = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await issueToken(req.repository, req.facilityId, req.body.department, req.actor),
    201,
  );
});

/** GET /api/tokens?facilityId=... */
export const tokenList = asyncHandler(async (req, res) => {
  const page = await req.repository.listTokens(
    { facilityId: req.facilityId },
    { limit: req.query.limit, offset: req.query.offset },
  );
  sendJson(req, res, sendPage(page));
});

/** POST /api/tokens/:id/serve */
export const tokenServe = asyncHandler(async (req, res) => {
  sendJson(req, res, await serveToken(req.repository, req.params.id, req.body.counterId, req.actor));
});

/** POST /api/counters */
export const counterSet = asyncHandler(async (req, res) => {
  sendJson(req, res, await setCounter(req.repository, { ...req.body, facilityId: req.facilityId }, req.actor));
});

/** GET /api/footfall?facilityId=... */
export const footfall = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await footfallReport(req.repository, req.facilityId, { department: req.query.department }),
  );
});

/** GET /api/beds?facilityId=... */
export const beds = asyncHandler(async (req, res) => {
  sendJson(req, res, await bedAvailability(req.repository, req.facilityId));
});

/** POST /api/beds/:wardId/update */
export const bedUpdate = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await updateBed(req.repository, req.params.wardId, req.body, req.actor),
  );
});

/** PUT /api/wards/:id */
export const wardUpsert = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await upsertWard(req.repository, req.params.id, req.body, req.actor),
    201,
  );
});

/** GET /api/attendance?facilityId=... */
export const attendance = asyncHandler(async (req, res) => {
  sendJson(req, res, await attendanceBoard(req.repository, req.facilityId));
});

/** POST /api/attendance/check-in */
export const attendanceCheckIn = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await checkIn(req.repository, { ...req.body, facilityId: req.facilityId }, req.actor),
    201,
  );
});

/** POST /api/attendance/check-out */
export const attendanceCheckOut = asyncHandler(async (req, res) => {
  sendJson(
    req,
    res,
    await checkOut(req.repository, { ...req.body, facilityId: req.facilityId }, req.actor),
    201,
  );
});

/** POST /api/leaves */
export const leaveCreate = asyncHandler(async (req, res) => {
  sendJson(req, res, await recordLeave(req.repository, req.body, req.actor), 201);
});

/** GET /api/audit?facilityId=... */
export const audit = asyncHandler(async (req, res) => {
  const page = await req.repository.listAudit(
    { filters: { facilityId: req.facilityId, entityType: req.query.entityType } },
    { limit: req.query.limit, offset: req.query.offset },
  );
  sendJson(req, res, sendPage(page));
});

/** GET /api/public/crowding?facilityId=... */
export const publicCrowdingController = asyncHandler(async (req, res) => {
  sendJson(req, res, await publicCrowding(req.repository, req.query.facilityId));
});

/** GET /api/public/summary */
export const publicSummary = asyncHandler(async (req, res) => {
  const facilitiesPage = await req.repository.listFacilities({ limit: 100, offset: 0 });
  const items = [];
  for (const entry of facilitiesPage.items) {
    if (entry.type === 'DISTRICT_STORE') continue;
    const [bedView, board] = await Promise.all([
      bedAvailability(req.repository, entry.id),
      attendanceBoard(req.repository, entry.id),
    ]);
    items.push({
      facilityId: entry.id,
      name: entry.name,
      nameHi: entry.nameHi,
      type: entry.type,
      block: entry.block,
      address: entry.address,
      mapsUrl: entry.mapsUrl,
      doctorPresentToday: board.doctorPresentToday,
      doctorsPresent: board.summary.presentCount,
      beds: bedView.summary,
    });
  }
  sendJson(req, res, { facilities: items, lang: req.query.lang });
});
