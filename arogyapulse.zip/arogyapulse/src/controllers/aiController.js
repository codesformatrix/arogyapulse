/**
 * AI controllers.
 *
 * Every response carries `meta.mode` ('gemini' | 'basic' | 'guardrail') so the
 * UI can show a "basic mode" badge whenever the model path is unavailable.
 *
 * @module controllers/aiController
 */

import { asyncHandler } from '../middleware/asyncHandler.js';
import { NotFoundError } from '../utils/errors.js';
import { parseWith } from '../services/validate.js';
import { bedUpdateSchema, stockAdjustSchema } from '../validators/index.js';
import { aiEnvelope, sendJson } from './respond.js';
import { adjustStock, recordDispensing } from '../services/stockService.js';
import { issueToken } from '../services/queueService.js';
import { updateBed } from '../services/bedService.js';
import { facilityDashboard, districtDashboard } from '../services/dashboardService.js';
import {
  aiStatus,
  askQuestion,
  dailyBriefing,
  parseNlEntry,
  ruleBasedNlEntry,
} from '../services/geminiService.js';
import { invalidateFor } from '../utils/caches.js';

/** GET /api/ai/status */
export const status = asyncHandler(async (req, res) => {
  sendJson(req, res, aiStatus());
});

/**
 * POST /api/ai/nl-entry
 *
 * Parses a spoken-style note into a structured record. Nothing is saved here -
 * the user must confirm first.
 */
export const nlEntry = asyncHandler(async (req, res) => {
  const result = await parseNlEntry(req.repository, {
    text: req.body.text,
    facilityId: req.facilityId,
    language: req.body.language,
  });

  const preview = {
    intent: result.data.intent,
    confidence: result.data.confidence,
    medicineId: result.data.medicineHint,
    quantity: result.data.quantity,
    reason: result.data.reason,
    department: result.data.department,
    bedField: result.data.bedField,
    bedDelta: result.data.bedDelta,
    explanation: result.data.explanation,
  };

  if (preview.medicineId) {
    const medicine = await req.repository.getMedicine(preview.medicineId);
    preview.medicineName = medicine?.name ?? null;
    preview.medicineNameHi = medicine?.nameHi ?? null;
  }

  sendJson(
    req,
    res,
    aiEnvelope(result, { requiresConfirmation: true, preview, facilityId: req.facilityId }),
  );
});

/**
 * POST /api/ai/confirm
 *
 * Applies a previously previewed NL entry. The payload is re-validated against
 * the same zod schemas the form endpoints use, and the deterministic parser is
 * re-run server-side so a tampered client cannot claim a different intent.
 */
export const nlConfirm = asyncHandler(async (req, res) => {
  const entry = req.body;

  // Re-derive the intent from the original text when it was supplied, so the
  // client cannot escalate "dispense 10" into "receive 10000".
  if (entry.originalText) {
    const derived = ruleBasedNlEntry(entry.originalText);
    if (derived.intent !== 'UNKNOWN' && derived.intent !== entry.intent) {
      sendJson(req, res, {
        ok: false,
        reason: 'INTENT_MISMATCH',
        expected: derived.intent,
        received: entry.intent,
      });
      return;
    }
  }

  let result;

  switch (entry.intent) {
    case 'STOCK_ADJUSTMENT': {
      // Re-validate exactly as the form endpoint would, so a natural-language
      // entry can never bypass a rule the manual path enforces.
      const payload = parseWith(
        stockAdjustSchema,
        {
          facilityId: req.facilityId,
          medicineId: entry.medicineId,
          delta: entry.quantity,
          reason: entry.reason ?? 'OTHER',
          note: entry.originalText ?? 'Natural-language entry',
        },
        'ai.confirm.stockAdjust',
      );
      result = await adjustStock(req.repository, payload, req.actor);
      break;
    }

    case 'DISPENSING':
      result = await recordDispensing(
        req.repository,
        {
          facilityId: req.facilityId,
          medicineId: entry.medicineId,
          quantity: Math.abs(entry.quantity ?? 0),
        },
        req.actor,
      );
      break;

    case 'FOOTFALL':
      for (let index = 0; index < Math.min(Math.abs(entry.quantity ?? 0), 50); index += 1) {
        await issueToken(req.repository, req.facilityId, entry.department ?? 'OPD_GENERAL', req.actor);
      }
      result = { tokensIssued: Math.min(Math.abs(entry.quantity ?? 0), 50) };
      break;

    case 'BED_UPDATE': {
      const wards = await req.repository.listWards(req.facilityId);
      const ward = wards[0];
      if (!ward) throw new NotFoundError('This facility has no ward configured');
      const payload = parseWith(
        bedUpdateSchema,
        { field: entry.bedField ?? 'occupied', delta: entry.bedDelta ?? 1 },
        'ai.confirm.bedUpdate',
      );
      result = await updateBed(req.repository, ward.id, payload, req.actor);
      break;
    }

    default:
      sendJson(req, res, { ok: false, reason: 'UNKNOWN_INTENT' });
      return;
  }

  invalidateFor(req.facilityId);
  sendJson(req, res, { ok: true, intent: entry.intent, result }, 201);
});

/** POST /api/ai/briefing */
export const briefing = asyncHandler(async (req, res) => {
  const scope = req.body.scope;
  const dashboard =
    scope === 'district'
      ? await districtDashboard(req.repository)
      : await facilityDashboard(req.repository, req.body.facilityId ?? req.facilityId);

  const result = await dailyBriefing(dashboard, scope, req.body.language);
  sendJson(req, res, aiEnvelope(result, { scope }));
});

/** POST /api/ai/ask */
export const ask = asyncHandler(async (req, res) => {
  const snapshot = await facilityDashboard(
    req.repository,
    req.body.facilityId ?? req.facilityId ?? req.actor.facilityId,
  );
  if (!snapshot) throw new NotFoundError('Facility snapshot unavailable');

  const result = await askQuestion(
    snapshot,
    {
      question: req.body.question,
      facilityId: req.body.facilityId ?? req.facilityId,
      language: req.body.language,
    },
    req.actor.role,
  );
  sendJson(req, res, aiEnvelope(result));
});
