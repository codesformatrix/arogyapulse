/**
 * Auth controller: demo-mode role switching and session introspection.
 *
 * @module controllers/authController
 */

import config from '../config/env.js';
import { ROLES } from '../config/constants.js';
import { NotFoundError } from '../utils/errors.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { permissionsForRole } from '../middleware/rbac.js';
import { signDemoToken } from '../middleware/auth.js';
import { sendJson } from './respond.js';

/**
 * POST /api/auth/login - issue a signed demo session cookie.
 *
 * Only exists so a demo can switch roles in one tap. When Firebase Auth is
 * configured the real deployment uses ID tokens instead, and this route simply
 * reports that.
 */
export const login = asyncHandler(async (req, res) => {
  const { role, facilityId, displayName } = req.body;

  if (role !== ROLES.PUBLIC && role !== ROLES.DISTRICT_OFFICER) {
    const facility = await req.repository.getFacility(facilityId ?? '');
    if (!facility && role !== ROLES.PUBLIC) {
      throw new NotFoundError(`Facility not found: ${facilityId ?? '(none)'}`);
    }
  }

  const token = signDemoToken({
    role,
    facilityId: role === ROLES.DISTRICT_OFFICER || role === ROLES.PUBLIC ? facilityId ?? null : facilityId,
    displayName: displayName ?? role,
  });

  res.cookie(config.cookieName, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.cookieSecure || config.isProduction,
    maxAge: config.sessionTtlSeconds * 1000,
    path: '/',
  });

  sendJson(req, res, {
    role,
    facilityId: facilityId ?? null,
    displayName: displayName ?? role,
    permissions: permissionsForRole(role),
    demoMode: config.demoMode,
    firebaseAuth: config.firebaseAuthEnabled,
  });
});

/** POST /api/auth/logout */
export const logout = asyncHandler(async (req, res) => {
  res.clearCookie(config.cookieName, { path: '/' });
  sendJson(req, res, { ok: true });
});

/** GET /api/auth/me */
export const me = asyncHandler(async (req, res) => {
  const actor = req.actor;
  sendJson(req, res, {
    role: actor.role,
    facilityId: actor.facilityId,
    displayName: actor.displayName,
    source: actor.source,
    isPublic: actor.isPublic,
    permissions: permissionsForRole(actor.role),
    demoMode: config.demoMode,
    firebaseAuth: config.firebaseAuthEnabled,
    facilities:
      actor.role === ROLES.DISTRICT_OFFICER
        ? (await req.repository.listFacilities({ limit: 100, offset: 0 })).items.map((facility) => ({
            id: facility.id,
            name: facility.name,
            type: facility.type,
          }))
        : [],
  });
});
