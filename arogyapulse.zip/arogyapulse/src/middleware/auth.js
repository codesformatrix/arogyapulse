/**
 * Authentication.
 *
 * Two modes, selected by configuration:
 *
 *   FIREBASE_PROJECT_ID set  -> Firebase Auth. The client sends
 *                               `Authorization: Bearer <idToken>`; the token is
 *                               verified with the Admin SDK and the role is
 *                               read from the `role` / `facilityId` custom
 *                               claims.
 *   otherwise (DEMO_MODE)    -> a signed HS256 JWT in an httpOnly cookie,
 *                               issued by `POST /api/auth/login` so the
 *                               hackathon demo can switch roles in one tap.
 *
 * A Firebase ID token always wins over the demo cookie, so a real deployment
 * can never be downgraded to demo auth by simply presenting a cookie.
 *
 * @module middleware/auth
 */

import jwt from 'jsonwebtoken';

import config from '../config/env.js';
import { ROLES } from '../config/constants.js';
import { UnauthorizedError } from '../utils/errors.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('auth');

/** Roles that may appear on a token, in privilege order. */
const VALID_ROLES = Object.values(ROLES);

/** @type {{verifyIdToken: Function}|null} */
let firebaseAuth = null;
/** @type {boolean} */
let firebaseInitAttempted = false;

/**
 * Lazily initialise Firebase Auth. Failures are logged, never thrown: a broken
 * Firebase config must not take the whole service down.
 *
 * @returns {Promise<{verifyIdToken: Function}|null>}
 */
async function getFirebaseAuth() {
  if (firebaseInitAttempted) return firebaseAuth;
  firebaseInitAttempted = true;

  if (!config.firebaseAuthEnabled) return null;
  try {
    const admin = await import('firebase-admin/app');
    if (admin.getApps().length === 0) {
      admin.initializeApp({ projectId: config.googleCloudProject ?? undefined });
    }
    const { getAuth } = await import('firebase-admin/auth');
    firebaseAuth = getAuth();
    log.info('Firebase Auth enabled', { projectId: config.googleCloudProject });
  } catch (error) {
    log.error('Firebase Auth unavailable, falling back to demo auth', { error });
    firebaseAuth = null;
  }
  return firebaseAuth;
}

/**
 * @typedef {Object} Actor
 * @property {string} role
 * @property {string|null} facilityId
 * @property {string} subject - Stable user identifier (uid or demo subject).
 * @property {string} displayName
 * @property {'firebase'|'demo'} source
 * @property {boolean} isPublic
 */

/**
 * The anonymous actor used for unauthenticated reads.
 *
 * @type {Actor}
 */
export const PUBLIC_ACTOR = Object.freeze({
  role: ROLES.PUBLIC,
  facilityId: null,
  subject: 'anonymous',
  displayName: 'Guest',
  source: 'demo',
  isPublic: true,
});

/**
 * Extract a bearer token from the Authorization header.
 *
 * @param {import('express').Request} req
 * @returns {string|null}
 */
export function bearerToken(req) {
  const header = req.get('authorization') ?? '';
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  return match ? match[1].trim() : null;
}

/**
 * Sign a demo-mode session token.
 *
 * @param {object} claims
 * @param {string} claims.role
 * @param {string|null} [claims.facilityId]
 * @param {string} [claims.subject]
 * @param {string} [claims.displayName]
 * @param {number} [expiresInSeconds]
 * @returns {string} Signed JWT.
 */
export function signDemoToken(claims, expiresInSeconds = config.sessionTtlSeconds) {
  return jwt.sign(
    {
      sub: claims.subject ?? `demo:${claims.role}`,
      role: claims.role,
      facilityId: claims.facilityId ?? null,
      name: claims.displayName ?? claims.role,
      demo: true,
    },
    config.sessionSecret,
    { algorithm: 'HS256', expiresIn: expiresInSeconds, issuer: 'arogyapulse' },
  );
}

/**
 * Verify a demo-mode session token.
 *
 * @param {string} token
 * @returns {Actor}
 * @throws {UnauthorizedError}
 */
export function verifyDemoToken(token) {
  let payload;
  try {
    payload = jwt.verify(token, config.sessionSecret, {
      algorithms: ['HS256'],
      issuer: 'arogyapulse',
    });
  } catch {
    throw new UnauthorizedError('Session expired or invalid, please sign in again');
  }

  const role = VALID_ROLES.includes(payload.role) ? payload.role : ROLES.PUBLIC;
  return {
    role,
    facilityId: payload.facilityId ?? null,
    subject: String(payload.sub ?? 'demo'),
    displayName: String(payload.name ?? role),
    source: 'demo',
    isPublic: role === ROLES.PUBLIC,
  };
}

/**
 * Verify a Firebase ID token and map custom claims onto an Actor.
 *
 * @param {string} idToken
 * @returns {Promise<Actor>}
 * @throws {UnauthorizedError}
 */
export async function verifyFirebaseToken(idToken) {
  const auth = await getFirebaseAuth();
  if (!auth) throw new UnauthorizedError('Firebase Auth is not configured');

  let decoded;
  try {
    decoded = await auth.verifyIdToken(idToken, true);
  } catch {
    throw new UnauthorizedError('Firebase token rejected');
  }

  const claims = decoded ?? {};
  const role = VALID_ROLES.includes(claims.role) ? claims.role : ROLES.PUBLIC;
  return {
    role,
    facilityId: typeof claims.facilityId === 'string' ? claims.facilityId : null,
    subject: String(claims.uid ?? claims.sub ?? 'firebase'),
    displayName: String(claims.name ?? claims.email ?? role),
    source: 'firebase',
    isPublic: role === ROLES.PUBLIC,
  };
}

/**
 * Resolve the current actor. Never throws - an unauthenticated caller simply
 * becomes the public actor, and RBAC decides whether that is enough.
 *
 * @param {import('express').Request} req
 * @returns {Promise<Actor>}
 */
export async function resolveActor(req) {
  const token = bearerToken(req);

  if (token) {
    // A Firebase-shaped token is long and has three dot-separated segments.
    if (config.firebaseAuthEnabled && token.split('.').length === 3 && token.length > 200) {
      try {
        return await verifyFirebaseToken(token);
      } catch (error) {
        log.warn('Firebase token verification failed', { error });
      }
    }
    try {
      return verifyDemoToken(token);
    } catch {
      // fall through to cookie / public
    }
  }

  const cookie = req.cookies?.[config.cookieName];
  if (cookie) {
    try {
      return verifyDemoToken(cookie);
    } catch {
      // A credential was presented and rejected. Silently degrading to the
      // public actor would turn an expired session into "logged out but still
      // browsing", which is far more confusing than an honest 401.
      throw new UnauthorizedError('Your session has expired, please sign in again');
    }
  }

  // No credential at all: the request continues as the anonymous public actor.
  return PUBLIC_ACTOR;
}

/**
 * Express middleware: attach `req.actor`.
 *
 * @returns {import('express').RequestHandler}
 */
export function attachActor() {
  return async (req, _res, next) => {
    try {
      req.actor = await resolveActor(req);
      next();
    } catch (error) {
      next(error);
    }
  };
}

/**
 * Express middleware: require an authenticated (non-public) actor.
 *
 * @returns {import('express').RequestHandler}
 */
export function requireAuth() {
  return (req, _res, next) => {
    if (!req.actor || req.actor.isPublic) {
      next(new UnauthorizedError('Sign in to continue'));
      return;
    }
    next();
  };
}

/**
 * Reset cached Firebase state (used by tests).
 *
 * @returns {void}
 */
export function resetFirebaseAuth() {
  firebaseAuth = null;
  firebaseInitAttempted = false;
}

export default attachActor;
