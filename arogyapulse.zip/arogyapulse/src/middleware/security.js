/**
 * Security middleware: headers, CORS, rate limiting, request validation.
 *
 * @module middleware/security
 */

import cors from 'cors';
import helmet from 'helmet';
import rateLimit, { ipKeyGenerator } from 'express-rate-limit';

import config from '../config/env.js';
import { ValidationError } from '../utils/errors.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('security');

/**
 * Helmet with a strict Content-Security-Policy.
 *
 * The SPA is served from the same origin and uses inline SVG charts plus a
 * small amount of inline style for high-contrast mode, so `style-src` allows
 * `'unsafe-inline'` while `script-src` stays `'self'` - no inline scripts, no
 * third-party CDNs, nothing to exfiltrate to.
 *
 * @returns {import('express').RequestHandler}
 */
export function securityHeaders() {
  return helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        defaultSrc: ["'none'"],
        baseUri: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'https://www.google.com', 'https://maps.google.com'],
        fontSrc: ["'self'"],
        connectSrc: ["'self'"],
        formAction: ["'self'"],
        frameSrc: ["'none'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        manifestSrc: ["'self'"],
        workerSrc: ["'self'"],
      },
    },
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: { policy: 'same-origin' },
    referrerPolicy: { policy: 'no-referrer' },
    hsts: config.isProduction ? { maxAge: 31_536_000, includeSubDomains: true } : false,
  });
}

/**
 * CORS restricted to an explicit allowlist.
 *
 * With an empty allowlist (the default) the API is same-origin only, which is
 * exactly right for a PWA served by the same Cloud Run service.
 *
 * @returns {import('express').RequestHandler}
 */
export function corsPolicy() {
  const allowlist = config.corsOrigins;
  return cors({
    origin(origin, callback) {
      if (!origin || allowlist.includes(origin)) {
        callback(null, true);
        return;
      }
      log.warn('Blocked CORS origin', { origin });
      callback(new Error('Origin not allowed by CORS policy'));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'If-None-Match'],
    exposedHeaders: ['ETag'],
    maxAge: 600,
  });
}

/**
 * Rate limiter factory.
 *
 * Client identity comes from `x-forwarded-for` because Cloud Run terminates TLS
 * at its load balancer, so the socket address is always the proxy.
 *
 * @param {object} [options]
 * @param {number} [options.max]
 * @param {number} [options.windowMs]
 * @returns {import('express').RequestHandler}
 */
export function createRateLimiter(options = {}) {
  return rateLimit({
    windowMs: options.windowMs ?? config.rateLimit.windowMs,
    max: options.max ?? config.rateLimit.max,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    keyGenerator(request) {
      const forwarded = String(request.get('x-forwarded-for') ?? '').split(',')[0].trim();
      if (forwarded) return forwarded;
      // ipKeyGenerator normalises IPv6 so a client cannot rotate its suffix to
      // escape the limit.
      return ipKeyGenerator(request.ip, 64);
    },
    handler(_request, response) {
      response.status(429).json({
        error: { code: 'RATE_LIMITED', message: 'Too many requests, please try again shortly' },
      });
    },
  });
}

/** Stricter limiter for the AI routes (paid, slow, abusable). */
export const aiRateLimiter = createRateLimiter({ max: config.rateLimit.aiMax });

/** General limiter for the rest of the API. */
export const apiRateLimiter = createRateLimiter();

/**
 * Validate one part of the request against a zod schema and replace it with
 * the parsed (coerced, defaulted, stripped) value.
 *
 * @param {'body'|'query'|'params'} source
 * @param {import('zod').ZodType} schema
 * @param {string} [label]
 * @returns {import('express').RequestHandler}
 */
export function validate(source, schema, label) {
  return (req, _res, next) => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      next(
        new ValidationError(
          `Invalid ${label ?? source} payload`,
          result.error.issues.map((issue) => ({
            path: issue.path.join('.') || '(root)',
            message: issue.message,
            code: issue.code,
          })),
        ),
      );
      return;
    }

    if (source === 'query') {
      // Express 4 exposes `req.query` as a getter, so redefine it explicitly.
      Object.defineProperty(req, 'query', {
        value: result.data,
        writable: true,
        configurable: true,
        enumerable: true,
      });
    } else {
      req[source] = result.data;
    }
    next();
  };
}
