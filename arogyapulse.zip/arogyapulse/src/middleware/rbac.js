/**
 * Permission matrix and access-control helpers.
 *
 * Every mutating route declares a permission string; {@link requirePermission}
 * resolves it against the caller's role. Keeping the matrix in one file means
 * the whole trust model can be reviewed (and unit tested) in one screen.
 *
 * Roles, most to least privileged:
 *   district_officer - DHO / district drug store manager
 *   chc_admin        - CHC superintendent
 *   facility_staff   - pharmacist / ANM / nurse at a PHC
 *   public           - anonymous, read-only
 *
 * @module middleware/rbac
 */

import { ROLES } from '../config/constants.js';
import { ForbiddenError } from '../utils/errors.js';

/**
 * @typedef {Object} PermissionSpec
 * @property {string[]} roles - Roles allowed to perform the action.
 * @property {'own'|'any'} [scope] - `own` restricts staff to their own facility.
 */

/**
 * The complete permission matrix.
 *
 * @type {Record<string, PermissionSpec>}
 */
export const PERMISSIONS = Object.freeze({
  // ---- read surfaces
  'facility:read': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF, ROLES.PUBLIC] },
  'medicine:read': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF, ROLES.PUBLIC] },
  'stock:read': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF, ROLES.PUBLIC], scope: 'read' },
  'queue:read': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF, ROLES.PUBLIC], scope: 'read' },
  'bed:read': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF, ROLES.PUBLIC], scope: 'read' },
  'attendance:read': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF, ROLES.PUBLIC], scope: 'read' },
  'dashboard:read': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'read' },
  'district:read': { roles: [ROLES.DISTRICT_OFFICER] },
  'audit:read': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN], scope: 'read' },

  // ---- write surfaces
  'stock:adjust': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'stock:dispense': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'token:issue': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'token:serve': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'counter:manage': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'bed:update': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'ward:manage': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'attendance:record': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'leave:record': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN] },
  'referral:request': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'referral:decide': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN] },
  'indent:create': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'indent:approve': { roles: [ROLES.DISTRICT_OFFICER] },
  'transfer:create': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN] },
  'transfer:approve': { roles: [ROLES.DISTRICT_OFFICER] },
  'transfer:receive': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'alert:acknowledge': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN] },

  // ---- AI surfaces (rate limited separately)
  'ai:nlp': { roles: [ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF], scope: 'own' },
  'ai:briefing': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF] },
  'ai:ask': { roles: [ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF] },
});

/**
 * Look up a permission definition.
 *
 * @param {string} permission
 * @returns {PermissionSpec}
 * @throws {ForbiddenError} When the permission name is unknown - a typo in a
 *   route must fail closed, not open.
 */
export function permissionSpec(permission) {
  const spec = PERMISSIONS[permission];
  if (!spec) throw new ForbiddenError(`Unknown permission: ${permission}`);
  return spec;
}

/**
 * Can this role perform this permission?
 *
 * @param {string|null|undefined} role
 * @param {string} permission
 * @returns {boolean}
 */
export function can(role, permission) {
  if (!role) return false;
  const spec = PERMISSIONS[permission];
  if (!spec) return false;
  return spec.roles.includes(role);
}

/**
 * Does this permission restrict the caller to their own facility?
 *
 * @param {string} permission
 * @returns {boolean}
 */
export function isOwnScoped(permission) {
  return PERMISSIONS[permission]?.scope === 'own';
}

/**
 * Resolve the facility a request is allowed to touch.
 *
 * District officers may act on any facility; everyone else is pinned to the
 * facility on their session, regardless of what the request body claims.
 *
 * @param {{role: string, facilityId?: string|null}} actor
 * @param {string|undefined} requestedFacilityId
 * @returns {string}
 * @throws {ForbiddenError} When a scoped role targets another facility.
 */
export function resolveFacilityScope(actor, requestedFacilityId) {
  if (actor.role === ROLES.DISTRICT_OFFICER) {
    if (!requestedFacilityId) throw new ForbiddenError('district_officer must specify a facilityId');
    return requestedFacilityId;
  }
  if (!actor.facilityId) throw new ForbiddenError('Your session is not attached to a facility');
  if (requestedFacilityId && requestedFacilityId !== actor.facilityId) {
    throw new ForbiddenError('You can only access data for your own facility');
  }
  return actor.facilityId;
}

/**
 * Read-scope resolution: like {@link resolveFacilityScope} but a facility is
 * optional for district officers, who are allowed to read across the district.
 *
 * @param {{role: string, facilityId?: string|null}} actor
 * @param {string|undefined} requestedFacilityId
 * @returns {string|null} The facility to read, or null for district-wide.
 * @throws {ForbiddenError} When a scoped role targets another facility.
 */
export function resolveReadScope(actor, requestedFacilityId) {
  // District officers see the whole district and may narrow to one facility.
  if (actor.role === ROLES.DISTRICT_OFFICER) return requestedFacilityId ?? null;

  // In demo mode the public role is a real, selectable principal that reads
  // the anonymous view of any single facility - that is the whole point of the
  // public crowding page. It is read-only by construction: every write
  // permission excludes it.
  if (actor.role === ROLES.PUBLIC) {
    if (!requestedFacilityId) {
      throw new ForbiddenError('Specify a facilityId to view public information');
    }
    return requestedFacilityId;
  }

  return resolveFacilityScope(actor, requestedFacilityId);
}

/**
 * Assert that the caller holds a permission, throwing a 403 when not.
 *
 * @param {{role: string|null}} actor
 * @param {string} permission
 * @returns {PermissionSpec}
 * @throws {ForbiddenError}
 */
export function assertPermission(actor, permission) {
  if (!can(actor?.role, permission)) {
    throw new ForbiddenError(`Role '${actor?.role ?? 'anonymous'}' cannot perform '${permission}'`);
  }
  return permissionSpec(permission);
}

/**
 * Human-readable list of what a role may do (used by the role switcher UI).
 *
 * @param {string} role
 * @returns {string[]}
 */
export function permissionsForRole(role) {
  return Object.entries(PERMISSIONS)
    .filter(([_permission, spec]) => spec.roles.includes(role))
    .map(([permission]) => permission)
    .sort();
}

/**
 * Resolve the facility scope for a permission in one call.
 *
 * `scope: 'own'`  - write surfaces. Everyone is pinned to their session
 *                   facility; a district officer must name one explicitly.
 * `scope: 'read'` - read surfaces. District officers may stay district-wide
 *                   (null) or narrow to one facility; everyone else is pinned.
 * no scope        - the permission is not facility-bound (e.g. `district:read`),
 *                   so nothing is resolved and the controller decides.
 *
 * @param {{role: string, facilityId?: string|null}} actor
 * @param {string} permission
 * @param {string|null} [requestedFacilityId]
 * @returns {string|null}
 * @throws {ForbiddenError} When a scoped role targets another facility.
 */
export function resolveScope(actor, permission, requestedFacilityId = null) {
  const spec = PERMISSIONS[permission];
  if (!spec || !spec.scope) return null;
  if (spec.scope === 'read') return resolveReadScope(actor, requestedFacilityId ?? undefined);
  return resolveFacilityScope(actor, requestedFacilityId ?? undefined);
}
