/**
 * Attach the process-wide repository to each request as `req.repository`.
 *
 * Controllers and services receive the repository through the request rather
 * than importing a singleton, which keeps them trivially testable and makes the
 * Firestore/in-memory switch invisible to them.
 *
 * @module middleware/attachRepository
 */

/**
 * @param {object} repository
 * @returns {import('express').RequestHandler}
 */
export function attachRepository(repository) {
  return (req, _res, next) => {
    req.repository = repository;
    next();
  };
}

export default attachRepository;
