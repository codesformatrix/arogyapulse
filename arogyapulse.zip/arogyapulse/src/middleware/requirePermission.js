/**
 * Route-level access control.
 *
 * @module middleware/requirePermission
 */

import { ValidationError, UnauthorizedError } from '../utils/errors.js';
import { assertPermission, resolveScope } from './rbac.js';

/**
 * Build middleware that enforces one permission.
 *
 * Usage:
 *   router.post('/stock/adjust', requirePermission('stock:adjust'), controller.adjust)
 *
 * When the permission is facility-scoped, the middleware pins `req.facilityId`
 * to a facility the caller is actually allowed to touch, so a controller can
 * never act on a facility taken straight from the body. `req.params`,
 * `req.query` and `req.body` are consulted only to *narrow* the scope for a
 * district officer, never to widen it for anyone else.
 *
 * @param {string} permission - Key of the permission matrix.
 * @param {object} [options]
 * @param {boolean} [options.requireFacility] - Reject when no facility resolves.
 * @returns {import('express').RequestHandler}
 */
export function requirePermission(permission, options = {}) {
  return (req, _res, next) => {
    try {
      const actor = req.actor;

      // A missing actor is an authentication problem; a public actor simply
      // holds the `public` role, so the matrix below decides what it may do.
      if (!actor) {
        next(new UnauthorizedError('Sign in to continue'));
        return;
      }

      assertPermission(actor, permission);

      const requested =
        req.query?.facilityId ?? req.body?.facilityId ?? req.params?.facilityId ?? null;

      const resolved = resolveScope(actor, permission, requested);

      if (options.requireFacility && !resolved) {
        next(new ValidationError(`facilityId is required for ${permission}`));
        return;
      }

      req.facilityId = resolved;
      next();
    } catch (error) {
      next(error);
    }
  };
}

export default requirePermission;
