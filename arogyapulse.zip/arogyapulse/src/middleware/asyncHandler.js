/**
 * Shared Express plumbing: async error capture and response helpers.
 *
 * @module middleware/asyncHandler
 */

/**
 * Wrap an async route handler so a rejected promise reaches the error
 * middleware instead of hanging the request.
 *
 * @param {(req: import('express').Request, res: import('express').Response) => Promise<unknown>} handler
 * @returns {import('express').RequestHandler}
 */
export function asyncHandler(handler) {
  return (req, res, next) => {
    Promise.resolve(handler(req, res)).catch(next);
  };
}

export default asyncHandler;
