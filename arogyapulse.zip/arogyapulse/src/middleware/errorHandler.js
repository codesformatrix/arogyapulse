/**
 * Error handling and 404 middleware.
 *
 * Nothing in here ever puts a stack trace, a file path or a driver message in
 * a response body. The full error goes to Cloud Logging; the client gets a
 * stable code and a message that is safe to read aloud at a help desk.
 *
 * @module middleware/errorHandler
 */

import config from '../config/env.js';
import { AppError, toAppError } from '../utils/errors.js';
import { formatIssues } from '../services/validate.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('http');

/**
 * 404 for unmatched API routes.
 *
 * @returns {import('express').RequestHandler}
 */
export function notFoundHandler() {
  return (req, res) => {
    res.status(404).json({
      error: {
        code: 'NOT_FOUND',
        message: `No route for ${req.method} ${req.originalUrl.split('?')[0]}`,
      },
    });
  };
}

/**
 * Final error handler.
 *
 * @returns {import('express').ErrorRequestHandler}
 */
export function errorHandler() {
  return (error, req, res, _next) => {
    const appError = toAppError(error);

    // Never log a client validation error as a server fault.
    if (appError.statusCode >= 500) {
      log.error('Request failed', {
        method: req.method,
        path: req.originalUrl.split('?')[0],
        code: appError.code,
        error: appError.cause ?? appError,
      });
    } else {
      log.warn('Request rejected', {
        method: req.method,
        path: req.originalUrl.split('?')[0],
        code: appError.code,
        status: appError.statusCode,
      });
    }

    const body = {
      error: {
        code: appError.code,
        message: appError.expose ? appError.message : 'Unexpected server error',
      },
    };

    if (appError instanceof AppError && appError.details?.issues) {
      body.error.issues = formatIssues(appError.details.issues);
    }
    if (!config.isProduction && appError.statusCode >= 500) {
      body.error.detail = String(appError.cause?.message ?? appError.message);
    }

    if (!res.headersSent) res.status(appError.statusCode).json(body);
  };
}

export default errorHandler;
