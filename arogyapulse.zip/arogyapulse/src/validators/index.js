/**
 * Request validation schemas (zod).
 *
 * One schema per input surface. Keeping them in a single, dependency-free
 * module means the controllers stay thin, the schemas are unit-testable in
 * isolation, and there is exactly one place to review the trust boundary.
 *
 * @module validators
 */

import { z } from 'zod';

import {
  ADJUSTMENT_REASONS,
  DEPARTMENTS,
  INDENT_STATUS,
  LANGUAGES,
  PAGINATION,
  REFERRAL_STATUS,
  ROLES,
  TRANSFER_STATUS,
} from '../config/constants.js';

/** Bounded positive integer used by most quantities. */
const units = z.coerce.number().int().min(0).max(1_000_000);
const counterId = z.coerce.number().int().min(1).max(50);

/** `?limit=&offset=` for every list endpoint. */
export const paginationSchema = z.object({
  limit: z.coerce
    .number()
    .int()
    .min(1)
    .max(PAGINATION.MAX_LIMIT)
    .default(PAGINATION.DEFAULT_LIMIT),
  offset: z.coerce.number().int().min(0).max(100_000).default(0),
});

/** Shared path parameter. */
export const idParamSchema = z.object({
  id: z.string().trim().min(1).max(64),
});

/** `?facilityId=` - public and staff reads. */
export const facilityQuerySchema = z.object({
  facilityId: z.string().trim().min(1).max(64),
});

/** `?type=PHC|CHC` filter on the facility list. */
export const facilityListSchema = paginationSchema.extend({
  type: z.enum(['PHC', 'CHC', 'DISTRICT_STORE']).optional(),
  q: z.string().trim().max(64).optional(),
});

/** POST /api/auth/login - demo-mode role switcher. */
export const loginSchema = z.object({
  role: z.enum([ROLES.DISTRICT_OFFICER, ROLES.CHC_ADMIN, ROLES.FACILITY_STAFF, ROLES.PUBLIC]),
  // District and public actors have no facility, and a client naturally sends
  // an explicit null for them, so nullish is accepted and coalesced downstream.
  facilityId: z
    .string()
    .trim()
    .min(1)
    .max(64)
    .nullish()
    .transform((value) => value ?? null),
  displayName: z
    .string()
    .trim()
    .min(2)
    .max(60)
    .nullish()
    .transform((value) => value ?? null),
});

/** GET /api/stock?facilityId=...&status=RED */
export const stockListSchema = paginationSchema.extend({
  facilityId: z.string().trim().min(1).max(64),
  status: z.enum(['RED', 'AMBER', 'GREEN', 'EXPIRY_RISK']).optional(),
  q: z.string().trim().max(64).optional(),
  sort: z.enum(['risk', 'name', 'cover', 'expiry']).default('risk'),
});

/** POST /api/stock/adjust - one-tap receipt / write-off. */
/**
 * A payload field that is authoritative from the session, not the client.
 *
 * `requirePermission` pins `req.facilityId` from the actor and *then* the
 * controller passes it into the schema, so a facility-scoped mutation never
 * needs - and can never trust - a `facilityId` supplied by the browser.
 * The field is declared at all so that district officers, who may target any
 * facility, have a documented place to put it.
 *
 * @param {object} [options]
 * @param {boolean} [options.required] - Require the value (read endpoints).
 * @returns {import('zod').ZodType<string|null>}
 */
export function facilityIdField(options = {}) {
  const base = z.string().trim().min(1).max(64);
  if (options.required) return base;
  return base.nullish().transform((value) => value ?? null);
}

/**
 * Apply `facilityIdField()` to a shape.
 *
 * @param {Record<string, import('zod').ZodTypeAny>} shape
 * @param {object} [options]
 * @returns {import('zod').ZodObject<any>}
 */
function facilityScoped(shape, options = {}) {
  return z.object({ facilityId: facilityIdField(options), ...shape });
}

export const stockAdjustSchema = facilityScoped({
  medicineId: z.string().trim().min(1).max(64),
  delta: z.coerce.number().int().min(-1_000_000).max(1_000_000).refine((value) => value !== 0, {
    message: 'delta must not be zero',
  }),
  reason: z.enum(ADJUSTMENT_REASONS),
  batchNo: z.string().trim().max(32).optional(),
  expiryDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'expiryDate must be YYYY-MM-DD')
    .optional(),
  note: z.string().trim().max(200).optional(),
});

/** POST /api/dispensing - log stock issued to a patient token. */
export const dispensingSchema = facilityScoped({
  medicineId: z.string().trim().min(1).max(64),
  quantity: units.refine((value) => value > 0, { message: 'quantity must be greater than zero' }),
  token: z.string().trim().max(24).optional(),
  counterId: counterId.optional(),
});

/** POST /api/tokens - issue an anonymous OPD token. */
export const tokenIssueSchema = facilityScoped({
  department: z.enum(DEPARTMENTS),
});

/** POST /api/tokens/:id/serve - mark a token served at a counter. */
export const tokenServeSchema = z.object({
  counterId,
});

/** POST /api/counters - open or close an OPD counter. */
export const counterSchema = facilityScoped({
  counterId,
  department: z.enum(DEPARTMENTS),
  isOpen: z.boolean(),
});

/** POST /api/beds/:wardId/update - one-tap +/- bed change. */
export const bedUpdateSchema = z.object({
  field: z.enum(['occupied', 'reserved']),
  delta: z.coerce.number().int().min(-500).max(500).refine((value) => value !== 0, {
    message: 'delta must not be zero',
  }),
  reason: z.string().trim().max(120).optional(),
});

/** PUT /api/wards/:id - set ward capacity. */
export const wardSchema = z.object({
  name: z.string().trim().min(1).max(60),
  total: units.max(1000),
  occupied: units.max(1000).default(0),
  reserved: units.max(1000).default(0),
});

/** POST /api/attendance/check-in and /check-out. */
export const attendanceSchema = facilityScoped({
  doctorId: z.string().trim().min(1).max(64),
  note: z.string().trim().max(120).optional(),
});

/** POST /api/leaves - record an approved leave. */
export const leaveSchema = facilityScoped({
  doctorId: z.string().trim().min(1).max(64),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'date must be YYYY-MM-DD'),
  type: z.enum(['CASUAL', 'MEDICAL', 'TRAINING', 'OTHER']).default('CASUAL'),
  note: z.string().trim().max(120).optional(),
});

/** POST /api/referrals - PHC asks a CHC for a bed. */
export const referralSchema = facilityScoped({
  toFacilityId: z.string().trim().min(1).max(64),
  patientToken: z.string().trim().min(1).max(24),
  category: z.enum(['MATERNITY', 'EMERGENCY', 'PEDIATRIC', 'GENERAL', 'SURGICAL']),
  urgency: z.enum(['ROUTINE', 'URGENT', 'CRITICAL']).default('URGENT'),
  needsBed: z.boolean().default(true),
  note: z.string().trim().max(200).optional(),
});

/** POST /api/referrals/:id/status */
export const referralStatusSchema = z.object({
  status: z.enum([
    REFERRAL_STATUS.ACCEPTED,
    REFERRAL_STATUS.REJECTED,
    REFERRAL_STATUS.TRANSFERRED,
    REFERRAL_STATUS.CLOSED,
  ]),
  wardId: z.string().trim().max(64).optional(),
  note: z.string().trim().max(200).optional(),
});

/** POST /api/indents */
export const indentSchema = facilityScoped({
  items: z
    .array(
      z.object({
        medicineId: z.string().trim().min(1).max(64),
        units: units.refine((value) => value > 0, { message: 'units must be greater than zero' }),
      }),
    )
    .min(1)
    .max(100),
  note: z.string().trim().max(200).optional(),
});

/** POST /api/indents/:id/status */
export const indentStatusSchema = z.object({
  status: z.enum([
    INDENT_STATUS.APPROVED,
    INDENT_STATUS.REJECTED,
    INDENT_STATUS.DISPATCHED,
    INDENT_STATUS.RECEIVED,
    INDENT_STATUS.CANCELLED,
  ]),
  note: z.string().trim().max(200).optional(),
});

/** POST /api/transfers */
export const transferSchema = z.object({
  fromFacilityId: z.string().trim().min(1).max(64),
  toFacilityId: z.string().trim().min(1).max(64),
  medicineId: z.string().trim().min(1).max(64),
  batchId: z.string().trim().min(1).max(64),
  units: units.refine((value) => value > 0, { message: 'units must be greater than zero' }),
  reason: z.enum(['SURPLUS_TO_DEFICIT', 'EXPIRY_RISK', 'MANUAL']).default('MANUAL'),
  note: z.string().trim().max(200).optional(),
});

/** POST /api/transfers/:id/status */
export const transferStatusSchema = z.object({
  status: z.enum([
    TRANSFER_STATUS.APPROVED,
    TRANSFER_STATUS.REJECTED,
    TRANSFER_STATUS.DISPATCHED,
    TRANSFER_STATUS.RECEIVED,
    TRANSFER_STATUS.CANCELLED,
  ]),
  note: z.string().trim().max(200).optional(),
});

/** POST /api/ai/nl-entry - natural-language stock/footfall entry. */
export const nlEntrySchema = facilityScoped({
  text: z.string().trim().min(2).max(400),
  language: z.enum(LANGUAGES).optional(),
});

/** POST /api/ai/confirm - user confirms a parsed NL entry before it is saved. */
export const nlConfirmSchema = facilityScoped({
  intent: z.enum(['STOCK_ADJUSTMENT', 'DISPENSING', 'FOOTFALL', 'BED_UPDATE', 'UNKNOWN']),
  medicineId: z.string().trim().max(64).optional(),
  quantity: z.coerce.number().int().min(-1_000_000).max(1_000_000).optional(),
  reason: z.enum(ADJUSTMENT_REASONS).optional(),
  department: z.enum(DEPARTMENTS).optional(),
  // The NL preview calls these bedField / bedDelta; accept both spellings so a
  // round-trip of the preview object is accepted verbatim.
  bedField: z.enum(['occupied', 'reserved']).optional(),
  bedDelta: z.coerce.number().int().min(-100).max(100).optional(),
  field: z.enum(['occupied', 'reserved']).optional(),
  confidence: z.coerce.number().min(0).max(1).optional(),
  originalText: z.string().trim().max(400).optional(),
});

/** POST /api/ai/briefing */
export const briefingSchema = z.object({
  scope: z.enum(['facility', 'district']).default('facility'),
  facilityId: z.string().trim().max(64).optional(),
  language: z.enum(LANGUAGES).default('en'),
});

/** POST /api/ai/ask */
export const askSchema = z.object({
  question: z.string().trim().min(3).max(400),
  facilityId: z.string().trim().max(64).optional(),
  language: z.enum(LANGUAGES).default('en'),
});

/** GET /api/public/* - language + facility filters for anonymous reads. */
export const publicQuerySchema = z.object({
  facilityId: z.string().trim().max(64).optional(),
  lang: z.enum(LANGUAGES).default('en'),
});

/** GET /api/footfall?facilityId=&date= */
export const footfallQuerySchema = z.object({
  facilityId: z.string().trim().min(1).max(64),
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'date must be YYYY-MM-DD')
    .optional(),
  department: z.enum(DEPARTMENTS).optional(),
});

/** GET /api/audit?facilityId=&entityType= */
export const auditQuerySchema = paginationSchema.extend({
  facilityId: facilityIdField(),
  entityType: z
    .enum(['STOCK', 'BATCH', 'BED', 'WARD', 'ATTENDANCE', 'INDENT', 'TRANSFER', 'REFERRAL', 'TOKEN', 'AI'])
    .optional(),
});

/** GET /api/medicines */
export const medicineListSchema = paginationSchema.extend({
  category: z.string().trim().max(40).optional(),
  coldChain: z
    .enum(['true', 'false'])
    .transform((value) => value === 'true')
    .optional(),
  q: z.string().trim().max(64).optional(),
});

/** GET /api/doctors?facilityId= */
export const doctorListSchema = paginationSchema.extend({
  facilityId: z.string().trim().min(1).max(64),
  department: z.string().trim().max(60).optional(),
});

/** Offline queue replay: a batch of mutations captured while the phone was offline. */
export const offlineBatchSchema = z.object({
  operations: z
    .array(
      z.object({
        id: z.string().trim().min(1).max(64),
        method: z.enum(['POST', 'PUT', 'PATCH', 'DELETE']),
        path: z
          .string()
          .trim()
          .min(1)
          .max(200)
          .refine((value) => value.startsWith('/api/'), { message: 'path must start with /api/' }),
        body: z.record(z.string(), z.unknown()).optional(),
        capturedAt: z.string().datetime({ offset: true }).optional(),
      }),
    )
    .min(1)
    .max(50),
});
