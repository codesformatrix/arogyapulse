/**
 * Seeded facility master data.
 *
 * One district (Ahmednagar, Maharashtra) with 2 CHCs, 7 PHCs and the district
 * drug store. Coordinates are real town locations so the "Open in Google Maps"
 * links and the haversine transfer distances behave like production.
 *
 * Population figures are plausible planning numbers, not census extracts.
 *
 * @module seed/facilities
 */

import { FACILITY_TYPES } from '../config/constants.js';

/**
 * @typedef {Object} FacilitySeed
 * @property {string} id
 * @property {string} name
 * @property {string} nameHi
 * @property {'PHC'|'CHC'|'DISTRICT_STORE'} type
 * @property {string} block - Taluka / block.
 * @property {string} address
 * @property {number} latitude
 * @property {number} longitude
 * @property {number} populationServed
 * @property {number} opdCounters
 * @property {{name: string, total: number}[]} wards
 * @property {{id: string, name: string, department: string}[]} doctors
 * @property {number} loadFactor - Relative busyness multiplier used by the seed.
 */

/** @type {FacilitySeed[]} */
export const FACILITIES = [
  {
    id: 'FAC-DS-AHN',
    name: 'District Drug Store, Ahmednagar',
    nameHi: 'जिला औषधि भंडार, अहमदनगर',
    type: FACILITY_TYPES.DISTRICT_STORE,
    block: 'Ahmednagar',
    address: 'Civil Hospital Campus, Ahmednagar, Maharashtra 414001',
    latitude: 19.0947,
    longitude: 74.7484,
    populationServed: 4_500_000,
    opdCounters: 0,
    wards: [],
    doctors: [],
    loadFactor: 1,
  },
  {
    id: 'FAC-CHC-SANGAMNER',
    name: 'CHC Sangamner',
    nameHi: 'सामुदायिक स्वास्थ्य केंद्र, संगमनेर',
    type: FACILITY_TYPES.CHC,
    block: 'Sangamner',
    address: 'Sangamner, Ahmednagar, Maharashtra 422605',
    latitude: 19.5714,
    longitude: 74.2079,
    populationServed: 148_000,
    opdCounters: 6,
    wards: [
      { name: 'General Ward', total: 24 },
      { name: 'Maternity Ward', total: 12 },
      { name: 'Paediatric Ward', total: 8 },
    ],
    doctors: [
      { id: 'DOC-CHCS-1', name: 'Dr. S. Kulkarni', department: 'General Medicine' },
      { id: 'DOC-CHCS-2', name: 'Dr. P. Deshmukh', department: 'Obstetrics' },
      { id: 'DOC-CHCS-3', name: 'Dr. A. Shaikh', department: 'Paediatrics' },
      { id: 'DOC-CHCS-4', name: 'Dr. R. Jadhav', department: 'Surgery' },
    ],
    loadFactor: 1.6,
  },
  {
    id: 'FAC-CHC-SHRIRAMPUR',
    name: 'CHC Shrirampur',
    nameHi: 'सामुदायिक स्वास्थ्य केंद्र, श्रीरामपूर',
    type: FACILITY_TYPES.CHC,
    block: 'Shrirampur',
    address: 'Shrirampur, Ahmednagar, Maharashtra 413709',
    latitude: 19.6205,
    longitude: 74.6517,
    populationServed: 132_000,
    opdCounters: 5,
    wards: [
      { name: 'General Ward', total: 20 },
      { name: 'Maternity Ward', total: 10 },
      { name: 'Paediatric Ward', total: 6 },
    ],
    doctors: [
      { id: 'DOC-CHCSR-1', name: 'Dr. M. Pawar', department: 'General Medicine' },
      { id: 'DOC-CHCSR-2', name: 'Dr. V. Gaikwad', department: 'Obstetrics' },
      { id: 'DOC-CHCSR-3', name: 'Dr. N. Kadam', department: 'General Medicine' },
    ],
    loadFactor: 1.35,
  },
  {
    id: 'FAC-PHC-KOPARGAON',
    name: 'PHC Kopargaon',
    nameHi: 'प्राथमिक स्वास्थ्य केंद्र, कोपरगाव',
    type: FACILITY_TYPES.PHC,
    block: 'Kopargaon',
    address: 'Kopargaon, Ahmednagar, Maharashtra 423601',
    latitude: 19.8857,
    longitude: 74.4831,
    populationServed: 42_000,
    opdCounters: 3,
    wards: [
      { name: 'Observation Beds', total: 6 },
      { name: 'Maternity Beds', total: 4 },
    ],
    doctors: [
      { id: 'DOC-PHCK-1', name: 'Dr. S. Bhosale', department: 'General Medicine' },
      { id: 'DOC-PHCK-2', name: 'Dr. K. Thorat', department: 'General Medicine' },
    ],
    loadFactor: 1.1,
  },
  {
    id: 'FAC-PHC-RAHATA',
    name: 'PHC Rahata',
    nameHi: 'प्राथमिक स्वास्थ्य केंद्र, राहाता',
    type: FACILITY_TYPES.PHC,
    block: 'Rahata',
    address: 'Rahata, Ahmednagar, Maharashtra 423107',
    latitude: 19.5917,
    longitude: 74.4428,
    populationServed: 38_000,
    opdCounters: 3,
    wards: [
      { name: 'Observation Beds', total: 6 },
      { name: 'Maternity Beds', total: 4 },
    ],
    doctors: [
      { id: 'DOC-PHCR-1', name: 'Dr. A. Shinde', department: 'General Medicine' },
      { id: 'DOC-PHCR-2', name: 'Dr. D. Wagh', department: 'General Medicine' },
    ],
    loadFactor: 1,
  },
  {
    id: 'FAC-PHC-SHEVGAON',
    name: 'PHC Shevgaon',
    nameHi: 'प्राथमिक स्वास्थ्य केंद्र, शेवगाव',
    type: FACILITY_TYPES.PHC,
    block: 'Shevgaon',
    address: 'Shevgaon, Ahmednagar, Maharashtra 414502',
    latitude: 19.2459,
    longitude: 75.2452,
    populationServed: 31_000,
    opdCounters: 2,
    wards: [{ name: 'Observation Beds', total: 6 }],
    doctors: [{ id: 'DOC-PHCSH-1', name: 'Dr. R. Sonawane', department: 'General Medicine' }],
    loadFactor: 0.85,
  },
  {
    id: 'FAC-PHC-PATHARDI',
    name: 'PHC Pathardi',
    nameHi: 'प्राथमिक स्वास्थ्य केंद्र, पाथर्डी',
    type: FACILITY_TYPES.PHC,
    block: 'Pathardi',
    address: 'Pathardi, Ahmednagar, Maharashtra 414102',
    latitude: 19.1771,
    longitude: 75.1834,
    populationServed: 29_000,
    opdCounters: 2,
    wards: [{ name: 'Observation Beds', total: 4 }],
    doctors: [{ id: 'DOC-PHCP-1', name: 'Dr. P. Nikam', department: 'General Medicine' }],
    loadFactor: 0.8,
  },
  {
    id: 'FAC-PHC-NEWASA',
    name: 'PHC Newasa',
    nameHi: 'प्राथमिक स्वास्थ्य केंद्र, नेवासा',
    type: FACILITY_TYPES.PHC,
    block: 'Newasa',
    address: 'Newasa, Ahmednagar, Maharashtra 414603',
    latitude: 19.4681,
    longitude: 74.9735,
    populationServed: 34_000,
    opdCounters: 2,
    wards: [
      { name: 'Observation Beds', total: 6 },
      { name: 'Maternity Beds', total: 2 },
    ],
    doctors: [
      { id: 'DOC-PHCN-1', name: 'Dr. S. Kardile', department: 'General Medicine' },
      { id: 'DOC-PHCN-2', name: 'Dr. M. Kale', department: 'General Medicine' },
    ],
    loadFactor: 0.95,
  },
  {
    id: 'FAC-PHC-AKOLE',
    name: 'PHC Akole (Tribal)',
    nameHi: 'प्राथमिक स्वास्थ्य केंद्र, अकोले (आदिवासी)',
    type: FACILITY_TYPES.PHC,
    block: 'Akole',
    address: 'Akole, Ahmednagar, Maharashtra 422601',
    latitude: 19.4029,
    longitude: 73.9473,
    populationServed: 26_000,
    opdCounters: 2,
    wards: [{ name: 'Observation Beds', total: 4 }],
    doctors: [{ id: 'DOC-PHCA-1', name: 'Dr. T. Pawara', department: 'General Medicine' }],
    loadFactor: 0.7,
  },
  {
    id: 'FAC-PHC-PARNER',
    name: 'PHC Parner',
    nameHi: 'प्राथमिक स्वास्थ्य केंद्र, पारनेर',
    type: FACILITY_TYPES.PHC,
    block: 'Parner',
    address: 'Parner, Ahmednagar, Maharashtra 414304',
    latitude: 19.0531,
    longitude: 75.1093,
    populationServed: 33_000,
    opdCounters: 2,
    wards: [{ name: 'Observation Beds', total: 6 }],
    doctors: [
      { id: 'DOC-PHCPN-1', name: 'Dr. G. Dhumal', department: 'General Medicine' },
      { id: 'DOC-PHCPN-2', name: 'Dr. L. More', department: 'General Medicine' },
    ],
    loadFactor: 0.9,
  },
  {
    id: 'FAC-PHC-SHRIGONDA',
    name: 'PHC Shrigonda',
    nameHi: 'प्राथमिक स्वास्थ्य केंद्र, श्रीगोंदा',
    type: FACILITY_TYPES.PHC,
    block: 'Shrigonda',
    address: 'Shrigonda, Ahmednagar, Maharashtra 413701',
    latitude: 18.6149,
    longitude: 74.6989,
    populationServed: 41_000,
    opdCounters: 3,
    wards: [
      { name: 'Observation Beds', total: 6 },
      { name: 'Maternity Beds', total: 4 },
    ],
    doctors: [
      { id: 'DOC-PHCSG-1', name: 'Dr. M. Gorhe', department: 'General Medicine' },
      { id: 'DOC-PHCSG-2', name: 'Dr. R. Bhosale', department: 'General Medicine' },
    ],
    loadFactor: 1.0,
  },
];

/**
 * Facilities that serve patients (excludes the district drug store).
 *
 * @type {FacilitySeed[]}
 */
export const SERVICE_FACILITIES = FACILITIES.filter(
  (facility) => facility.type !== FACILITY_TYPES.DISTRICT_STORE,
);

/** @type {Map<string, FacilitySeed>} */
export const FACILITY_BY_ID = new Map(FACILITIES.map((facility) => [facility.id, facility]));

/** @type {string[]} */
export const PHC_IDS = FACILITIES.filter((facility) => facility.type === FACILITY_TYPES.PHC).map(
  (facility) => facility.id,
);

/** @type {string[]} */
export const CHC_IDS = FACILITIES.filter((facility) => facility.type === FACILITY_TYPES.CHC).map(
  (facility) => facility.id,
);

export default FACILITIES;
