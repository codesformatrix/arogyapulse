/**
 * Seeded essential-medicine catalogue.
 *
 * 25 items drawn from the kinds of commodities a Primary Health Centre in
 * Maharashtra actually dispenses: NCD refills, ORS/zinc for diarrhoea,
 * antibiotics from the AWaRe "Access/Watch" groups, cold-chain vaccines and
 * the two emergency sera that must never be out of stock.
 *
 * `reorderMultiple` reflects how the drug store actually packs the item, which
 * keeps auto-generated indents realistic (you cannot order 37 ORS sachets).
 *
 * @module seed/medicines
 */

/**
 * @typedef {Object} MedicineSeed
 * @property {string} id
 * @property {string} name - English / generic name.
 * @property {string} nameHi - Hindi (Devanagari) label for the i18n UI.
 * @property {string} strength
 * @property {string} form - TAB | CAP | SUSP | INJ | SACHET | VIAL | INHALER
 * @property {string} unit - Unit of issue counted in stock.
 * @property {string} category
 * @property {boolean} coldChain
 * @property {boolean} critical - Never allowed to hit zero.
 * @property {number} reorderMultiple - Pack size used when rounding indents.
 * @property {number} shelfLifeDays
 * @property {number} baseDaily - Typical daily consumption at a busy PHC.
 */

/** @type {MedicineSeed[]} */
export const MEDICINES = [
  { id: 'MED-PARA-500', name: 'Paracetamol', nameHi: 'पैरासिटामोल', strength: '500 mg', form: 'TAB', unit: 'tablet', category: 'Analgesic/Antipyretic', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 180 },
  { id: 'MED-ORS', name: 'Oral Rehydration Salts (ORS)', nameHi: 'ओ.आर.एस.', strength: '20.5 g', form: 'SACHET', unit: 'sachet', category: 'Rehydration', coldChain: false, critical: true, reorderMultiple: 50, shelfLifeDays: 730, baseDaily: 40 },
  { id: 'MED-ZINC-20', name: 'Zinc Sulphate (Dispersible)', nameHi: 'जिंक सल्फेट', strength: '20 mg', form: 'TAB', unit: 'tablet', category: 'Rehydration', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 35 },
  { id: 'MED-AMOX-250', name: 'Amoxicillin', nameHi: 'एमोक्सिसिलिन', strength: '250 mg', form: 'CAP', unit: 'capsule', category: 'Antibiotic (Access)', coldChain: false, critical: true, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 90 },
  { id: 'MED-AMOX-SUSP', name: 'Amoxicillin Oral Suspension', nameHi: 'एमोक्सिसिलिन सस्पेंशन', strength: '125 mg/5 ml', form: 'SUSP', unit: 'bottle', category: 'Antibiotic (Access)', coldChain: false, critical: false, reorderMultiple: 10, shelfLifeDays: 540, baseDaily: 8 },
  { id: 'MED-AZITH-500', name: 'Azithromycin', nameHi: 'एज़िथ्रोमाइसिन', strength: '500 mg', form: 'TAB', unit: 'tablet', category: 'Antibiotic (Watch)', coldChain: false, critical: true, reorderMultiple: 30, shelfLifeDays: 730, baseDaily: 24 },
  { id: 'MED-CEFTRI-1G', name: 'Ceftriaxone Injection', nameHi: 'सेफ्ट्रियाक्सोन इंजेक्शन', strength: '1 g', form: 'VIAL', unit: 'vial', category: 'Antibiotic (Watch)', coldChain: false, critical: true, reorderMultiple: 10, shelfLifeDays: 730, baseDaily: 6 },
  { id: 'MED-METRO-400', name: 'Metronidazole', nameHi: 'मेट्रोनिडाज़ोल', strength: '400 mg', form: 'TAB', unit: 'tablet', category: 'Antibiotic (Access)', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 45 },
  { id: 'MED-ALBEN-400', name: 'Albendazole', nameHi: 'एल्बेन्डाज़ोल', strength: '400 mg', form: 'TAB', unit: 'tablet', category: 'Antiparasitic', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 20 },
  { id: 'MED-IFA', name: 'Iron and Folic Acid', nameHi: 'आयरन फोलिक एसिड', strength: '60 mg + 500 mcg', form: 'TAB', unit: 'tablet', category: 'Anaemia control', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 120 },
  { id: 'MED-METFORMIN-500', name: 'Metformin', nameHi: 'मेटफॉर्मिन', strength: '500 mg', form: 'TAB', unit: 'tablet', category: 'NCD - Diabetes', coldChain: false, critical: true, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 150 },
  { id: 'MED-GLIMEPIRIDE-1', name: 'Glimepiride', nameHi: 'ग्लाइमेपिराइड', strength: '1 mg', form: 'TAB', unit: 'tablet', category: 'NCD - Diabetes', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 40 },
  { id: 'MED-AMLODIPINE-5', name: 'Amlodipine', nameHi: 'एम्लोडिपिन', strength: '5 mg', form: 'TAB', unit: 'tablet', category: 'NCD - Hypertension', coldChain: false, critical: true, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 140 },
  { id: 'MED-TELMI-40', name: 'Telmisartan', nameHi: 'टेल्मिसार्टन', strength: '40 mg', form: 'TAB', unit: 'tablet', category: 'NCD - Hypertension', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 60 },
  { id: 'MED-ATORVA-10', name: 'Atorvastatin', nameHi: 'एटोरवास्टेटिन', strength: '10 mg', form: 'TAB', unit: 'tablet', category: 'NCD - Lipid', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 45 },
  { id: 'MED-ASA-75', name: 'Aspirin (Low dose)', nameHi: 'एस्पिरिन (कम मात्रा)', strength: '75 mg', form: 'TAB', unit: 'tablet', category: 'NCD - Cardiac', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 50 },
  { id: 'MED-OXYTOCIN', name: 'Oxytocin Injection', nameHi: 'ऑक्सीटोसिन इंजेक्शन', strength: '10 IU/ml', form: 'AMP', unit: 'ampoule', category: 'Maternal health', coldChain: true, critical: true, reorderMultiple: 10, shelfLifeDays: 540, baseDaily: 2 },
  { id: 'MED-MGSO4', name: 'Magnesium Sulphate Injection', nameHi: 'मैग्नीशियम सल्फेट इंजेक्शन', strength: '50% 10 ml', form: 'AMP', unit: 'ampoule', category: 'Maternal health', coldChain: false, critical: true, reorderMultiple: 10, shelfLifeDays: 730, baseDaily: 1 },
  { id: 'MED-TT', name: 'Tetanus Toxoid (TT)', nameHi: 'टिटनेस टॉक्सॉइड', strength: '5 Lf/0.5 ml', form: 'VIAL', unit: 'dose', category: 'Immunisation', coldChain: true, critical: true, reorderMultiple: 20, shelfLifeDays: 540, baseDaily: 12 },
  { id: 'MED-BCG', name: 'BCG Vaccine', nameHi: 'बी.सी.जी. टीका', strength: '0.05 ml', form: 'VIAL', unit: 'dose', category: 'Immunisation', coldChain: true, critical: true, reorderMultiple: 20, shelfLifeDays: 365, baseDaily: 8 },
  { id: 'MED-OPV', name: 'Oral Polio Vaccine (bOPV)', nameHi: 'ओरल पोलियो टीका', strength: '20 dose vial', form: 'VIAL', unit: 'dose', category: 'Immunisation', coldChain: true, critical: true, reorderMultiple: 40, shelfLifeDays: 365, baseDaily: 10 },
  { id: 'MED-ARV', name: 'Anti-Rabies Vaccine', nameHi: 'एंटी-रेबीज़ टीका', strength: '1 ml', form: 'VIAL', unit: 'vial', category: 'Emergency - Bite', coldChain: true, critical: true, reorderMultiple: 5, shelfLifeDays: 540, baseDaily: 1.5 },
  { id: 'MED-ASV', name: 'Anti-Snake Venom Serum', nameHi: 'एंटी-स्नेक वेनम सीरम', strength: '10 ml', form: 'VIAL', unit: 'vial', category: 'Emergency - Envenomation', coldChain: true, critical: true, reorderMultiple: 5, shelfLifeDays: 365, baseDaily: 0.4 },
  { id: 'MED-SALBUTAMOL', name: 'Salbutamol Inhaler', nameHi: 'सैल्बुटामोल इनहेलर', strength: '100 mcg/puff', form: 'INHALER', unit: 'inhaler', category: 'Respiratory', coldChain: false, critical: true, reorderMultiple: 5, shelfLifeDays: 730, baseDaily: 2 },
  { id: 'MED-CALCIUM', name: 'Calcium + Vitamin D3', nameHi: 'कैल्शियम + विटामिन डी3', strength: '500 mg + 250 IU', form: 'TAB', unit: 'tablet', category: 'Supplement', coldChain: false, critical: false, reorderMultiple: 100, shelfLifeDays: 730, baseDaily: 60 },
];

/**
 * Lookup map by id, used by the seed generator and by tests.
 *
 * @type {Map<string, MedicineSeed>}
 */
export const MEDICINE_BY_ID = new Map(MEDICINES.map((medicine) => [medicine.id, medicine]));

/**
 * Ids that a facility must never be allowed to run out of.
 *
 * @type {string[]}
 */
export const CRITICAL_MEDICINE_IDS = MEDICINES.filter((medicine) => medicine.critical).map(
  (medicine) => medicine.id,
);

export default MEDICINES;
