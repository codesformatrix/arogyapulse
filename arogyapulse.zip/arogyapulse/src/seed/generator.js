/**
 * Deterministic demo-dataset generator (pure - no I/O, no clock reads).
 *
 * The same `seedKey` + `generatedAt` always produces the same district, so:
 *   - the hackathon demo script never drifts between machines,
 *   - integration tests can assert on real numbers,
 *   - a Cloud Run cold start reseeds an identical world.
 *
 * Every entity below carries only aggregate counts and anonymous tokens; there
 * is no patient identifier, name or contact detail anywhere in the dataset.
 *
 * @module seed/generator
 */

import {
  ADJUSTMENT_REASONS,
  ATTENDANCE,
  DEPARTMENTS,
  EXPIRY,
  FACILITY_TYPES,
  INDENT_STATUS,
  MOVEMENT_REASONS,
  REFERRAL_STATUS,
  TRANSFER_STATUS,
} from '../config/constants.js';
import { MEDICINES } from './medicines.js';
import { FACILITIES, SERVICE_FACILITIES } from './facilities.js';
import { createRandom, hashString, round } from '../utils/random.js';
import { addDays, addMinutes, dayKey, startOfDay, toDate } from '../utils/time.js';

/**
 * @typedef {Object} SeedResult
 * @property {object[]} facilities
 * @property {object[]} medicines
 * @property {object[]} stock
 * @property {object[]} batches
 * @property {object[]} dispensing
 * @property {object[]} footfall
 * @property {object[]} tokens
 * @property {object[]} counters
 * @property {object[]} wards
 * @property {object[]} doctors
 * @property {object[]} attendance
 * @property {object[]} rosters
 * @property {object[]} leaves
 * @property {object[]} indents
 * @property {object[]} transfers
 * @property {object[]} referrals
 * @property {object[]} audit
 * @property {object} meta
 */

/** Weekday multipliers (0 = Sunday). Monday OPD + Saturday immunisation drive. */
const WEEKDAY_LOAD = [0.35, 1.25, 1.0, 0.95, 1.05, 0.9, 0.8];

/** Hourly OPD arrival shape, index = hour of day. */
const HOUR_SHAPE = [
  0, 0, 0, 0, 0, 0, 0, 0, 0.5, 1.1, 1.5, 1.2, 0.7, 0.4, 0.9, 1.1, 1, 0.8, 0.4, 0.2, 0, 0, 0, 0,
];

/**
 * Build the complete demo dataset.
 *
 * @param {object} [options]
 * @param {number} [options.days] - Days of history to generate (>= 14).
 * @param {Date|string|number} [options.generatedAt] - "Now" for the dataset.
 * @param {string} [options.seedKey] - Changing this changes every random value.
 * @returns {SeedResult}
 */
export function generateDataset(options = {}) {
  const days = Math.max(14, Math.floor(options.days ?? 45));
  const now = toDate(options.generatedAt) ?? new Date();
  const today = startOfDay(now);
  const todayKey = dayKey(now);
  const seedKey = options.seedKey ?? 'arogyapulse-demo';
  const random = createRandom(seedKey);

  const facilities = FACILITIES.map((facility) => ({
    id: facility.id,
    name: facility.name,
    nameHi: facility.nameHi,
    type: facility.type,
    block: facility.block,
    districtId: 'DIST-AHN',
    districtName: 'Ahmednagar',
    state: 'Maharashtra',
    address: facility.address,
    latitude: facility.latitude,
    longitude: facility.longitude,
    populationServed: facility.populationServed,
    opdCounters: facility.opdCounters,
    attendanceAlertTime: ATTENDANCE.DEFAULT_ALERT_TIME,
    mapsUrl: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
      `${facility.latitude},${facility.longitude}`,
    )}`,
    active: true,
  }));

  const medicines = MEDICINES.map((medicine) => ({ ...medicine }));

  const audit = [];
  const dispensing = [];
  const batches = [];
  const stock = [];

  /**
   * Push an audit entry (newest entries are appended; callers sort later).
   */
  const logAudit = (entry) => {
    audit.push({
      id: `AUD-${audit.length + 1}-${random.int(1000, 9999)}`,
      entityType: entry.entityType,
      entityId: entry.entityId,
      facilityId: entry.facilityId,
      action: entry.action,
      actor: entry.actor ?? 'seed',
      role: entry.role ?? 'facility_staff',
      before: entry.before ?? null,
      after: entry.after ?? null,
      reason: entry.reason ?? null,
      createdAt: entry.at ?? now.toISOString(),
    });
  };

  for (const facility of SERVICE_FACILITIES) {
    const facilityRandom = createRandom(`${seedKey}:${facility.id}`);
    const isChc = facility.type === FACILITY_TYPES.CHC;
    const scale = isChc ? 1.9 : 1;

    for (const medicine of MEDICINES) {
      const baseDaily = medicine.baseDaily * scale * facility.loadFactor * (0.7 + facilityRandom.float() * 0.7);
      const consumptionSeries = [];

      for (let offset = days - 1; offset >= 0; offset -= 1) {
        const date = dayKey(addDays(today, -offset));
        const weekday = toDate(`${date}T00:00:00Z`).getUTCDay();
        const weekly = WEEKDAY_LOAD[weekday] ?? 1;
        // Seasonal surge for rehydration/antibiotics mid-window (monsoon effect).
        const seasonal = medicine.category === 'Rehydration' || medicine.category === 'Antibiotic (Access)'
          ? 1 + 0.5 * Math.sin((offset / days) * Math.PI * 2)
          : 1;
        const noise = 0.75 + facilityRandom.float() * 0.55;
        const quantity = Math.max(0, Math.round(baseDaily * weekly * seasonal * noise));
        consumptionSeries.push({ date, quantity });

        // Record dispensing events for the last 7 days only, to keep the
        // dataset small while still supporting FEFO + audit demonstration.
        if (offset < 7 && quantity > 0) {
          dispensing.push({
            id: `DSP-${facility.id}-${medicine.id}-${offset}-${facilityRandom.int(1000, 9999)}`,
            facilityId: facility.id,
            medicineId: medicine.id,
            quantity,
            token: `A-${100 + facilityRandom.int(1, 80)}`,
            counterId: facility.opdCounters > 0 ? facilityRandom.int(1, facility.opdCounters) : 1,
            reason: MOVEMENT_REASONS.DISPENSING,
            recordedBy: 'seed',
            recordedAt: addMinutes(addDays(today, -offset), 9 * 60 + facilityRandom.int(0, 300)).toISOString(),
          });
        }
      }

      // Deliberately engineer a mix of RED / AMBER / GREEN / EXPIRY_RISK so the
      // demo shows every state without any manual data entry. The opening stock
      // is calibrated against the whole generated history (not the last 7 days)
      // so the resulting days-of-cover lands on the intended band.
      const targetCover = chooseTargetCover(facility.id, medicine.id, facilityRandom);
      const historyPerDay =
        consumptionSeries.reduce((total, entry) => total + entry.quantity, 0) /
        Math.max(1, consumptionSeries.length);
      const openingStock = Math.max(0, Math.round(historyPerDay * targetCover));

      const batchCount = openingStock === 0 ? 0 : facilityRandom.int(1, 3);
      /** @type {{id: string, quantity: number}[]} */
      const lineBatches = [];
      let remaining = openingStock;
      for (let index = 0; index < batchCount; index += 1) {
        const isLast = index === batchCount - 1;
        const quantity = isLast ? remaining : Math.max(1, Math.floor(remaining / (batchCount - index)));
        remaining -= quantity;
        const expiryOffsetDays = chooseExpiryOffset(targetCover, index, facilityRandom);
        const expiryDate = dayKey(addDays(today, expiryOffsetDays));
        const batch = {
          id: `BAT-${facility.id}-${medicine.id}-${index + 1}`,
          facilityId: facility.id,
          medicineId: medicine.id,
          batchNo: `B${2500 + facilityRandom.int(10, 89)}${index + 1}`,
          quantity: Math.max(0, quantity),
          expiryDate,
          receivedAt: addDays(today, -facilityRandom.int(10, 160)).toISOString(),
          status:
            expiryOffsetDays < 0
              ? 'EXPIRED'
              : expiryOffsetDays <= EXPIRY.NEAR_EXPIRY_DAYS
                ? 'NEAR_EXPIRY'
                : 'ACTIVE',
        };
        batches.push(batch);
        lineBatches.push(batch);
      }

      // Sum only this line's batches - `batches` is the district-wide array.
      const totalOnHand = lineBatches.reduce((total, batch) => total + batch.quantity, 0);
      stock.push({
        id: `STK-${facility.id}-${medicine.id}`,
        facilityId: facility.id,
        medicineId: medicine.id,
        units: totalOnHand,
        reorderLevel: Math.max(10, Math.round(baseDaily * 7)),
        consumptionSeries,
        lastMovementAt: now.toISOString(),
        updatedAt: now.toISOString(),
      });

      logAudit({
        entityType: 'STOCK',
        entityId: `STK-${facility.id}-${medicine.id}`,
        facilityId: facility.id,
        action: 'SEED',
        at: now.toISOString(),
        after: { units: totalOnHand },
        reason: 'Demo dataset initialisation',
      });
    }

    // One worked example of a manual adjustment in the audit trail.
    logAudit({
      entityType: 'STOCK',
      entityId: `STK-${facility.id}-MED-ORS`,
      facilityId: facility.id,
      action: 'ADJUST',
      actor: 'seed:pharmacist',
      at: addDays(now, -2).toISOString(),
      before: { units: 300 },
      after: { units: 500 },
      reason: ADJUSTMENT_REASONS.RECEIPT,
    });
  }

  const { footfall, tokens, counters } = generateQueue({ facilities: SERVICE_FACILITIES, today, todayKey, days, seedKey });
  const { wards, doctors, attendance, rosters, leaves } = generateStaffAndBeds({
    facilities: SERVICE_FACILITIES,
    today,
    todayKey,
    days,
    seedKey,
    random,
  });

  const indents = generateIndents({ facilities: SERVICE_FACILITIES, stock, now, random });
  const transfers = generateTransfers({ facilities: SERVICE_FACILITIES, batches, now, random });
  const referrals = generateReferrals({ facilities: SERVICE_FACILITIES, wards, now, random });

  return {
    facilities,
    medicines,
    stock,
    batches,
    dispensing,
    footfall,
    tokens,
    counters,
    wards,
    doctors,
    attendance,
    rosters,
    leaves,
    indents,
    transfers,
    referrals,
    audit: audit.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))),
    meta: {
      seedKey,
      generatedAt: now.toISOString(),
      todayKey,
      historyDays: days,
      facilityCount: facilities.length,
      medicineCount: medicines.length,
      stockLineCount: stock.length,
      batchCount: batches.length,
      footfallRowCount: footfall.length,
      tokenCount: tokens.length,
      wardCount: wards.length,
      doctorCount: doctors.length,
      attendanceRowCount: attendance.length,
      indentCount: indents.length,
      transferCount: transfers.length,
      referralCount: referrals.length,
      auditCount: audit.length,
      note: 'Synthetic data. Aggregate counts and anonymous tokens only - no patient PII.',
    },
  };
}

/**
 * Assign a target days-of-cover so the district shows a realistic spread of
 * RED / AMBER / GREEN / EXPIRY_RISK lines without any manual data entry.
 *
 * The bucket is derived from a hash of both ids: keying off id *length* alone
 * would put every medicine in a facility into the same band, which is what a
 * real district never looks like.
 *
 * @param {string} facilityId
 * @param {string} medicineId
 * @param {ReturnType<typeof createRandom>} random
 * @returns {number}
 */
function chooseTargetCover(facilityId, medicineId, random) {
  const bucket = hashString(`${facilityId}|${medicineId}`) % 10;
  if (bucket === 0) return 0; // complete stock-out
  if (bucket <= 2) return round(0.5 + random.float() * 2, 1); // RED: under 3 days
  if (bucket <= 4) return round(3.5 + random.float() * 3, 1); // AMBER: 3-7 days
  if (bucket === 5) return round(8 + random.float() * 4, 1); // healthy but thin
  return round(14 + random.float() * 45, 1); // GREEN
}

/**
 * Pick a batch expiry offset (days from today), sometimes inside the
 * near-expiry window so expiry-risk redistribution has something to move.
 *
 * @param {number} targetCover
 * @param {number} index
 * @param {ReturnType<typeof createRandom>} random
 * @returns {number}
 */
function chooseExpiryOffset(targetCover, index, random) {
  if (targetCover <= 2 && index === 0) return random.int(-12, 25); // expiry-risk / expired demo
  if (random.chance(0.18)) return random.int(5, 55); // near expiry
  return random.int(120, 640);
}

/**
 * Hourly footfall history + today's live tokens and counters.
 *
 * @param {object} input
 * @returns {{footfall: object[], tokens: object[], counters: object[]}}
 */
function generateQueue({ facilities, today, todayKey, days, seedKey }) {
  const footfall = [];
  const tokens = [];
  const counters = [];

  for (const facility of facilities) {
    const facilityRandom = createRandom(`${seedKey}:queue:${facility.id}`);
    const departmentCount = facility.type === FACILITY_TYPES.CHC ? 5 : 3;
    const departments = DEPARTMENTS.slice(0, departmentCount);
    const dailyBase = Math.round(40 * facility.loadFactor * (facility.type === FACILITY_TYPES.CHC ? 2.2 : 1));

    for (const counterIndex of Array.from({ length: facility.opdCounters }, (_unused, index) => index + 1)) {
      counters.push({
        id: `CTR-${facility.id}-${counterIndex}`,
        facilityId: facility.id,
        counterId: counterIndex,
        department: departments[(counterIndex - 1) % departments.length],
        isOpen: counterIndex <= Math.max(1, facility.opdCounters - 1),
        updatedAt: new Date().toISOString(),
      });
    }

    for (let offset = days - 1; offset >= 0; offset -= 1) {
      const date = dayKey(addDays(today, -offset));
      const weekday = toDate(`${date}T00:00:00Z`).getUTCDay();
      const dayTotal = Math.round(dailyBase * (WEEKDAY_LOAD[weekday] ?? 1) * (0.85 + facilityRandom.float() * 0.35));
      const shapeSum = HOUR_SHAPE.reduce((total, weight) => total + weight, 0) || 1;

      for (const [hour, weight] of HOUR_SHAPE.entries()) {
        if (weight === 0) continue;
        for (const department of departments) {
          const share = 1 / departments.length;
          const count = Math.max(0, Math.round((dayTotal * weight * share) / shapeSum));
          footfall.push({ facilityId: facility.id, department, date, weekday, hour, count });
        }
      }
    }

    // Today's live tokens: served earlier in the day, a few still waiting.
    const todaySoFar = Math.round(dailyBase * 0.6);
    let served = 0;
    let waiting = 0;
    for (let index = 0; index < todaySoFar; index += 1) {
      const department = departments[index % departments.length];
      const prefix = departmentPrefix(department);
      const issuedAt = addMinutes(today, 9 * 60 + Math.floor((index / Math.max(1, todaySoFar)) * 300));
      const isWaiting = index >= todaySoFar - 6;
      const serviceMinutes = 5 + Math.floor(facilityRandom.gaussian(6, 2.5));
      const servedAt = isWaiting ? null : addMinutes(issuedAt, Math.max(3, serviceMinutes));
      if (isWaiting) waiting += 1;
      else served += 1;

      tokens.push({
        id: `TOK-${facility.id}-${index + 1}`,
        facilityId: facility.id,
        department,
        token: `${prefix}-${String(index + 1).padStart(3, '0')}`,
        date: todayKey,
        hour: issuedAt.getUTCHours(),
        status: isWaiting ? 'WAITING' : 'SERVED',
        counterId: isWaiting ? null : (index % Math.max(1, facility.opdCounters)) + 1,
        issuedAt: issuedAt.toISOString(),
        servedAt: servedAt ? servedAt.toISOString() : null,
        waitMinutes: servedAt ? Math.max(1, Math.round((servedAt - issuedAt) / 60_000)) : null,
      });
    }

    // A couple of no-shows, which is what makes wait estimates honest.
    for (let index = 0; index < 3; index += 1) {
      const department = departments[index % departments.length];
      const issuedAt = addMinutes(today, 9 * 60 + index * 27);
      tokens.push({
        id: `TOK-${facility.id}-NS-${index + 1}`,
        facilityId: facility.id,
        department,
        token: `${departmentPrefix(department)}-9${index + 1}`,
        date: todayKey,
        hour: issuedAt.getUTCHours(),
        status: 'NO_SHOW',
        counterId: null,
        issuedAt: issuedAt.toISOString(),
        servedAt: null,
        waitMinutes: null,
      });
    }

    void served;
    void waiting;
  }

  return { footfall, tokens, counters };
}

/**
 * Wards, doctors, rosters, leaves and 30 days of attendance.
 *
 * @param {object} input
 * @returns {{wards: object[], doctors: object[], attendance: object[], rosters: object[], leaves: object[]}}
 */
function generateStaffAndBeds({ facilities, today, days, seedKey, random }) {
  const wards = [];
  const doctors = [];
  const attendance = [];
  const rosters = [];
  const leaves = [];

  for (const facility of facilities) {
    const facilityRandom = createRandom(`${seedKey}:staff:${facility.id}`);

    facility.wards.forEach((ward, index) => {
      const occupied = Math.min(ward.total, Math.round(ward.total * (0.35 + facilityRandom.float() * 0.6)));
      const reserved = Math.min(ward.total - occupied, facilityRandom.int(0, 2));
      wards.push({
        id: `WRD-${facility.id}-${index + 1}`,
        facilityId: facility.id,
        name: ward.name,
        total: ward.total,
        occupied,
        reserved,
        updatedAt: new Date().toISOString(),
      });
    });

    for (const [index, doctor] of facility.doctors.entries()) {
      // Sunday is a light duty day: the first doctor of each facility covers
      // it and everyone else is off. Modelling Sunday as fully closed would
      // make the attendance feature look broken every weekend.
      const isFirstDoctor = index === 0;
      doctors.push({
        id: doctor.id,
        facilityId: facility.id,
        name: doctor.name,
        department: doctor.department,
        alertTime: ATTENDANCE.DEFAULT_ALERT_TIME,
        active: true,
      });

      // Reliability profile: one doctor per facility is deliberately unreliable
      // so the attendance risk feature is visible in the demo.
      const unreliable = doctor.id.endsWith('-1') && facilityRandom.chance(0.6);
      const presentProbability = unreliable ? 0.68 : 0.93;

      for (let offset = Math.min(days, 30) - 1; offset >= 0; offset -= 1) {
        const date = dayKey(addDays(today, -offset));
        const weekday = toDate(`${date}T00:00:00Z`).getUTCDay();
        const isSunday = weekday === 0;
        const onRoster = !isSunday || isFirstDoctor;
        if (!onRoster) {
          rosters.push({ id: `ROS-${doctor.id}-${date}`, doctorId: doctor.id, facilityId: facility.id, date, shift: 'OFF', department: doctor.department });
          continue;
        }

        rosters.push({
          id: `ROS-${doctor.id}-${date}`,
          doctorId: doctor.id,
          facilityId: facility.id,
          date,
          shift: 'DAY',
          shiftStart: '09:00',
          shiftEnd: '16:00',
          department: doctor.department,
        });

        const onLeave = facilityRandom.chance(0.05);
        if (onLeave) {
          leaves.push({
            id: `LV-${doctor.id}-${date}`,
            doctorId: doctor.id,
            facilityId: facility.id,
            date,
            type: facilityRandom.pick(['CASUAL', 'MEDICAL', 'TRAINING']),
            approvedBy: 'chc_admin',
            approvedAt: addDays(today, -offset - 1).toISOString(),
            note: 'Approved leave (synthetic)',
          });
          attendance.push({
            id: `ATT-${doctor.id}-${date}`,
            doctorId: doctor.id,
            facilityId: facility.id,
            date,
            checkInAt: null,
            checkOutAt: null,
            onLeave: true,
            leaveType: 'CASUAL',
          });
          continue;
        }

        const present = offset === 0 ? unreliable ? facilityRandom.chance(0.7) : true : facilityRandom.chance(presentProbability);
        if (!present) {
          attendance.push({
            id: `ATT-${doctor.id}-${date}`,
            doctorId: doctor.id,
            facilityId: facility.id,
            date,
            checkInAt: null,
            checkOutAt: null,
            onLeave: false,
            late: false,
          });
          continue;
        }

        const lateMinutes = facilityRandom.chance(0.25) ? facilityRandom.int(6, 55) : -facilityRandom.int(2, 25);
        const checkIn = addMinutes(addDays(today, -offset), 9 * 60 + 30 + lateMinutes);
        const checkOut = offset === 0 ? null : addMinutes(checkIn, facilityRandom.int(360, 430));
        attendance.push({
          id: `ATT-${doctor.id}-${date}`,
          doctorId: doctor.id,
          facilityId: facility.id,
          date,
          checkInAt: checkIn.toISOString(),
          checkOutAt: checkOut ? checkOut.toISOString() : null,
          onLeave: false,
          late: lateMinutes > 15,
        });
      }
    }
  }

  void random;
  return { wards, doctors, attendance, rosters, leaves };
}

/**
 * A small set of indents in different workflow states.
 *
 * @param {object} input
 * @returns {object[]}
 */
function generateIndents({ facilities, stock, now, random }) {
  const indents = [];
  const lowStock = stock
    .map((line) => ({ ...line, perDay: averageOf(line.consumptionSeries) }))
    .filter((line) => line.perDay > 0 && line.units / line.perDay < 7)
    .sort((a, b) => a.units / a.perDay - b.units / b.perDay)
    .slice(0, 12);

  lowStock.forEach((line, index) => {
    const facility = facilities.find((entry) => entry.id === line.facilityId);
    const status = index < 4 ? INDENT_STATUS.REQUESTED : index < 8 ? INDENT_STATUS.APPROVED : INDENT_STATUS.DISPATCHED;
    const units = Math.ceil(line.perDay * 21 - line.units);
    indents.push({
      id: `IND-${1000 + index}`,
      facilityId: line.facilityId,
      facilityName: facility?.name ?? line.facilityId,
      status,
      source: 'AUTO',
      priority: line.units / line.perDay < 3 ? 'CRITICAL' : 'HIGH',
      items: [
        {
          medicineId: line.medicineId,
          medicineName: MEDICINES.find((medicine) => medicine.id === line.medicineId)?.name ?? line.medicineId,
          currentStock: line.units,
          forecastPerDay: round(line.perDay, 2),
          daysOfCover: round(line.units / line.perDay, 1),
          units: Math.max(10, units),
          priority: line.units / line.perDay < 3 ? 'CRITICAL' : 'HIGH',
        },
      ],
      totalItems: 1,
      totalUnits: Math.max(10, units),
      requestedBy: 'system:auto-indent',
      requestedAt: addDays(now, -index % 5).toISOString(),
      history: [{ status: INDENT_STATUS.REQUESTED, at: addDays(now, -index % 5).toISOString(), by: 'system:auto-indent', note: 'Auto-raised below 7 days of cover.' }],
    });
  });

  void random;
  return indents;
}

/**
 * One suggested transfer that is already in flight, to demo the workflow.
 *
 * @param {object} input
 * @returns {object[]}
 */
function generateTransfers({ facilities, batches, now, random }) {
  const transfers = [];
  const donor = facilities.find((facility) => facility.type === FACILITY_TYPES.CHC);
  const recipient = facilities.find((facility) => facility.type === FACILITY_TYPES.PHC);
  const batch = batches.find(
    (entry) => entry.facilityId === donor?.id && entry.medicineId === 'MED-ORS' && entry.quantity > 50,
  );
  if (!donor || !recipient || !batch) return transfers;

  transfers.push({
    id: 'TRF-1001',
    fromFacilityId: donor.id,
    toFacilityId: recipient.id,
    medicineId: batch.medicineId,
    batchId: batch.id,
    units: 100,
    reason: 'SURPLUS_TO_DEFICIT',
    status: TRANSFER_STATUS.APPROVED,
    distanceKm: 12.4,
    requestedAt: addDays(now, -1).toISOString(),
    requestedBy: 'system:transfer-engine',
    history: [
      { status: TRANSFER_STATUS.REQUESTED, at: addDays(now, -1).toISOString(), by: 'system:transfer-engine', note: 'Nearest donor with >21 days of cover.' },
      { status: TRANSFER_STATUS.APPROVED, at: addDays(now, -1).toISOString(), by: 'district_officer', note: 'Approved for same-day dispatch.' },
    ],
  });

  void random;
  return transfers;
}

/**
 * A referral request that shows the CHC's live bed availability.
 *
 * @param {object} input
 * @returns {object[]}
 */
function generateReferrals({ facilities, wards, now, random }) {
  const referrals = [];
  const from = facilities.find((facility) => facility.type === FACILITY_TYPES.PHC);
  const to = facilities.find((facility) => facility.type === FACILITY_TYPES.CHC);
  if (!from || !to) return referrals;

  const ward = wards.find((entry) => entry.facilityId === to.id);
  referrals.push({
    id: 'REF-2001',
    fromFacilityId: from.id,
    toFacilityId: to.id,
    patientToken: 'R-014',
    category: 'MATERNITY',
    urgency: 'URGENT',
    needsBed: true,
    status: REFERRAL_STATUS.REQUESTED,
    wardId: ward?.id ?? null,
    bedsAvailableAtRequest: ward ? Math.max(0, ward.total - ward.occupied - ward.reserved) : 0,
    note: 'Synthetic referral for demo. Anonymous token only.',
    createdAt: addDays(now, -0.2).toISOString(),
    history: [
      { status: REFERRAL_STATUS.REQUESTED, at: addDays(now, -0.2).toISOString(), by: 'facility_staff', note: 'Requested bed at CHC.' },
    ],
  });

  void random;
  return referrals;
}

/**
 * Mean of a consumption series.
 *
 * @param {{quantity: number}[]} series
 * @returns {number}
 */
function averageOf(series) {
  if (!series?.length) return 0;
  return series.reduce((total, entry) => total + entry.quantity, 0) / series.length;
}

/**
 * One-letter anonymous token prefix per department.
 *
 * @param {string} department
 * @returns {string}
 */
function departmentPrefix(department) {
  const map = {
    OPD_GENERAL: 'A',
    OPD_ANC: 'M',
    OPD_CHILD: 'C',
    IMMUNISATION: 'I',
    NCD_CLINIC: 'N',
    EMERGENCY: 'E',
  };
  return map[department] ?? 'X';
}

export { WEEKDAY_LOAD, HOUR_SHAPE, departmentPrefix };
