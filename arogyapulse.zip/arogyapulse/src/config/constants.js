/**
 * Domain-wide constants, thresholds and enumerations for ArogyaPulse.
 *
 * Every tunable number that the product rules depend on lives here so that
 * the pure services stay free of magic numbers and so that a district can
 * re-tune the policy without touching business logic.
 *
 * @module config/constants
 */

/** Application role identifiers, ordered from most to least privileged. */
export const ROLES = Object.freeze({
  DISTRICT_OFFICER: 'district_officer',
  CHC_ADMIN: 'chc_admin',
  FACILITY_STAFF: 'facility_staff',
  PUBLIC: 'public',
});

/** All roles, ordered by privilege (index 0 = highest). */
export const ROLE_HIERARCHY = Object.freeze([
  ROLES.DISTRICT_OFFICER,
  ROLES.CHC_ADMIN,
  ROLES.FACILITY_STAFF,
  ROLES.PUBLIC,
]);

/** Facility categories. */
export const FACILITY_TYPES = Object.freeze({
  PHC: 'PHC',
  CHC: 'CHC',
  DISTRICT_STORE: 'DISTRICT_STORE',
});

/** Stock-out forecast status buckets (icon + text is always shown with colour). */
export const STOCK_STATUS = Object.freeze({
  RED: 'RED',
  AMBER: 'AMBER',
  GREEN: 'GREEN',
  EXPIRY_RISK: 'EXPIRY_RISK',
});

/** Forecast thresholds, expressed in days of cover. */
export const FORECAST = Object.freeze({
  RED_DAYS: 3,
  AMBER_DAYS: 7,
  /** Weighted moving average window, in days. */
  WINDOW_DAYS: 7,
  /** Weights applied to the daily consumption series, oldest -> newest. */
  WEIGHTS: Object.freeze([1, 1, 1.5, 1.5, 2, 2, 3]),
  /** If a forecast value is below this, treat consumption as negligible. */
  MIN_FORECAST: 0.01,
});

/** Batch / expiry policy. */
export const EXPIRY = Object.freeze({
  /** Batches expiring within this many days are "near expiry". */
  NEAR_EXPIRY_DAYS: 60,
  /** Share of stock that must be near expiry before the item is flagged. */
  EXPIRY_RISK_SHARE: 0.3,
  /** Shelf life assumed when a batch has no printed expiry (days). */
  DEFAULT_SHELF_LIFE_DAYS: 365,
});

/** Indent (requisition) policy. */
export const INDENT = Object.freeze({
  /** Auto-raise an indent when days-of-cover drops below this. */
  AUTO_TRIGGER_DAYS: 7,
  /** Days of supply to reach after the indent is fulfilled. */
  TARGET_DAYS_OF_COVER: 21,
  /** Assumed lead time from the district drug store, in days. */
  LEAD_TIME_DAYS: 3,
  /** Safety margin on top of lead time, in days. */
  SAFETY_DAYS: 2,
});

/** Transfer matching policy. */
export const TRANSFER = Object.freeze({
  /** Donor must have at least this many days of cover after donating. */
  DONOR_MIN_DAYS_OF_COVER: 21,
  /** Recipient must have fewer than this many days of cover to qualify. */
  RECIPIENT_MAX_DAYS_OF_COVER: 10,
  /** Days of cover the recipient is topped up to. */
  TARGET_DAYS_OF_COVER: 7,
  /** Never move fewer units than this (not worth a vehicle trip). */
  MIN_UNITS: 20,
  /** Cap a single transfer at this share of the donor's available stock. */
  MAX_SHARE_OF_DONOR: 0.4,
  /** Ignore donors further away than this (km). */
  MAX_DISTANCE_KM: 120,
  /** Batches expiring within this window are eligible for expiry-risk moves. */
  EXPIRY_RISK_DAYS: 90,
});

/** OPD queue policy. */
export const QUEUE = Object.freeze({
  /** Fallback average consultation time when no history exists (minutes). */
  DEFAULT_SERVICE_MINUTES: 8,
  /** Historical window used for peak-hour prediction (days). */
  HISTORY_DAYS: 14,
  /** Hours of the OPD day used for charts. */
  OPD_START_HOUR: 8,
  OPD_END_HOUR: 20,
  /** Wait bands used by the public "how crowded is it now" page. */
  LOAD_BANDS: Object.freeze([
    { id: 'LOW', maxWaitMinutes: 15 },
    { id: 'MODERATE', maxWaitMinutes: 45 },
  ]),
});

/** Bed management policy. */
export const BEDS = Object.freeze({
  RESERVED_SHARE_ALERT: 0.25,
});

/** Attendance policy. */
export const ATTENDANCE = Object.freeze({
  /** Default alert time if a facility has not configured one ("HH:mm"). */
  DEFAULT_ALERT_TIME: '09:30',
  /** Days of history used for the reliability percentage. */
  WINDOW_DAYS: 30,
  /** Reliability below this percentage is reported as a risk. */
  LOW_RELIABILITY_PERCENT: 80,
  /** A check-in later than this many minutes after shift start is "late". */
  LATE_GRACE_MINUTES: 15,
});

/** Referral workflow states (PHC -> CHC). */
export const REFERRAL_STATUS = Object.freeze({
  REQUESTED: 'REQUESTED',
  ACCEPTED: 'ACCEPTED',
  REJECTED: 'REJECTED',
  TRANSFERRED: 'TRANSFERRED',
  CLOSED: 'CLOSED',
});

/** Indent workflow states. */
export const INDENT_STATUS = Object.freeze({
  REQUESTED: 'REQUESTED',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED',
  DISPATCHED: 'DISPATCHED',
  RECEIVED: 'RECEIVED',
  CANCELLED: 'CANCELLED',
});

/** Transfer workflow states. */
export const TRANSFER_STATUS = Object.freeze({
  REQUESTED: 'REQUESTED',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED',
  DISPATCHED: 'DISPATCHED',
  RECEIVED: 'RECEIVED',
  CANCELLED: 'CANCELLED',
});

/** Allowed forward transitions for each workflow, used by the state machine. */
export const WORKFLOW_TRANSITIONS = Object.freeze({
  indent: Object.freeze({
    REQUESTED: Object.freeze(['APPROVED', 'REJECTED', 'CANCELLED']),
    APPROVED: Object.freeze(['DISPATCHED', 'CANCELLED']),
    DISPATCHED: Object.freeze(['RECEIVED']),
    RECEIVED: Object.freeze([]),
    REJECTED: Object.freeze([]),
    CANCELLED: Object.freeze([]),
  }),
  transfer: Object.freeze({
    REQUESTED: Object.freeze(['APPROVED', 'REJECTED', 'CANCELLED']),
    APPROVED: Object.freeze(['DISPATCHED', 'CANCELLED']),
    DISPATCHED: Object.freeze(['RECEIVED']),
    RECEIVED: Object.freeze([]),
    REJECTED: Object.freeze([]),
    CANCELLED: Object.freeze([]),
  }),
});

/** Reasons accepted for a manual stock adjustment (audit friendly). */
export const ADJUSTMENT_REASONS = Object.freeze([
  'RECEIPT',
  'RETURN',
  'DAMAGE',
  'EXPIRY_WRITE_OFF',
  'THEFT_LOSS',
  'COUNT_CORRECTION',
  'OTHER',
]);

/** OPD departments tracked for footfall. */
export const DEPARTMENTS = Object.freeze([
  'OPD_GENERAL',
  'OPD_ANC',
  'OPD_CHILD',
  'IMMUNISATION',
  'NCD_CLINIC',
  'EMERGENCY',
]);

/** Reasons a seeded stock movement can carry. */
export const MOVEMENT_REASONS = Object.freeze([
  'DISPENSING',
  'RECEIPT',
  'TRANSFER_IN',
  'TRANSFER_OUT',
  'INDENT_IN',
  'ADJUSTMENT',
  'EXPIRY_WRITE_OFF',
]);

/** Default district used by the seed data (Ahmednagar, Maharashtra). */
export const DEFAULT_DISTRICT = Object.freeze({
  id: 'DIST-AHN',
  name: 'Ahmednagar',
  state: 'Maharashtra',
});

/** Page size limits for list endpoints. */
export const PAGINATION = Object.freeze({
  DEFAULT_LIMIT: 25,
  MAX_LIMIT: 100,
});

/** Cache TTLs, in milliseconds. */
export const CACHE_TTL_MS = Object.freeze({
  DASHBOARD: 20_000,
  DISTRICT: 30_000,
  PUBLIC: 15_000,
  FORECAST: 60_000,
  AI_BRIEFING: 300_000,
  AI_ANSWER: 120_000,
});

/** HTTP body limits. */
export const BODY_LIMITS = Object.freeze({
  JSON: '64kb',
  TEXT: '16kb',
});

/** Supported UI languages. */
export const LANGUAGES = Object.freeze(['en', 'hi']);
export const DEFAULT_LANGUAGE = 'en';
