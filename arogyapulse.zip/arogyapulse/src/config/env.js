import { z } from 'zod';

/**
 * Environment configuration.
 *
 * The application is designed to boot with ZERO configuration: every value
 * below has a working default, which gives an in-memory repository, seeded
 * demo data and rule-based ("basic mode") AI. Real Google Cloud credentials
 * only *enhance* the deployment.
 *
 * @module config/env
 */

const booleanish = z
  .enum(['true', 'false', '1', '0', 'yes', 'no'])
  .transform((value) => value === 'true' || value === '1' || value === 'yes');

const intOr = (fallback) =>
  z.coerce
    .number()
    .int()
    .min(0)
    .optional()
    .transform((value) => (Number.isFinite(value) ? value : fallback));

/** Raw process.env schema. Unknown keys are stripped, never rejected. */
export const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: intOr(8080),
  HOST: z.string().min(1).default('0.0.0.0'),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error', 'silent']).default('info'),

  /** 'firestore' or 'memory'. Defaults to firestore only when a project id exists. */
  REPOSITORY: z.enum(['firestore', 'memory']).optional(),
  GOOGLE_CLOUD_PROJECT: z.string().min(1).optional(),
  FIRESTORE_EMULATOR_HOST: z.string().min(1).optional(),

  /** Gemini. */
  GEMINI_API_KEY: z.string().min(8).optional(),
  GEMINI_MODEL: z.string().min(1).default('gemini-2.5-flash'),
  GEMINI_TIMEOUT_MS: intOr(8000),
  GEMINI_MAX_RETRIES: intOr(1),

  /** Firebase Auth (ID token verification). Absent => DEMO_MODE. */
  FIREBASE_PROJECT_ID: z.string().min(1).optional(),

  /** Signed demo-mode session cookies. A dev default is used when unset. */
  SESSION_SECRET: z.string().min(16).default('arogyapulse-dev-only-secret-change-me'),
  COOKIE_NAME: z.string().min(1).default('ap_session'),
  SESSION_TTL_SECONDS: intOr(43_200),
  COOKIE_SECURE: booleanish.default('false'),

  /** CORS allowlist, comma separated. Empty => same-origin only. */
  CORS_ORIGINS: z
    .string()
    .default('')
    .transform((value) =>
      value
        .split(',')
        .map((entry) => entry.trim())
        .filter(Boolean),
    ),

  /** Rate limits (requests per window). */
  RATE_LIMIT_WINDOW_MS: intOr(60_000),
  RATE_LIMIT_MAX: intOr(300),
  RATE_LIMIT_AI_MAX: intOr(10),

  /** Data seeding. */
  SEED_ON_BOOT: booleanish.default('true'),
  SEED_DAYS: intOr(45),

  /** Attendance alert default ("HH:mm", 24h, IST). */
  ATTENDANCE_ALERT_TIME: z
    .string()
    .regex(/^([01]\d|2[0-3]):[0-5]\d$/)
    .default('09:30'),

  /** IANA timezone used for all date bucketing. */
  TZ: z.string().min(1).default('Asia/Kolkata'),
});

/** Result of parsing the environment; safe to read synchronously. */
export const rawEnv = { ...process.env };

const parsed = envSchema.safeParse(rawEnv);

if (!parsed.success) {
  // Fail fast and loudly: a bad PORT is worse than a crash at boot.
  const issues = parsed.error.issues
    .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
    .join('; ');
  throw new Error(`Invalid environment configuration -> ${issues}`);
}

/**
 * @typedef {Object} AppConfig
 * @property {'development'|'test'|'production'} nodeEnv
 * @property {number} port
 * @property {string} host
 * @property {string} logLevel
 * @property {'firestore'|'memory'} repository
 * @property {string|undefined} googleCloudProject
 * @property {{model: string, apiKey: string|undefined, timeoutMs: number, maxRetries: number, enabled: boolean}} gemini
 * @property {boolean} firebaseAuthEnabled
 * @property {string} sessionSecret
 * @property {string} cookieName
 * @property {number} sessionTtlSeconds
 * @property {boolean} cookieSecure
 * @property {string[]} corsOrigins
 * @property {{windowMs: number, max: number, aiMax: number}} rateLimit
 * @property {boolean} seedOnBoot
 * @property {number} seedDays
 * @property {string} attendanceAlertTime
 * @property {string} tz
 * @property {boolean} isProduction
 * @property {boolean} demoMode
 */

/**
 * The resolved, normalised application configuration.
 *
 * @type {AppConfig}
 */
export const config = Object.freeze({
  nodeEnv: parsed.data.NODE_ENV,
  port: parsed.data.PORT,
  host: parsed.data.HOST,
  logLevel: parsed.data.LOG_LEVEL,

  repository:
    parsed.data.REPOSITORY ??
    (parsed.data.GOOGLE_CLOUD_PROJECT || parsed.data.FIRESTORE_EMULATOR_HOST
      ? 'firestore'
      : 'memory'),
  googleCloudProject: parsed.data.GOOGLE_CLOUD_PROJECT,

  gemini: Object.freeze({
    model: parsed.data.GEMINI_MODEL,
    apiKey: parsed.data.GEMINI_API_KEY,
    timeoutMs: parsed.data.GEMINI_TIMEOUT_MS,
    maxRetries: parsed.data.GEMINI_MAX_RETRIES,
    enabled: Boolean(parsed.data.GEMINI_API_KEY),
  }),

  firebaseAuthEnabled: Boolean(parsed.data.FIREBASE_PROJECT_ID),
  sessionSecret: parsed.data.SESSION_SECRET,
  cookieName: parsed.data.COOKIE_NAME,
  sessionTtlSeconds: parsed.data.SESSION_TTL_SECONDS,
  cookieSecure: parsed.data.COOKIE_SECURE,

  corsOrigins: parsed.data.CORS_ORIGINS,
  rateLimit: Object.freeze({
    windowMs: parsed.data.RATE_LIMIT_WINDOW_MS,
    max: parsed.data.RATE_LIMIT_MAX,
    aiMax: parsed.data.RATE_LIMIT_AI_MAX,
  }),

  seedOnBoot: parsed.data.SEED_ON_BOOT,
  seedDays: parsed.data.SEED_DAYS,
  attendanceAlertTime: parsed.data.ATTENDANCE_ALERT_TIME,
  tz: parsed.data.TZ,

  isProduction: parsed.data.NODE_ENV === 'production',
  demoMode: !parsed.data.FIREBASE_PROJECT_ID,
});

export default config;
