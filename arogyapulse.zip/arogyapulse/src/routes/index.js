/**
 * API router.
 *
 * Every route declares, in order: RBAC -> validation -> controller. Reading
 * this file top to bottom is a complete statement of the API's trust model.
 *
 * @module routes
 */

import { Router } from 'express';

import { aiRateLimiter, validate } from '../middleware/security.js';
import { requirePermission } from '../middleware/requirePermission.js';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import * as authController from '../controllers/authController.js';
import * as facilityController from '../controllers/facilityController.js';
import * as supplyChainController from '../controllers/supplyChainController.js';
import * as aiController from '../controllers/aiController.js';
import { replay } from '../controllers/offlineController.js';
import { attendanceBoard } from '../services/attendanceService.js';
import { sendJson, sendPage } from '../controllers/respond.js';
import {
  askSchema,
  attendanceSchema,
  auditQuerySchema,
  bedUpdateSchema,
  briefingSchema,
  counterSchema,
  dispensingSchema,
  doctorListSchema,
  facilityListSchema,
  facilityQuerySchema,
  footfallQuerySchema,
  idParamSchema,
  indentSchema,
  indentStatusSchema,
  leaveSchema,
  loginSchema,
  medicineListSchema,
  nlConfirmSchema,
  nlEntrySchema,
  offlineBatchSchema,
  paginationSchema,
  publicQuerySchema,
  referralSchema,
  referralStatusSchema,
  stockAdjustSchema,
  stockListSchema,
  tokenIssueSchema,
  tokenServeSchema,
  transferSchema,
  transferStatusSchema,
  wardSchema,
} from '../validators/index.js';

/**
 * GET /api/doctors - doctor list with today's status and 30-day reliability.
 *
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @returns {Promise<void>}
 */
async function listDoctors(req, res) {
  const board = await attendanceBoard(req.repository, req.query.facilityId);
  const page = await req.repository.listDoctors(
    { facilityId: req.query.facilityId, department: req.query.department },
    { limit: req.query.limit, offset: req.query.offset },
  );

  const items = page.items.map((doctor) => {
    const entry = board.entries.find((candidate) => candidate.doctorId === doctor.id) ?? {};
    return {
      ...doctor,
      status: entry.status ?? 'UNKNOWN',
      checkInAt: entry.checkInAt ?? null,
      onLeave: Boolean(entry.onLeave),
      reliabilityPercent: entry.reliabilityPercent ?? null,
      reliabilityRating: entry.reliabilityRating ?? null,
      alert: Boolean(entry.alert),
    };
  });

  sendJson(req, res, sendPage({ ...page, items }, { summary: board.summary }));
}

/**
 * Build the API router.
 *
 * @param {object} [options]
 * @param {boolean} [options.enableRateLimit] - Off during tests unless asked.
 * @returns {import('express').Router}
 */
export function createApiRouter(options = {}) {
  const router = Router();

  // ---------------------------------------------------------------- auth
  router.post('/auth/login', validate('body', loginSchema, 'auth.login'), authController.login);
  router.post('/auth/logout', authController.logout);
  router.get('/auth/me', authController.me);

  // ------------------------------------------------------- public (no auth)
  router.get('/public/summary', validate('query', publicQuerySchema), facilityController.publicSummary);
  router.get(
    '/public/crowding',
    validate('query', facilityQuerySchema),
    facilityController.publicCrowdingController,
  );

  // ------------------------------------------------------- reference reads
  router.get(
    '/facilities',
    requirePermission('facility:read'),
    validate('query', facilityListSchema),
    facilityController.listFacilities,
  );
  router.get(
    '/facilities/:id',
    requirePermission('facility:read'),
    validate('params', idParamSchema),
    facilityController.getFacility,
  );
  router.get(
    '/medicines',
    requirePermission('medicine:read'),
    validate('query', medicineListSchema),
    facilityController.listMedicines,
  );
  router.get(
    '/doctors',
    requirePermission('attendance:read'),
    validate('query', doctorListSchema),
    asyncHandler(listDoctors),
  );

  // ------------------------------------------------------------- stock
  router.get(
    '/stock',
    requirePermission('stock:read'),
    validate('query', stockListSchema),
    facilityController.listStock,
  );
  router.get(
    '/stock/expiry',
    requirePermission('stock:read'),
    validate('query', facilityQuerySchema),
    facilityController.expiry,
  );
  router.post(
    '/stock/adjust',
    requirePermission('stock:adjust'),
    validate('body', stockAdjustSchema, 'stock.adjust'),
    facilityController.stockAdjust,
  );
  router.post(
    '/dispensing',
    requirePermission('stock:dispense'),
    validate('body', dispensingSchema, 'dispensing'),
    facilityController.dispensing,
  );

  // ------------------------------------------------------------- queue
  router.get(
    '/queue',
    requirePermission('queue:read'),
    validate('query', facilityQuerySchema),
    facilityController.queue,
  );
  router.get(
    '/tokens',
    requirePermission('queue:read'),
    validate('query', facilityQuerySchema, 'tokens'),
    facilityController.tokenList,
  );
  router.post(
    '/tokens',
    requirePermission('token:issue'),
    validate('body', tokenIssueSchema, 'token.issue'),
    facilityController.tokenIssue,
  );
  router.post(
    '/tokens/:id/serve',
    requirePermission('token:serve'),
    validate('params', idParamSchema),
    validate('body', tokenServeSchema, 'token.serve'),
    facilityController.tokenServe,
  );
  router.post(
    '/counters',
    requirePermission('counter:manage'),
    validate('body', counterSchema, 'counter'),
    facilityController.counterSet,
  );
  router.get(
    '/footfall',
    requirePermission('queue:read'),
    validate('query', footfallQuerySchema),
    facilityController.footfall,
  );

  // -------------------------------------------------------------- beds
  router.get(
    '/beds',
    requirePermission('bed:read'),
    validate('query', facilityQuerySchema),
    facilityController.beds,
  );
  router.post(
    '/beds/:wardId/update',
    requirePermission('bed:update'),
    validate('body', bedUpdateSchema, 'bed.update'),
    facilityController.bedUpdate,
  );
  router.put(
    '/wards/:id',
    requirePermission('ward:manage'),
    validate('params', idParamSchema),
    validate('body', wardSchema, 'ward'),
    facilityController.wardUpsert,
  );

  // -------------------------------------------------------- attendance
  router.get(
    '/attendance',
    requirePermission('attendance:read'),
    validate('query', facilityQuerySchema),
    facilityController.attendance,
  );
  router.post(
    '/attendance/check-in',
    requirePermission('attendance:record'),
    validate('body', attendanceSchema, 'attendance.checkIn'),
    facilityController.attendanceCheckIn,
  );
  router.post(
    '/attendance/check-out',
    requirePermission('attendance:record'),
    validate('body', attendanceSchema, 'attendance.checkOut'),
    facilityController.attendanceCheckOut,
  );
  router.post(
    '/leaves',
    requirePermission('leave:record'),
    validate('body', leaveSchema, 'leave'),
    facilityController.leaveCreate,
  );

  // -------------------------------------------------------- dashboards
  router.get('/dashboard/facility', requirePermission('dashboard:read'), facilityController.facility);
  router.get('/dashboard/district', requirePermission('district:read'), facilityController.district);
  router.get(
    '/audit',
    requirePermission('audit:read'),
    validate('query', auditQuerySchema),
    facilityController.audit,
  );
  router.get(
    '/alerts',
    requirePermission('dashboard:read'),
    validate('query', paginationSchema),
    supplyChainController.listAlerts,
  );
  router.post(
    '/alerts/:id/acknowledge',
    requirePermission('alert:acknowledge'),
    validate('params', idParamSchema),
    supplyChainController.acknowledgeAlert,
  );

  // ------------------------------------------------------ supply chain
  router.get(
    '/indents',
    requirePermission('dashboard:read'),
    validate('query', paginationSchema),
    supplyChainController.listIndents,
  );
  router.post(
    '/indents',
    requirePermission('indent:create'),
    validate('body', indentSchema, 'indent'),
    supplyChainController.indentCreate,
  );
  router.post(
    '/indents/:id/status',
    requirePermission('indent:approve'),
    validate('params', idParamSchema),
    validate('body', indentStatusSchema, 'indent.status'),
    supplyChainController.indentStatus,
  );

  router.get(
    '/transfers',
    requirePermission('dashboard:read'),
    validate('query', paginationSchema),
    supplyChainController.listTransfers,
  );
  router.get('/transfers/suggestions', requirePermission('district:read'), supplyChainController.transferSuggest);
  router.post(
    '/transfers',
    requirePermission('transfer:create'),
    validate('body', transferSchema, 'transfer'),
    supplyChainController.transferCreate,
  );
  router.post(
    '/transfers/:id/status',
    requirePermission('transfer:approve'),
    validate('params', idParamSchema),
    validate('body', transferStatusSchema, 'transfer.status'),
    supplyChainController.transferStatus,
  );

  router.get(
    '/referrals',
    requirePermission('dashboard:read'),
    validate('query', paginationSchema),
    supplyChainController.listReferrals,
  );
  router.get('/referrals/options', requirePermission('referral:request'), supplyChainController.referralOptions);
  router.post(
    '/referrals',
    requirePermission('referral:request'),
    validate('body', referralSchema, 'referral'),
    supplyChainController.referralCreate,
  );
  router.post(
    '/referrals/:id/status',
    requirePermission('referral:decide'),
    validate('params', idParamSchema),
    validate('body', referralStatusSchema, 'referral.status'),
    supplyChainController.referralStatus,
  );

  // ------------------------------------------------------------- AI
  if (options.enableRateLimit) router.use('/ai', aiRateLimiter);
  router.get('/ai/status', aiController.status);
  router.post(
    '/ai/nl-entry',
    requirePermission('ai:nlp'),
    validate('body', nlEntrySchema, 'ai.nlEntry'),
    aiController.nlEntry,
  );
  router.post(
    '/ai/confirm',
    requirePermission('ai:nlp'),
    validate('body', nlConfirmSchema, 'ai.confirm'),
    aiController.nlConfirm,
  );
  router.post(
    '/ai/briefing',
    requireAuth(),
    requirePermission('ai:briefing'),
    validate('body', briefingSchema, 'ai.briefing'),
    aiController.briefing,
  );
  router.post(
    '/ai/ask',
    requireAuth(),
    requirePermission('ai:ask'),
    validate('body', askSchema, 'ai.ask'),
    aiController.ask,
  );

  // --------------------------------------------------------- offline
  router.post(
    '/offline/replay',
    requireAuth(),
    validate('body', offlineBatchSchema, 'offline.replay'),
    replay(router),
  );

  return router;
}

export default createApiRouter;
