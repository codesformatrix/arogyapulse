/**
 * Server entry point.
 *
 * Boots with zero configuration: in-memory repository, seeded demo data,
 * rule-based AI. Setting GOOGLE_CLOUD_PROJECT / GEMINI_API_KEY upgrades the
 * same code to Firestore and Gemini without any other change.
 *
 * @module server
 */

import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import compression from 'compression';
import cookieParser from 'cookie-parser';
import express from 'express';

import config from './config/env.js';
import { BODY_LIMITS } from './config/constants.js';
import { attachActor } from './middleware/auth.js';
import { attachRepository } from './middleware/attachRepository.js';
import { corsPolicy, securityHeaders } from './middleware/security.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import { createApiRouter } from './routes/index.js';
import { createRepository, getRepository, setRepository } from './repositories/index.js';
import { seed } from '../scripts/seed.mjs';
import { aiStatus } from './services/geminiService.js';
import { cacheStats } from './utils/caches.js';
import { createLogger } from './utils/logger.js';

const log = createLogger('server');
const startedAt = Date.now();
const moduleDir = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(moduleDir, 'public');

/**
 * Build the Express application.
 *
 * Exported so tests can drive the whole stack in-process with supertest.
 *
 * @param {object} [options]
 * @param {object} [options.repository] - Injected repository (tests).
 * @param {boolean} [options.enableRateLimit]
 * @param {boolean} [options.seedData] - Seed when the repository is empty.
 * @returns {Promise<import('express').Express>}
 */
export async function createApp(options = {}) {
  const repository = options.repository ?? (await getRepository());
  const app = express();

  // Cloud Run terminates TLS at its load balancer; trust exactly one hop so
  // rate limiting and secure cookies see the real client.
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.disable('etag'); // the API sets its own weak ETags

  app.use(securityHeaders());
  app.use(corsPolicy());
  app.use(compression());
  app.use(express.json({ limit: BODY_LIMITS.JSON }));
  app.use(express.text({ limit: BODY_LIMITS.TEXT }));
  app.use(cookieParser());
  app.use(attachRepository(repository));
  app.use(attachActor());

  // ------------------------------------------------------------- health
  app.get('/healthz', (_req, res) => {
    res.status(200).json({
      status: 'ok',
      uptimeSeconds: Math.round((Date.now() - startedAt) / 1000),
      repository: repository.kind,
      demoMode: config.demoMode,
      firebaseAuth: config.firebaseAuthEnabled,
      ai: aiStatus(),
      caches: cacheStats(),
      version: '1.0.0',
    });
  });

  // -------------------------------------------------------------- static
  // The PWA lives in src/public. When it is absent (for example inside a
  // container built without the frontend) the API still serves normally.
  if (fs.existsSync(publicDir)) {
    app.use(
      express.static(publicDir, {
        etag: true,
        maxAge: config.isProduction ? '1h' : 0,
        setHeaders(res, filePath) {
          // The service worker must never be cached, or clients stick to a
          // stale shell forever.
          if (filePath.endsWith('sw.js') || filePath.endsWith('service-worker.js')) {
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
          }
        },
      }),
    );
  } else {
    log.warn('No frontend bundle found; serving the API only', { publicDir });
  }

  // ----------------------------------------------------------------- API
  app.use('/api', createApiRouter({ enableRateLimit: options.enableRateLimit ?? true }));
  app.use('/api', notFoundHandler());

  // SPA fallback: any non-API GET serves the app shell.
  app.get(/^\/(?!api\/).*/, (_req, res, next) => {
    const indexFile = path.join(publicDir, 'index.html');
    if (!fs.existsSync(indexFile)) {
      next();
      return;
    }
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(indexFile);
  });

  app.use(errorHandler());

  app.locals.repository = repository;
  return app;
}

/**
 * Seed the repository when it is empty.
 *
 * @param {object} repository
 * @param {number} [days]
 * @returns {Promise<boolean>} True when data was seeded.
 */
export async function seedIfEmpty(repository, days = config.seedDays) {
  if (!config.seedOnBoot) return false;
  if (repository.count('facilities') > 0) return false;

  const result = await seed({ repository, days });
  log.info('Seeded demo dataset', {
    kind: repository.kind,
    facilities: result.written.facilities,
    stock: result.written.stock,
    footfall: result.written.footfall,
  });
  return true;
}

/**
 * Start listening, wiring graceful shutdown to SIGTERM (Cloud Run sends it on
 * every scale-down and every deploy).
 *
 * @param {object} [options]
 * @returns {Promise<{app: import('express').Express, server: http.Server, repository: object}>}
 */
export async function start(options = {}) {
  const repository = options.repository ?? (await createRepository());
  setRepository(repository);
  await seedIfEmpty(repository, options.seedDays);

  const app = await createApp({ ...options, repository });
  const server = http.createServer(app);

  await new Promise((resolve) => server.listen(config.port, config.host, resolve));
  log.info('ArogyaPulse listening', {
    port: config.port,
    host: config.host,
    repository: repository.kind,
    demoMode: config.demoMode,
    ai: aiStatus().mode,
  });

  let shuttingDown = false;
  const shutdown = (signal) => {
    if (shuttingDown) return;
    shuttingDown = true;
    log.info('Shutting down', { signal });

    const force = setTimeout(() => {
      log.error('Forced exit after timeout');
      process.exit(1);
    }, 9_000);
    force.unref();

    server.close(async () => {
      await repository.close?.();
      clearTimeout(force);
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  return { app, server, repository };
}

const isDirectRun =
  typeof process.argv[1] === 'string' && process.argv[1].endsWith(path.join('src', 'server.js'));

if (isDirectRun) {
  start().catch((error) => {
    log.error('Failed to start', { error });
    process.exit(1);
  });
}

export default createApp;
