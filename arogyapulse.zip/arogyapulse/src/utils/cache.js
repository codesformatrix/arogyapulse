/**
 * Dependency-free in-memory TTL cache with a bounded key count.
 *
 * Used for dashboard aggregates, district rankings and Gemini results, where a
 * 15-60 second staleness window is invisible to users but removes almost all
 * repeated Firestore reads (and paid Gemini calls) from a busy district screen.
 *
 * @module utils/cache
 */

import { createHash } from 'node:crypto';

/**
 * @typedef {Object} CacheOptions
 * @property {number} [ttlMs] Default time-to-live in milliseconds.
 * @property {number} [maxEntries] Hard cap on stored keys (LRU-ish eviction).
 * @property {() => number} [now] Clock injection, used by tests.
 */

export class TtlCache {
  /** @param {CacheOptions} [options] */
  constructor({ ttlMs = 30_000, maxEntries = 500, now = () => Date.now() } = {}) {
    this.ttlMs = ttlMs;
    this.maxEntries = maxEntries;
    this.now = now;
    /** @type {Map<string, {value: unknown, expiresAt: number}>} */
    this.store = new Map();
    this.hits = 0;
    this.misses = 0;
  }

  /**
   * Read a value, returning undefined when absent or expired.
   *
   * @template T
   * @param {string} key
   * @returns {T|undefined}
   */
  get(key) {
    const entry = this.store.get(key);
    if (!entry) {
      this.misses += 1;
      return undefined;
    }
    if (entry.expiresAt <= this.now()) {
      this.store.delete(key);
      this.misses += 1;
      return undefined;
    }
    // Refresh recency for the eviction order.
    this.store.delete(key);
    this.store.set(key, entry);
    this.hits += 1;
    return /** @type {T} */ (entry.value);
  }

  /**
   * Store a value.
   *
   * @param {string} key
   * @param {unknown} value
   * @param {number} [ttlMs]
   * @returns {void}
   */
  set(key, value, ttlMs = this.ttlMs) {
    if (this.store.size >= this.maxEntries && !this.store.has(key)) {
      const oldest = this.store.keys().next().value;
      if (oldest !== undefined) this.store.delete(oldest);
    }
    this.store.set(key, { value, expiresAt: this.now() + ttlMs });
  }

  /**
   * Read-through helper: compute and store on a miss.
   *
   * @template T
   * @param {string} key
   * @param {() => Promise<T>|T} producer
   * @param {number} [ttlMs]
   * @returns {Promise<T>}
   */
  async wrap(key, producer, ttlMs = this.ttlMs) {
    const cached = this.get(key);
    if (cached !== undefined) return /** @type {T} */ (cached);
    const value = await producer();
    if (value !== undefined && value !== null) this.set(key, value, ttlMs);
    return value;
  }

  /**
   * Drop keys matching a prefix (e.g. invalidate one facility's caches).
   *
   * @param {string} [prefix]
   * @returns {number} Number of keys removed.
   */
  invalidate(prefix) {
    if (!prefix) {
      const size = this.store.size;
      this.store.clear();
      return size;
    }
    let removed = 0;
    for (const key of this.store.keys()) {
      if (key.startsWith(prefix)) {
        this.store.delete(key);
        removed += 1;
      }
    }
    return removed;
  }

  /** @returns {number} */
  get size() {
    return this.store.size;
  }

  /** @returns {{hits: number, misses: number, size: number, ttlMs: number}} */
  stats() {
    return { hits: this.hits, misses: this.misses, size: this.store.size, ttlMs: this.ttlMs };
  }
}

/**
 * Deterministic cache key built from a prefix and arbitrary JSON-safe parts.
 *
 * @param {string} prefix
 * @param {...unknown} parts
 * @returns {string}
 */
export function cacheKey(prefix, ...parts) {
  const payload = JSON.stringify(parts, (_key, value) =>
    value instanceof Date ? value.toISOString() : value,
  );
  const digest = createHash('sha1').update(payload).digest('hex').slice(0, 16);
  return `${prefix}:${digest}`;
}
