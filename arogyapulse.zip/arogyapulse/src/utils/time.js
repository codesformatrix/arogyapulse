/**
 * Time helpers.
 *
 * Rural health facilities run on Indian Standard Time and most staff think in
 * whole days ("aaj kitne aaye?"), so every date bucket in ArogyaPulse is
 * computed in a single, configurable IANA timezone (default Asia/Kolkata).
 * `Intl.DateTimeFormat` with an explicit timeZone keeps the results identical
 * on Cloud Run (UTC containers) and on a developer laptop.
 *
 * @module utils/time
 */

import config from '../config/env.js';

/** @type {string} */
const TZ = config.tz;

const DAY_MS = 86_400_000;

/**
 * Parse a value into a Date, accepting Date, ISO string or epoch millis.
 *
 * @param {Date|string|number|null|undefined} value
 * @returns {Date|null} Null when the value cannot be interpreted.
 */
export function toDate(value) {
  if (value === null || value === undefined) return null;
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;
  if (typeof value === 'number') {
    const fromNumber = new Date(value);
    return Number.isNaN(fromNumber.getTime()) ? null : fromNumber;
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

/**
 * Wall-clock parts of an instant in the configured timezone.
 *
 * @param {Date|string|number} value
 * @returns {{year: number, month: number, day: number, hour: number, minute: number, weekday: number}}
 *          `month` is 1-12 and `weekday` is 0 (Sunday) - 6 (Saturday).
 */
export function partsInTz(value) {
  const date = toDate(value) ?? new Date(0);
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    weekday: 'short',
    hour12: false,
  });
  const parts = formatter.formatToParts(date).reduce((accumulator, part) => {
    accumulator[part.type] = part.value;
    return accumulator;
  }, {});

  const weekdayMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    day: Number(parts.day),
    hour: Number(parts.hour) % 24,
    minute: Number(parts.minute),
    weekday: weekdayMap[parts.weekday] ?? 0,
  };
}

/**
 * Calendar day key ("YYYY-MM-DD") in the configured timezone.
 *
 * @param {Date|string|number} value
 * @returns {string}
 */
export function dayKey(value) {
  const { year, month, day } = partsInTz(value);
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

/**
 * Add (or subtract) whole calendar days to an instant, in local wall-clock time.
 *
 * @param {Date|string|number} value
 * @param {number} days
 * @returns {Date}
 */
export function addDays(value, days) {
  const date = toDate(value) ?? new Date();
  return new Date(date.getTime() + days * DAY_MS);
}

/**
 * Add minutes to an instant.
 *
 * @param {Date|string|number} value
 * @param {number} minutes
 * @returns {Date}
 */
export function addMinutes(value, minutes) {
  const date = toDate(value) ?? new Date();
  return new Date(date.getTime() + minutes * 60_000);
}

/**
 * Build an instant from wall-clock parts interpreted in the configured
 * timezone (found by probing the UTC offset around the target date).
 *
 * @param {number} year
 * @param {number} month - 1-12.
 * @param {number} day
 * @param {number} [hour]
 * @param {number} [minute]
 * @returns {Date}
 */
export function fromPartsInTz(year, month, day, hour = 0, minute = 0) {
  const guess = Date.UTC(year, month - 1, day, hour, minute, 0, 0);
  const offset = offsetMsAt(new Date(guess));
  return new Date(guess - offset);
}

/**
 * Signed UTC offset (ms) of the configured timezone at a given instant.
 *
 * @param {Date} date
 * @returns {number}
 */
function offsetMsAt(date) {
  const { year, month, day, hour, minute } = partsInTz(date);
  return Date.UTC(year, month - 1, day, hour, minute, 0, 0) - date.getTime();
}

/**
 * Midnight (start of day) of the given instant in the configured timezone.
 *
 * @param {Date|string|number} [value]
 * @returns {Date}
 */
export function startOfDay(value = new Date()) {
  const { year, month, day } = partsInTz(value);
  return fromPartsInTz(year, month, day, 0, 0);
}

/**
 * Contiguous list of day keys ending today (inclusive), oldest first.
 *
 * @param {number} days - Number of days to produce (>= 1).
 * @param {Date|string|number} [today]
 * @returns {string[]}
 */
export function lastNDayKeys(days, today = new Date()) {
  const count = Math.max(1, Math.floor(days));
  const keys = [];
  for (let offset = count - 1; offset >= 0; offset -= 1) {
    keys.push(dayKey(addDays(today, -offset)));
  }
  return keys;
}

/**
 * "HH:mm" in the configured timezone.
 *
 * @param {Date|string|number} value
 * @returns {string}
 */
export function timeOfDay(value) {
  const { hour, minute } = partsInTz(value);
  return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
}

/**
 * Minutes elapsed since local midnight for an instant.
 *
 * @param {Date|string|number} value
 * @returns {number}
 */
export function minutesSinceMidnight(value) {
  const { hour, minute } = partsInTz(value);
  return hour * 60 + minute;
}

/**
 * Convert "HH:mm" to minutes since midnight.
 *
 * @param {string} hhmm
 * @returns {number} 0 when the string is malformed.
 */
export function hhmmToMinutes(hhmm) {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm ?? '').trim());
  if (!match) return 0;
  return Number(match[1]) * 60 + Number(match[2]);
}

/**
 * Minutes between two instants (b - a), rounded.
 *
 * @param {Date|string|number} a
 * @param {Date|string|number} b
 * @returns {number}
 */
export function diffMinutes(a, b) {
  const first = toDate(a);
  const second = toDate(b);
  if (!first || !second) return 0;
  return Math.round((second.getTime() - first.getTime()) / 60_000);
}

/**
 * Whole days between two day keys (b - a).
 *
 * @param {string} aKey
 * @param {string} bKey
 * @returns {number}
 */
export function daysBetweenKeys(aKey, bKey) {
  const a = Date.parse(`${aKey}T00:00:00Z`);
  const b = Date.parse(`${bKey}T00:00:00Z`);
  if (Number.isNaN(a) || Number.isNaN(b)) return 0;
  return Math.round((b - a) / DAY_MS);
}

/**
 * Short human date, e.g. "18 Oct 2026".
 *
 * @param {Date|string|number} value
 * @returns {string}
 */
export function formatDay(value) {
  const date = toDate(value);
  if (!date) return '';
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: TZ,
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

/**
 * Compact human instant, e.g. "18 Oct, 09:42".
 *
 * @param {Date|string|number} value
 * @returns {string}
 */
export function formatDateTime(value) {
  const date = toDate(value);
  if (!date) return '';
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: TZ,
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(date);
}

export { DAY_MS, TZ };
