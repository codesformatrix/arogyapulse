/**
 * Identifier generation.
 *
 * Ids are prefixed and time-sortable so they read well in Firestore, in audit
 * logs and in URLs, while remaining unpredictable enough for anonymous tokens
 * (no PII is ever encoded in an id).
 *
 * @module utils/ids
 */

import { randomBytes, randomUUID } from 'node:crypto';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no I/O/0/1 - read out loud over a phone line

/**
 * Random alphanumeric string from an unambiguous alphabet.
 *
 * @param {number} length
 * @returns {string}
 */
export function randomCode(length = 6) {
  const bytes = randomBytes(length);
  let out = '';
  for (let index = 0; index < length; index += 1) {
    out += ALPHABET[bytes[index] % ALPHABET.length];
  }
  return out;
}

/**
 * Time-sortable, prefixed id: `prefix-<base36 time>-<random>`.
 *
 * @param {string} prefix - Short collection prefix, e.g. "stk", "bat".
 * @returns {string}
 */
export function newId(prefix) {
  const time = Date.now().toString(36).padStart(9, '0');
  return `${prefix}-${time}-${randomCode(5)}`;
}

/**
 * Anonymous patient token, e.g. "A-104". Never contains personal information.
 *
 * @param {string} departmentPrefix - Single letter department marker.
 * @param {number} sequence - 1-based sequence number for the day.
 * @returns {string}
 */
export function anonymousToken(departmentPrefix, sequence) {
  return `${departmentPrefix}-${String(sequence).padStart(3, '0')}`;
}

/**
 * UUIDv4, used where a globally unique value is required (audit entries).
 *
 * @returns {string}
 */
export function uuid() {
  return randomUUID();
}
