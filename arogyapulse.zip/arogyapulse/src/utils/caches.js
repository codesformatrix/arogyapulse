/**
 * Process-wide caches.
 *
 * Two bounded TTL caches absorb the repeated reads that make a district
 * dashboard expensive:
 *   - `dashboardCache` for aggregates recomputed on every screen open
 *   - `aiCache` for Gemini results, which are both slow and paid
 *
 * Both are invalidated by prefix whenever the underlying entity changes, so a
 * pharmacist adjusting stock sees their own change immediately while everyone
 * else keeps the cached aggregate for a few more seconds.
 *
 * @module utils/caches
 */

import { CACHE_TTL_MS } from '../config/constants.js';
import { TtlCache } from './cache.js';

/** @type {TtlCache} */
export const dashboardCache = new TtlCache({
  ttlMs: CACHE_TTL_MS.DASHBOARD,
  maxEntries: 400,
});

/** @type {TtlCache} */
export const aiCache = new TtlCache({
  ttlMs: CACHE_TTL_MS.AI_ANSWER,
  maxEntries: 200,
});

/**
 * Drop caches whose key starts with a facility id (or everything).
 *
 * @param {string} [facilityId]
 * @returns {{dashboard: number, ai: number}}
 */
export function invalidateFor(facilityId) {
  return {
    dashboard: dashboardCache.invalidate(facilityId ? `facility:${facilityId}` : undefined),
    ai: aiCache.invalidate(facilityId ? `facility:${facilityId}` : undefined),
  };
}

/**
 * Cache statistics for the /healthz endpoint.
 *
 * @returns {{dashboard: object, ai: object}}
 */
export function cacheStats() {
  return { dashboard: dashboardCache.stats(), ai: aiCache.stats() };
}
