/**
 * Structured JSON logger.
 *
 * On Cloud Run, anything written to stdout as a JSON object with the fields
 * below is ingested by Cloud Logging with the correct severity, so no
 * additional client library (or extra cold-start cost) is required.
 *
 * @see https://cloud.google.com/run/docs/logging#structured-logging
 * @module utils/logger
 */

import config from '../config/env.js';

const LEVELS = Object.freeze({ debug: 10, info: 20, warn: 30, error: 40, silent: 99 });

const currentLevel = LEVELS[config.logLevel] ?? LEVELS.info;

/**
 * Sanitise a value before it reaches the log stream: strip anything that looks
 * like a secret, an authorisation header or a cookie.
 *
 * @param {unknown} value
 * @param {number} [depth]
 * @returns {unknown}
 */
function sanitise(value, depth = 0) {
  if (depth > 4 || value === null || value === undefined) return value ?? null;
  if (typeof value !== 'object') return value;
  if (value instanceof Error) {
    return { name: value.name, message: value.message, code: value.code ?? null };
  }
  if (Array.isArray(value)) return value.slice(0, 25).map((entry) => sanitise(entry, depth + 1));

  const sensitive = new Set([
    'authorization',
    'cookie',
    'set-cookie',
    'apikey',
    'api_key',
    'x-goog-api-key',
    'password',
    'secret',
    'token',
    'idtoken',
    'session',
  ]);

  const output = {};
  for (const [key, entry] of Object.entries(value)) {
    output[key] = sensitive.has(key.toLowerCase()) ? '[redacted]' : sanitise(entry, depth + 1);
  }
  return output;
}

/**
 * Emit one structured log record.
 *
 * @param {'DEBUG'|'INFO'|'WARNING'|'ERROR'} severity
 * @param {string} message
 * @param {Record<string, unknown>} [context]
 * @returns {void}
 */
function emit(severity, message, context = {}) {
  const numeric =
    severity === 'DEBUG' ? LEVELS.debug : severity === 'WARNING' ? LEVELS.warn : severity === 'ERROR' ? LEVELS.error : LEVELS.info;
  if (numeric < currentLevel) return;

  const record = {
    severity,
    message,
    time: new Date().toISOString(),
    serviceContext: { service: 'arogyapulse', version: '1.0.0' },
    ...sanitise(context),
  };

  const line = JSON.stringify(record);
  if (severity === 'ERROR') process.stderr.write(`${line}\n`);
  else process.stdout.write(`${line}\n`);
}

/** @typedef {{debug: Function, info: Function, warn: Function, error: Function}} Logger */

/**
 * Create a child logger that automatically carries a component field.
 *
 * @param {string} component - Logical component name, e.g. "inventory.controller".
 * @returns {Logger}
 */
export function createLogger(component) {
  return {
    debug: (message, context) => emit('DEBUG', message, { component, ...context }),
    info: (message, context) => emit('INFO', message, { component, ...context }),
    warn: (message, context) => emit('WARNING', message, { component, ...context }),
    error: (message, context) => emit('ERROR', message, { component, ...context }),
  };
}

export const logger = createLogger('app');
export default logger;
