/**
 * Application error taxonomy.
 *
 * Every error thrown from a service or controller is one of these, which lets
 * the error middleware map to a safe HTTP response (no stack traces leak to
 * clients in any environment).
 *
 * @module utils/errors
 */

/** Base class for all domain errors. */
export class AppError extends Error {
  /**
   * @param {string} message - Human readable message (safe to show to users).
   * @param {number} statusCode - HTTP status code.
   * @param {string} code - Stable machine readable code.
   * @param {Record<string, unknown>} [details]
   */
  constructor(message, statusCode = 500, code = 'INTERNAL_ERROR', details) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.expose = statusCode < 500;
  }
}

/** 400 - the request payload failed zod validation. */
export class ValidationError extends AppError {
  /** @param {string} message @param {unknown[]} [issues] */
  constructor(message = 'Invalid request payload', issues = []) {
    super(message, 400, 'VALIDATION_ERROR', { issues });
    this.name = 'ValidationError';
  }
}

/** 401 - missing, malformed or expired credentials. */
export class UnauthorizedError extends AppError {
  /** @param {string} [message] */
  constructor(message = 'Authentication required') {
    super(message, 401, 'UNAUTHENTICATED');
    this.name = 'UnauthorizedError';
  }
}

/** 403 - authenticated, but not allowed to perform this action. */
export class ForbiddenError extends AppError {
  /** @param {string} [message] */
  constructor(message = 'You do not have permission to perform this action') {
    super(message, 403, 'FORBIDDEN');
    this.name = 'ForbiddenError';
  }
}

/** 404 - the requested entity does not exist. */
export class NotFoundError extends AppError {
  /** @param {string} [message] */
  constructor(message = 'Resource not found') {
    super(message, 404, 'NOT_FOUND');
    this.name = 'NotFoundError';
  }
}

/** 409 - the change conflicts with current state (e.g. workflow transition). */
export class ConflictError extends AppError {
  /** @param {string} [message] @param {Record<string, unknown>} [details] */
  constructor(message = 'Conflicting state', details) {
    super(message, 409, 'CONFLICT', details);
    this.name = 'ConflictError';
  }
}

/** 422 - the request is well formed but semantically impossible. */
export class BusinessRuleError extends AppError {
  /** @param {string} [message] @param {Record<string, unknown>} [details] */
  constructor(message = 'Operation rejected by business rule', details) {
    super(message, 422, 'BUSINESS_RULE', details);
    this.name = 'BusinessRuleError';
  }
}

/** 429 - rate limited. */
export class TooManyRequestsError extends AppError {
  /** @param {string} [message] */
  constructor(message = 'Too many requests, please slow down') {
    super(message, 429, 'RATE_LIMITED');
    this.name = 'TooManyRequestsError';
  }
}

/** 503 - an upstream dependency (Gemini, Firestore) is unavailable. */
export class UpstreamError extends AppError {
  /** @param {string} [message] */
  constructor(message = 'Upstream service unavailable') {
    super(message, 503, 'UPSTREAM_UNAVAILABLE');
    this.name = 'UpstreamError';
  }
}

/**
 * Narrow an unknown thrown value into an AppError.
 *
 * @param {unknown} error
 * @returns {AppError}
 */
export function toAppError(error) {
  if (error instanceof AppError) return error;
  // body-parser signals an over-limit body with a 413 status and a stable
  // `type`, but only sets `name` on newer versions, so check both.
  if (
    error instanceof Error &&
    (error.name === 'PayloadTooLargeError' ||
      error.type === 'entity.too.large' ||
      error.status === 413)
  ) {
    return new AppError('Request body is too large', 413, 'PAYLOAD_TOO_LARGE');
  }

  // Malformed JSON is a client error, not a server fault.
  if (error instanceof Error && (error.type === 'entity.parse.failed' || error.status === 400)) {
    return new ValidationError('Request body could not be parsed');
  }
  const wrapped = new AppError('Unexpected server error', 500, 'INTERNAL_ERROR');
  wrapped.cause = error;
  return wrapped;
}
