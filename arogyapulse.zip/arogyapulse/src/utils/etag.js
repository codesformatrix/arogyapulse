/**
 * ETag + conditional request helpers.
 *
 * Every JSON payload served by the API is fingerprinted so a 2G-connected
 * phone re-opening the dashboard can receive a 304 instead of re-downloading
 * the whole district table.
 *
 * @module utils/etag
 */

import { createHash } from 'node:crypto';

/**
 * Weak ETag for a JSON-serialisable payload.
 *
 * @param {unknown} payload
 * @returns {string} Quoted ETag header value, e.g. `W/"9f2c..."`.
 */
export function etagFor(payload) {
  const body = JSON.stringify(payload, (_key, value) =>
    value instanceof Date ? value.toISOString() : value,
  );
  const digest = createHash('sha1').update(body).digest('base64url');
  return `W/"${digest}"`;
}

/**
 * Compare the request's If-None-Match header with a candidate ETag.
 *
 * @param {string|undefined} ifNoneMatch
 * @param {string} etag
 * @returns {boolean} True when the client's cached copy is still fresh.
 */
export function isFresh(ifNoneMatch, etag) {
  if (!ifNoneMatch) return false;
  if (ifNoneMatch.trim() === '*') return true;
  return ifNoneMatch
    .split(',')
    .map((candidate) => candidate.trim().replace(/^W\//, ''))
    .includes(etag.replace(/^W\//, ''));
}
