/**
 * Small deterministic helpers: id generation, hashing, numbers, text.
 *
 * Determinism matters for this project because the demo dataset must look the
 * same on every machine (and every Cloud Run cold start) so that screenshots,
 * tests and the 3-minute demo script never drift.
 *
 * @module utils/random
 */

/**
 * FNV-1a 32-bit string hash, used to derive stable numeric seeds.
 *
 * @param {string} input
 * @returns {number} Unsigned 32-bit integer.
 */
export function hashString(input) {
  let hash = 0x811c9dc5;
  for (let index = 0; index < input.length; index += 1) {
    hash ^= input.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193);
  }
  return hash >>> 0;
}

/**
 * Mulberry32 - a tiny, fast, seedable PRNG with good enough distribution for
 * synthetic health-facility data.
 *
 * @param {number|string} seed
 * @returns {() => number} Generator returning floats in [0, 1).
 */
export function mulberry32(seed) {
  let state = typeof seed === 'string' ? hashString(seed) : seed >>> 0;
  return function next() {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * A seeded random toolkit.
 *
 * @param {number|string} seed
 * @returns {{
 *   float: () => number,
 *   int: (min: number, max: number) => number,
 *   pick: <T>(items: readonly T[]) => T,
 *   chance: (probability: number) => boolean,
 *   gaussian: (mean: number, spread: number) => number
 * }}
 */
export function createRandom(seed) {
  const float = mulberry32(seed);
  return {
    float,
    int: (min, max) => Math.floor(float() * (max - min + 1)) + min,
    pick: (items) => items[Math.floor(float() * items.length) % items.length],
    chance: (probability) => float() < probability,
    /** Box-Muller transform, clamped so generated values stay sensible. */
    gaussian: (centre, spread) => {
      const u = Math.max(float(), 1e-9);
      const v = float();
      const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
      return centre + z * spread;
    },
  };
}

/**
 * Clamp a number into an inclusive range.
 *
 * @param {number} value
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
export function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

/**
 * Round to a fixed number of decimals, avoiding -0 and floating point noise.
 *
 * @param {number} value
 * @param {number} [decimals]
 * @returns {number}
 */
export function round(value, decimals = 2) {
  if (!Number.isFinite(value)) return 0;
  const factor = 10 ** decimals;
  const rounded = Math.round((value + Number.EPSILON) * factor) / factor;
  return Object.is(rounded, -0) ? 0 : rounded;
}

/**
 * Sum an array of numbers.
 *
 * @param {number[]} values
 * @returns {number}
 */
export function sum(values) {
  return values.reduce((total, value) => total + (Number.isFinite(value) ? value : 0), 0);
}

/**
 * Arithmetic mean of an array of numbers (0 for an empty array).
 *
 * @param {number[]} values
 * @returns {number}
 */
export function mean(values) {
  if (!values.length) return 0;
  return sum(values) / values.length;
}

/**
 * Stable, locale-independent slug for ids derived from names.
 *
 * @param {string} value
 * @returns {string}
 */
export function slugify(value) {
  return String(value)
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .toUpperCase()
    .slice(0, 24);
}

/**
 * Deep clone using the structured clone algorithm (Node 17+).
 *
 * @template T
 * @param {T} value
 * @returns {T}
 */
export function clone(value) {
  return value === undefined ? value : structuredClone(value);
}

/**
 * Group an array by a key function.
 *
 * @template T
 * @param {T[]} items
 * @param {(item: T) => string} keyOf
 * @returns {Map<string, T[]>}
 */
export function groupBy(items, keyOf) {
  const groups = new Map();
  for (const item of items) {
    const key = keyOf(item);
    const bucket = groups.get(key);
    if (bucket) bucket.push(item);
    else groups.set(key, [item]);
  }
  return groups;
}

/**
 * Sort helper that never mutates the input.
 *
 * @template T
 * @param {T[]} items
 * @param {(a: T, b: T) => number} compare
 * @returns {T[]}
 */
export function sortBy(items, compare) {
  return [...items].sort(compare);
}
