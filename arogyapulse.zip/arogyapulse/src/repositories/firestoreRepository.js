/**
 * Firestore repository.
 *
 * Implements exactly the same contract as {@link InMemoryRepository}, so
 * switching storage is a single environment variable (`REPOSITORY=firestore`)
 * and no controller or service changes.
 *
 * Design rules enforced here:
 *   - reads are projected through `normalize()` so the rest of the app only
 *     ever sees plain JSON (ISO strings, never Firestore `Timestamp` objects);
 *   - writes are projected through `prepare()` so `undefined` can never reach
 *     Firestore (which throws on it);
 *   - bulk writes are chunked to 400 documents, below the 500-op batch limit;
 *   - the Admin SDK is imported lazily, so the in-memory path never pays the
 *     firebase-admin import cost (which matters for Cloud Run cold starts).
 *
 * Required composite indexes are declared in `firestore.indexes.json`.
 *
 * @module repositories/firestoreRepository
 */

import { NotFoundError } from '../utils/errors.js';
import { addDays, dayKey } from '../utils/time.js';

/** Firestore's hard limit per batched write. */
const BATCH_LIMIT = 400;

/** Default page size when a caller does not supply one. */
const DEFAULT_LIMIT = 1000;

let adminModulePromise = null;

/**
 * Lazily import firebase-admin (heavy: gRPC, protobuf, auth).
 *
 * @returns {Promise<typeof import('firebase-admin/app')>}
 */
function loadAdmin() {
  if (!adminModulePromise) adminModulePromise = import('firebase-admin/app');
  return adminModulePromise;
}

/**
 * Strip `undefined`, convert Dates to ISO strings, so a value can be written.
 *
 * @param {unknown} value
 * @returns {unknown}
 */
function prepare(value) {
  if (value === undefined) return undefined;
  if (value === null) return null;
  if (value instanceof Date) return value.toISOString();
  if (typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map((entry) => prepare(entry)).filter((entry) => entry !== undefined);

  const output = {};
  for (const [key, entry] of Object.entries(value)) {
    const prepared = prepare(entry);
    if (prepared !== undefined) output[key] = prepared;
  }
  return output;
}

/**
 * Normalise the first argument of a list method.
 *
 * Both calling styles are accepted so filters can never be silently re-wrapped
 * (which would turn `{ filters: {...} }` into an equality test on a literal
 * field named "filters" and quietly return nothing):
 *   listAudit({ facilityId })               -> raw filters
 *   listAudit({ filters: { facilityId } })  -> options object
 *
 * @param {object} [first]
 * @param {object} [second]
 * @returns {{filters: Record<string, unknown>, limit?: number, offset?: number}}
 */
function listArgs(first = {}, second = {}) {
  const isOptionsShape =
    first && (first.filters !== undefined || first.limit !== undefined || first.offset !== undefined);
  return isOptionsShape ? { ...second, ...first } : { ...second, filters: first };
}

/**
 * Convert a Firestore document snapshot into plain JSON.
 *
 * @param {unknown} value
 * @param {number} [depth]
 * @returns {unknown}
 */
function normalize(value, depth = 0) {
  if (depth > 8) return value;
  if (value === null || value === undefined) return value ?? null;
  if (typeof value.toDate === 'function') return value.toDate().toISOString();
  if (typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map((entry) => normalize(entry, depth + 1));

  const output = {};
  for (const [key, entry] of Object.entries(value)) {
    output[key] = normalize(entry, depth + 1);
  }
  return output;
}

/**
 * Thin wrapper over a Firestore collection with the JSON conventions above.
 */
class CollectionHandle {
  /**
   * @param {import('firebase-admin/firestore').Firestore} db
   * @param {string} name
   */
  constructor(db, name) {
    this.db = db;
    this.name = name;
  }

  /** @param {string} id */
  doc(id) {
    return this.db.collection(this.name).doc(id);
  }

  /**
   * @param {string} id
   * @returns {Promise<object|null>}
   */
  async get(id) {
    const snapshot = await this.doc(id).get();
    if (!snapshot.exists) return null;
    return { id: snapshot.id, ...normalize(snapshot.data()) };
  }

  /**
   * @param {object} [options]
   * @param {Record<string, unknown>} [options.filters] - Equality filters.
   * @param {{field: string, op: '>='|'<='|'>'|'<', value: unknown}[]} [options.ranges]
   * @param {string} [options.orderBy]
   * @param {'asc'|'desc'} [options.direction]
   * @param {number} [options.limit]
   * @param {number} [options.offset]
   * @returns {Promise<object[]>}
   */
  async query(options = {}) {
    let ref = this.db.collection(this.name);
    for (const [field, value] of Object.entries(options.filters ?? {})) {
      if (value === undefined || value === null) continue;
      ref = ref.where(field, '==', value);
    }
    for (const range of options.ranges ?? []) {
      ref = ref.where(range.field, range.op, range.value);
    }
    if (options.orderBy) ref = ref.orderBy(options.orderBy, options.direction ?? 'asc');
    if (Number.isFinite(options.offset) && options.offset > 0) ref = ref.offset(options.offset);
    ref = ref.limit(Number.isFinite(options.limit) ? options.limit : DEFAULT_LIMIT);

    const snapshot = await ref.get();
    return snapshot.docs.map((doc) => ({ id: doc.id, ...normalize(doc.data()) }));
  }

  /**
   * @param {string} id
   * @param {object} data
   * @returns {Promise<object>}
   */
  async set(id, data) {
    const payload = prepare(data) ?? {};
    await this.doc(id).set(payload, { merge: true });
    return { id, ...normalize(payload) };
  }

  /**
   * @param {string} id
   * @param {object} patch
   * @returns {Promise<object|null>}
   */
  async update(id, patch) {
    const existing = await this.get(id);
    if (!existing) return null;
    const payload = prepare(patch) ?? {};
    await this.doc(id).update(payload);
    return { ...existing, ...normalize(payload) };
  }

  /**
   * @param {object[]} documents - Each must carry an `id`.
   * @returns {Promise<number>}
   */
  async bulkWrite(documents) {
    let written = 0;
    for (let index = 0; index < documents.length; index += BATCH_LIMIT) {
      const chunk = documents.slice(index, index + BATCH_LIMIT);
      const batch = this.db.batch();
      for (const document of chunk) {
        const { id, ...data } = document;
        batch.set(this.doc(id), prepare(data) ?? {}, { merge: true });
      }
      await batch.commit();
      written += chunk.length;
    }
    return written;
  }
}

export class FirestoreRepository {
  /**
   * @param {object} [options]
   * @param {object} [options.db] - Injected Firestore instance (tests / emulator).
   * @param {string} [options.projectId]
   */
  constructor(options = {}) {
    this.name = 'firestore';
    this.injectedDb = options.db ?? null;
    this.projectId = options.projectId ?? process.env.GOOGLE_CLOUD_PROJECT ?? null;
    this.dbPromise = null;
    this.app = null;
  }

  /** @returns {string} */
  get kind() {
    return 'firestore';
  }

  /**
   * Resolve (and memoise) the Firestore handle.
   *
   * @returns {Promise<import('firebase-admin/firestore').Firestore>}
   */
  async database() {
    if (this.injectedDb) return this.injectedDb;
    if (!this.dbPromise) {
      this.dbPromise = (async () => {
        const admin = await loadAdmin();
        if (admin.getApps().length === 0) {
          this.app = admin.initializeApp({
            projectId: this.projectId ?? undefined,
          });
        } else {
          this.app = admin.getApp();
        }
        const { getFirestore } = await import('firebase-admin/firestore');
        return getFirestore(this.app);
      })();
    }
    return this.dbPromise;
  }

  /**
   * @param {string} name
   * @returns {Promise<CollectionHandle>}
   */
  async handle(name) {
    const db = await this.database();
    return new CollectionHandle(db, name);
  }

  /**
   * Page shape parity with the in-memory repository.
   *
   * @param {CollectionHandle} handle
   * @param {object} [options]
   * @returns {Promise<{items: object[], total: number, limit: number, offset: number}>}
   */
  async page(handle, options = {}) {
    const limit = Number.isFinite(options.limit) ? options.limit : DEFAULT_LIMIT;
    const offset = Number.isFinite(options.offset) ? options.offset : 0;
    const filters = options.filters ?? {};
    const orderBy = options.orderBy ?? null;
    const direction = options.direction ?? 'desc';

    const [items, counted] = await Promise.all([
      handle.query({ filters, orderBy, direction, limit, offset }),
      handle.query({ filters }),
    ]);

    return { items, total: counted.length, limit, offset };
  }

  /** @returns {Promise<void>} */
  async close() {
    if (this.app) {
      await this.app.delete();
      this.app = null;
      this.dbPromise = null;
    }
  }

  // ---------------------------------------------------------------- facilities

  /** @param {{filters?: object, limit?: number, offset?: number}} [options] */
  async listFacilities(options = {}) {
    return this.page(await this.handle('facilities'), {
      ...options,
      orderBy: 'name',
      direction: 'asc',
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getFacility(id) {
    return (await this.handle('facilities')).get(id);
  }

  /** @param {string} id @returns {Promise<object>} */
  async requireFacility(id) {
    const facility = await this.getFacility(id);
    if (!facility) throw new NotFoundError(`Facility not found: ${id}`);
    return facility;
  }

  /** @param {object} facility @returns {Promise<object>} */
  async upsertFacility(facility) {
    return (await this.handle('facilities')).set(facility.id, facility);
  }

  // ----------------------------------------------------------------- medicines

  /** @param {{filters?: object, limit?: number, offset?: number}} [options] */
  async listMedicines(options = {}) {
    return this.page(await this.handle('medicines'), {
      ...options,
      orderBy: 'name',
      direction: 'asc',
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getMedicine(id) {
    return (await this.handle('medicines')).get(id);
  }

  /** @param {object} medicine @returns {Promise<object>} */
  async upsertMedicine(medicine) {
    return (await this.handle('medicines')).set(medicine.id, medicine);
  }

  // --------------------------------------------------------------------- stock

  /** @param {{facilityId: string, medicineId?: string}} filters @returns {Promise<object[]>} */
  async listStockByFacility(filters = {}) {
    return (await this.handle('stock')).query({
      ...listArgs(filters),
      orderBy: 'medicineId',
      direction: 'asc',
    });
  }

  /** @param {string} facilityId @param {string} medicineId @returns {Promise<object|null>} */
  async getStock(facilityId, medicineId) {
    const handle = await this.handle('stock');
    const direct = await handle.get(`STK-${facilityId}-${medicineId}`);
    if (direct) return direct;
    const found = await handle.query({ filters: { facilityId, medicineId }, limit: 1 });
    return found[0] ?? null;
  }

  /** @param {object} line @returns {Promise<object>} */
  async upsertStock(line) {
    const id = line.id ?? `STK-${line.facilityId}-${line.medicineId}`;
    return (await this.handle('stock')).set(id, { ...line, id, updatedAt: new Date().toISOString() });
  }

  /**
   * @param {string} facilityId
   * @param {string} medicineId
   * @param {{date: string, quantity: number}} point
   * @param {number} [maxPoints]
   * @returns {Promise<object|null>}
   */
  async appendConsumption(facilityId, medicineId, point, maxPoints = 45) {
    const line = await this.getStock(facilityId, medicineId);
    if (!line) return null;
    const series = Array.isArray(line.consumptionSeries) ? [...line.consumptionSeries] : [];
    const index = series.findIndex((entry) => entry.date === point.date);
    if (index >= 0) series[index] = { ...point };
    else series.push({ ...point });
    series.sort((a, b) => a.date.localeCompare(b.date));
    return this.upsertStock({
      ...line,
      id: line.id,
      consumptionSeries: series.slice(-maxPoints),
      updatedAt: new Date().toISOString(),
    });
  }

  /**
   * @param {string} facilityId
   * @param {string} medicineId
   * @param {number} [days]
   * @param {Date} [today]
   * @returns {Promise<{date: string, quantity: number}[]>}
   */
  async consumptionFromDispensing(facilityId, medicineId, days = 14, today = new Date()) {
    const fromInstant = addDays(today, -(days - 1)).toISOString();
    const records = await (await this.handle('dispensing')).query({
      filters: { facilityId, medicineId },
      ranges: [{ field: 'recordedAt', op: '>=', value: fromInstant }],
      orderBy: 'recordedAt',
      direction: 'desc',
      limit: DEFAULT_LIMIT,
    });

    const totals = new Map();
    for (const record of records) {
      const date = dayKey(record.recordedAt);
      totals.set(date, (totals.get(date) ?? 0) + (Number(record.quantity) || 0));
    }

    const series = [];
    for (let offset = days - 1; offset >= 0; offset -= 1) {
      const date = dayKey(addDays(today, -offset));
      series.push({ date, quantity: totals.get(date) ?? 0 });
    }
    return series;
  }

  // ------------------------------------------------------------------- batches

  /** @param {{facilityId: string, medicineId?: string}} filters @returns {Promise<object[]>} */
  async listBatches(filters = {}) {
    return (await this.handle('batches')).query({
      ...listArgs(filters),
      orderBy: 'expiryDate',
      direction: 'asc',
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getBatch(id) {
    return (await this.handle('batches')).get(id);
  }

  /** @param {object} batch @returns {Promise<object>} */
  async upsertBatch(batch) {
    return (await this.handle('batches')).set(batch.id, { ...batch, updatedAt: new Date().toISOString() });
  }

  /** @param {string} batchId @param {number} units @returns {Promise<object|null>} */
  async decrementBatch(batchId, units) {
    const batch = await this.getBatch(batchId);
    if (!batch) return null;
    const quantity = Math.max(0, (Number(batch.quantity) || 0) - units);
    if (quantity === 0) {
      await (await this.handle('batches')).doc(batchId).delete();
      return null;
    }
    return this.upsertBatch({ ...batch, quantity });
  }

  /** @param {string} batchId @param {number} units @returns {Promise<object|null>} */
  async incrementBatch(batchId, units) {
    const batch = await this.getBatch(batchId);
    if (!batch) return null;
    return this.upsertBatch({ ...batch, quantity: (Number(batch.quantity) || 0) + units });
  }

  // ---------------------------------------------------------------- dispensing

  /**
   * @param {{facilityId: string, medicineId?: string}} filters
   * @param {{limit?: number, offset?: number}} [options]
   */
  async listDispensing(filters = {}, options = {}) {
    return this.page(await this.handle('dispensing'), {
      ...listArgs(filters, options),
      orderBy: 'recordedAt',
      direction: 'desc',
    });
  }

  /** @param {object} record @returns {Promise<object>} */
  async addDispensing(record) {
    return (await this.handle('dispensing')).set(record.id, record);
  }

  // ------------------------------------------------------------------ footfall

  /** @param {{facilityId: string, date?: string, department?: string}} filters */
  async listFootfall(filters = {}) {
    return (await this.handle('footfall')).query({
      ...listArgs(filters),
      orderBy: 'date',
      direction: 'asc',
    });
  }

  /**
   * @param {string} facilityId
   * @param {string} fromKey
   * @param {string} toKey
   * @returns {Promise<object[]>}
   */
  async footfallBetween(facilityId, fromKey, toKey) {
    // Indexed range query on (facilityId, date) - no client-side scan.
    return (await this.handle('footfall')).query({
      filters: { facilityId },
      ranges: [
        { field: 'date', op: '>=', value: fromKey },
        { field: 'date', op: '<=', value: toKey },
      ],
      orderBy: 'date',
      direction: 'asc',
      limit: DEFAULT_LIMIT,
    });
  }

  /** @param {object} row @returns {Promise<object>} */
  async addFootfall(row) {
    const id = row.id ?? `FF-${row.facilityId}-${row.department}-${row.date}-${row.hour}`;
    return (await this.handle('footfall')).set(id, { ...row, id });
  }

  // -------------------------------------------------------------------- tokens

  /**
   * @param {{facilityId: string, date?: string, status?: string}} filters
   * @param {{limit?: number, offset?: number}} [options]
   */
  async listTokens(filters = {}, options = {}) {
    return this.page(await this.handle('tokens'), {
      ...listArgs(filters, options),
      orderBy: 'issuedAt',
      direction: 'asc',
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getToken(id) {
    return (await this.handle('tokens')).get(id);
  }

  /** @param {object} token @returns {Promise<object>} */
  async addToken(token) {
    return (await this.handle('tokens')).set(token.id, token);
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateToken(id, patch) {
    return (await this.handle('tokens')).update(id, patch);
  }

  // ------------------------------------------------------------------ counters

  /** @param {string} facilityId @returns {Promise<object[]>} */
  async listCounters(facilityId) {
    return (await this.handle('counters')).query({
      filters: { facilityId },
      orderBy: 'counterId',
      direction: 'asc',
    });
  }

  /** @param {object} counter @returns {Promise<object>} */
  async upsertCounter(counter) {
    const id = counter.id ?? `CTR-${counter.facilityId}-${counter.counterId}`;
    return (await this.handle('counters')).set(id, { ...counter, id, updatedAt: new Date().toISOString() });
  }

  // --------------------------------------------------------------------- wards

  /** @param {string} facilityId @returns {Promise<object[]>} */
  async listWards(facilityId) {
    return (await this.handle('wards')).query({ filters: { facilityId } });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getWard(id) {
    return (await this.handle('wards')).get(id);
  }

  /** @param {object} ward @returns {Promise<object>} */
  async upsertWard(ward) {
    return (await this.handle('wards')).set(ward.id, { ...ward, updatedAt: new Date().toISOString() });
  }

  /** @param {object} event @returns {Promise<object>} */
  async addBedEvent(event) {
    return (await this.handle('bedEvents')).set(event.id, event);
  }

  /** @param {string} facilityId @param {number} [limit] @returns {Promise<object[]>} */
  async listBedEvents(facilityId, limit = 50) {
    return (await this.handle('bedEvents')).query({
      filters: { facilityId },
      orderBy: 'at',
      direction: 'desc',
      limit,
    });
  }

  // ------------------------------------------------------------------- doctors

  /**
   * @param {{facilityId: string, department?: string}} filters
   * @param {{limit?: number, offset?: number}} [options]
   */
  async listDoctors(filters = {}, options = {}) {
    return this.page(await this.handle('doctors'), {
      ...listArgs(filters, options),
      orderBy: 'name',
      direction: 'asc',
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getDoctor(id) {
    return (await this.handle('doctors')).get(id);
  }

  /** @param {object} doctor @returns {Promise<object>} */
  async upsertDoctor(doctor) {
    return (await this.handle('doctors')).set(doctor.id, doctor);
  }

  /** @param {string} doctorId @param {string} [fromKey] @returns {Promise<object[]>} */
  async listAttendance(doctorId, fromKey) {
    const rows = await (await this.handle('attendance')).query({
      filters: { doctorId },
      orderBy: 'date',
      direction: 'asc',
    });
    return fromKey ? rows.filter((row) => row.date >= fromKey) : rows;
  }

  /** @param {{facilityId: string, date?: string}} filters @returns {Promise<object[]>} */
  async listAttendanceByFacility(filters = {}) {
    return (await this.handle('attendance')).query(listArgs(filters));
  }

  /** @param {object} record @returns {Promise<object>} */
  async upsertAttendance(record) {
    const id = record.id ?? `ATT-${record.doctorId}-${record.date}`;
    return (await this.handle('attendance')).set(id, { ...record, id });
  }

  /** @param {{facilityId: string, date?: string}} filters @returns {Promise<object[]>} */
  async listRosters(filters = {}) {
    return (await this.handle('rosters')).query(listArgs(filters));
  }

  /** @param {object} roster @returns {Promise<object>} */
  async upsertRoster(roster) {
    const id = roster.id ?? `ROS-${roster.doctorId}-${roster.date}`;
    return (await this.handle('rosters')).set(id, { ...roster, id });
  }

  /** @param {{facilityId: string, date?: string}} filters @returns {Promise<object[]>} */
  async listLeaves(filters = {}) {
    return (await this.handle('leaves')).query(listArgs(filters));
  }

  /** @param {object} leave @returns {Promise<object>} */
  async addLeave(leave) {
    return (await this.handle('leaves')).set(leave.id, leave);
  }

  // ----------------------------------------------------------------- referrals

  /** @param {object} [filters] @param {{limit?: number, offset?: number}} [options] */
  async listReferrals(filters = {}, options = {}) {
    return this.page(await this.handle('referrals'), {
      ...listArgs(filters, options),
      orderBy: 'createdAt',
      direction: 'desc',
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getReferral(id) {
    return (await this.handle('referrals')).get(id);
  }

  /** @param {object} referral @returns {Promise<object>} */
  async addReferral(referral) {
    return (await this.handle('referrals')).set(referral.id, referral);
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateReferral(id, patch) {
    return (await this.handle('referrals')).update(id, patch);
  }

  // ------------------------------------------------------------------- indents

  /** @param {object} [filters] @param {{limit?: number, offset?: number}} [options] */
  async listIndents(filters = {}, options = {}) {
    return this.page(await this.handle('indents'), {
      ...listArgs(filters, options),
      orderBy: 'requestedAt',
      direction: 'desc',
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getIndent(id) {
    return (await this.handle('indents')).get(id);
  }

  /** @param {object} indent @returns {Promise<object>} */
  async addIndent(indent) {
    return (await this.handle('indents')).set(indent.id, indent);
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateIndent(id, patch) {
    return (await this.handle('indents')).update(id, patch);
  }

  // ----------------------------------------------------------------- transfers

  /** @param {object} [filters] @param {{limit?: number, offset?: number}} [options] */
  async listTransfers(filters = {}, options = {}) {
    return this.page(await this.handle('transfers'), {
      ...listArgs(filters, options),
      orderBy: 'requestedAt',
      direction: 'desc',
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getTransfer(id) {
    return (await this.handle('transfers')).get(id);
  }

  /** @param {object} transfer @returns {Promise<object>} */
  async addTransfer(transfer) {
    return (await this.handle('transfers')).set(transfer.id, transfer);
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateTransfer(id, patch) {
    return (await this.handle('transfers')).update(id, patch);
  }

  // --------------------------------------------------------------------- audit

  /** @param {object} entry @returns {Promise<object>} */
  async addAudit(entry) {
    return (await this.handle('audit')).set(entry.id, entry);
  }

  /** @param {object} [filters] @param {{limit?: number, offset?: number}} [options] */
  async listAudit(filters = {}, options = {}) {
    return this.page(await this.handle('audit'), {
      ...listArgs(filters, options),
      orderBy: 'createdAt',
      direction: 'desc',
    });
  }

  // -------------------------------------------------------------------- alerts

  /** @param {object} alert @returns {Promise<object>} */
  async addAlert(alert) {
    return (await this.handle('alerts')).set(alert.id, alert);
  }

  /** @param {object} [filters] @param {{limit?: number, offset?: number}} [options] */
  async listAlerts(filters = {}, options = {}) {
    return this.page(await this.handle('alerts'), {
      ...listArgs(filters, options),
      orderBy: 'createdAt',
      direction: 'desc',
    });
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateAlert(id, patch) {
    return (await this.handle('alerts')).update(id, patch);
  }

  // -------------------------------------------------------------------- shared

  /**
   * Chunked batched write (Firestore allows at most 500 ops per batch).
   *
   * @param {string} collection
   * @param {object[]} documents
   * @returns {Promise<number>}
   */
  async bulkWrite(collection, documents) {
    return (await this.handle(collection)).bulkWrite(documents);
  }
}

export { CollectionHandle, prepare, normalize, BATCH_LIMIT };
export default FirestoreRepository;
