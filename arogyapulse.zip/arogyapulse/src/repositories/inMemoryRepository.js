/**
 * In-memory repository.
 *
 * Implements exactly the same contract as {@link FirestoreRepository} so the
 * application boots and is fully demo-able with zero configuration: no
 * service account, no project id, no emulator. Data lives for the lifetime of
 * the process and is reseeded on boot.
 *
 * Every read returns a deep copy, so a controller can never mutate the store
 * by accident (which is the single most common source of "it worked locally"
 * bugs in a shared-state server).
 *
 * @module repositories/inMemoryRepository
 */

import { NotFoundError } from '../utils/errors.js';
import { clone, groupBy, sortBy } from '../utils/random.js';
import { addDays, dayKey, toDate } from '../utils/time.js';

/**
 * @typedef {Object} ListOptions
 * @property {Record<string, unknown>} [filters] - Exact-match filters.
 * @property {(item: object) => boolean} [where] - Predicate filter.
 * @property {(a: object, b: object) => number} [sort]
 * @property {number} [limit]
 * @property {number} [offset]
 */

/**
 * Apply filters, sorting and pagination, returning a page plus the true total.
 *
 * @param {object[]} items
 * @param {ListOptions} options
 * @returns {{items: object[], total: number, limit: number, offset: number}}
 */
function paginate(items, options = {}) {
  const limit = Number.isFinite(options.limit) ? options.limit : items.length;
  const offset = Number.isFinite(options.offset) ? options.offset : 0;
  let filtered = items;

  if (options.filters) {
    for (const [key, value] of Object.entries(options.filters)) {
      if (value === undefined || value === null) continue;
      filtered = filtered.filter((item) => item[key] === value);
    }
  }
  if (options.where) filtered = filtered.filter(options.where);
  if (options.sort) filtered = sortBy(filtered, options.sort);

  return {
    items: filtered.slice(offset, offset + limit),
    total: filtered.length,
    limit,
    offset,
  };
}

/**
 * Match a compound filter across several fields, ignoring undefined values.
 *
 * @param {object} item
 * @param {Record<string, unknown>} filters
 * @returns {boolean}
 */
function matchesFilters(item, filters) {
  return Object.entries(filters ?? {}).every(
    ([key, value]) => value === undefined || value === null || item?.[key] === value,
  );
}

/**
 * Normalise the first argument of a list method.
 *
 * Both calling styles are accepted so a caller can never silently pass filters
 * in the wrong place:
 *   listAudit({ facilityId })                  -> raw filters
 *   listAudit({ filters: { facilityId } })     -> options object
 *
 * @param {object} [first]
 * @param {ListOptions} [second]
 * @returns {ListOptions}
 */
function listArgs(first = {}, second = {}) {
  const isOptionsShape =
    first && (first.filters !== undefined || first.limit !== undefined || first.offset !== undefined);
  return isOptionsShape ? { ...second, ...first } : { ...second, filters: first };
}

export class InMemoryRepository {
  /** @param {{name?: string}} [options] */
  constructor(options = {}) {
    this.name = options.name ?? 'memory';
    /** @type {Map<string, Map<string, object>>} */
    this.collections = new Map();
    for (const collection of [
      'facilities',
      'medicines',
      'stock',
      'batches',
      'dispensing',
      'footfall',
      'tokens',
      'counters',
      'wards',
      'bedEvents',
      'doctors',
      'attendance',
      'rosters',
      'leaves',
      'referrals',
      'indents',
      'transfers',
      'audit',
      'alerts',
      'aiCache',
    ]) {
      this.collections.set(collection, new Map());
    }
  }

  /** @returns {string} */
  get kind() {
    return 'memory';
  }

  /**
   * Raw collection access (always the internal map, never a copy).
   *
   * @param {string} name
   * @returns {Map<string, object>}
   */
  collection(name) {
    const collection = this.collections.get(name);
    if (!collection) throw new NotFoundError(`Unknown collection: ${name}`);
    return collection;
  }

  /**
   * Drop all data (used by tests and by reseeding).
   *
   * @returns {void}
   */
  reset() {
    for (const collection of this.collections.values()) collection.clear();
  }

  /**
   * @param {string} name
   * @returns {number}
   */
  count(name) {
    return this.collection(name).size;
  }

  /**
   * @returns {Record<string, number>}
   */
  stats() {
    const stats = { kind: this.kind };
    for (const [name, collection] of this.collections) stats[name] = collection.size;
    return stats;
  }

  // ---------------------------------------------------------------- facilities

  /**
   * @param {ListOptions} [options]
   * @returns {Promise<{items: object[], total: number, limit: number, offset: number}>}
   */
  async listFacilities(options = {}) {
    const items = [...this.collection('facilities').values()].filter((item) =>
      matchesFilters(item, options.filters),
    );
    return paginate(clone(items), {
      ...options,
      sort: options.sort ?? ((a, b) => a.name.localeCompare(b.name)),
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getFacility(id) {
    return clone(this.collection('facilities').get(id) ?? null);
  }

  /** @param {string} id @returns {Promise<object>} */
  async requireFacility(id) {
    const facility = await this.getFacility(id);
    if (!facility) throw new NotFoundError(`Facility not found: ${id}`);
    return facility;
  }

  /** @param {object} facility @returns {Promise<object>} */
  async upsertFacility(facility) {
    this.collection('facilities').set(facility.id, clone(facility));
    return clone(facility);
  }

  // ----------------------------------------------------------------- medicines

  /** @param {ListOptions} [options] */
  async listMedicines(options = {}) {
    const items = [...this.collection('medicines').values()];
    return paginate(clone(items), {
      ...options,
      sort: options.sort ?? ((a, b) => a.name.localeCompare(b.name)),
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getMedicine(id) {
    return clone(this.collection('medicines').get(id) ?? null);
  }

  /** @param {object} medicine @returns {Promise<object>} */
  async upsertMedicine(medicine) {
    this.collection('medicines').set(medicine.id, clone(medicine));
    return clone(medicine);
  }

  // --------------------------------------------------------------------- stock

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.medicineId]
   * @returns {Promise<object[]>}
   */
  async listStockByFacility(filters) {
    const items = [...this.collection('stock').values()].filter((item) =>
      matchesFilters(item, filters),
    );
    return clone(sortBy(items, (a, b) => a.medicineId.localeCompare(b.medicineId)));
  }

  /** @param {string} facilityId @param {string} medicineId @returns {Promise<object|null>} */
  async getStock(facilityId, medicineId) {
    return clone(this.collection('stock').get(`STK-${facilityId}-${medicineId}`) ?? null);
  }

  /**
   * @param {object} line - Must include facilityId and medicineId.
   * @returns {Promise<object>}
   */
  async upsertStock(line) {
    const id = line.id ?? `STK-${line.facilityId}-${line.medicineId}`;
    const record = { ...clone(line), id, updatedAt: new Date().toISOString() };
    this.collection('stock').set(id, record);
    return clone(record);
  }

  /**
   * Append a daily consumption point, keeping the series bounded.
   *
   * @param {string} facilityId
   * @param {string} medicineId
   * @param {{date: string, quantity: number}} point
   * @param {number} [maxPoints]
   * @returns {Promise<object|null>}
   */
  async appendConsumption(facilityId, medicineId, point, maxPoints = 45) {
    const line = this.collection('stock').get(`STK-${facilityId}-${medicineId}`);
    if (!line) return null;
    const series = Array.isArray(line.consumptionSeries) ? [...line.consumptionSeries] : [];
    const existingIndex = series.findIndex((entry) => entry.date === point.date);
    if (existingIndex >= 0) series[existingIndex] = { ...point };
    else series.push({ ...point });
    series.sort((a, b) => a.date.localeCompare(b.date));
    line.consumptionSeries = series.slice(-maxPoints);
    line.updatedAt = new Date().toISOString();
    return clone(line);
  }

  /**
   * Rebuild a consumption series from dispensing records (used when a stock
   * line exists but its cached series has been truncated).
   *
   * @param {string} facilityId
   * @param {string} medicineId
   * @param {number} [days]
   * @param {Date} [today]
   * @returns {Promise<{date: string, quantity: number}[]>}
   */
  async consumptionFromDispensing(facilityId, medicineId, days = 14, today = new Date()) {
    const from = dayKey(addDays(today, -(days - 1)));
    const totals = new Map();
    for (const record of this.collection('dispensing').values()) {
      if (record.facilityId !== facilityId || record.medicineId !== medicineId) continue;
      const date = dayKey(toDate(record.recordedAt) ?? new Date());
      if (date < from) continue;
      totals.set(date, (totals.get(date) ?? 0) + (Number(record.quantity) || 0));
    }
    const series = [];
    for (let offset = days - 1; offset >= 0; offset -= 1) {
      const date = dayKey(addDays(today, -offset));
      series.push({ date, quantity: totals.get(date) ?? 0 });
    }
    return series;
  }

  // ------------------------------------------------------------------- batches

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.medicineId]
   * @returns {Promise<object[]>}
   */
  async listBatches(filters) {
    const items = [...this.collection('batches').values()].filter((item) =>
      matchesFilters(item, filters),
    );
    return clone(sortBy(items, (a, b) => String(a.expiryDate).localeCompare(String(b.expiryDate))));
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getBatch(id) {
    return clone(this.collection('batches').get(id) ?? null);
  }

  /** @param {object} batch @returns {Promise<object>} */
  async upsertBatch(batch) {
    const record = { ...clone(batch), updatedAt: new Date().toISOString() };
    this.collection('batches').set(record.id, record);
    return clone(record);
  }

  /**
   * Remove units from a batch, deleting it when it reaches zero.
   *
   * @param {string} batchId
   * @param {number} units
   * @returns {Promise<object|null>} The updated batch, or null when removed.
   */
  async decrementBatch(batchId, units) {
    const batch = this.collection('batches').get(batchId);
    if (!batch) return null;
    batch.quantity = Math.max(0, (Number(batch.quantity) || 0) - units);
    batch.updatedAt = new Date().toISOString();
    if (batch.quantity === 0) {
      this.collection('batches').delete(batchId);
      return null;
    }
    return clone(batch);
  }

  /** @param {string} batchId @param {number} units @returns {Promise<object|null>} */
  async incrementBatch(batchId, units) {
    const batch = this.collection('batches').get(batchId);
    if (!batch) return null;
    batch.quantity = (Number(batch.quantity) || 0) + units;
    batch.updatedAt = new Date().toISOString();
    return clone(batch);
  }

  // ---------------------------------------------------------------- dispensing

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.medicineId]
   * @param {ListOptions} [options]
   */
  async listDispensing(filters, options = {}) {
    const items = [...this.collection('dispensing').values()].filter((item) =>
      matchesFilters(item, filters),
    );
    return paginate(clone(items), {
      ...options,
      sort:
        options.sort ??
        ((a, b) => String(b.recordedAt).localeCompare(String(a.recordedAt))),
    });
  }

  /** @param {object} record @returns {Promise<object>} */
  async addDispensing(record) {
    const stored = clone(record);
    this.collection('dispensing').set(stored.id, stored);
    return clone(stored);
  }

  // ------------------------------------------------------------------ footfall

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.date]
   * @param {string} [filters.department]
   * @returns {Promise<object[]>}
   */
  async listFootfall(filters) {
    return clone(
      [...this.collection('footfall').values()].filter((item) => matchesFilters(item, filters)),
    );
  }

  /**
   * Footfall rows inside a date range (inclusive).
   *
   * @param {string} facilityId
   * @param {string} fromKey - "YYYY-MM-DD"
   * @param {string} toKey
   * @returns {Promise<object[]>}
   */
  async footfallBetween(facilityId, fromKey, toKey) {
    return clone(
      [...this.collection('footfall').values()].filter(
        (item) => item.facilityId === facilityId && item.date >= fromKey && item.date <= toKey,
      ),
    );
  }

  /** @param {object} row @returns {Promise<object>} */
  async addFootfall(row) {
    const id = row.id ?? `FF-${row.facilityId}-${row.department}-${row.date}-${row.hour}`;
    const stored = { ...clone(row), id };
    this.collection('footfall').set(id, stored);
    return clone(stored);
  }

  // -------------------------------------------------------------------- tokens

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.date]
   * @param {string} [filters.status]
   * @param {ListOptions} [options]
   */
  async listTokens(filters, options = {}) {
    const items = [...this.collection('tokens').values()].filter((item) =>
      matchesFilters(item, filters),
    );
    return paginate(clone(items), {
      ...options,
      sort: options.sort ?? ((a, b) => String(a.issuedAt).localeCompare(String(b.issuedAt))),
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getToken(id) {
    return clone(this.collection('tokens').get(id) ?? null);
  }

  /** @param {object} token @returns {Promise<object>} */
  async addToken(token) {
    const stored = clone(token);
    this.collection('tokens').set(stored.id, stored);
    return clone(stored);
  }

  /**
   * @param {string} id
   * @param {Record<string, unknown>} patch
   * @returns {Promise<object|null>}
   */
  async updateToken(id, patch) {
    const token = this.collection('tokens').get(id);
    if (!token) return null;
    Object.assign(token, clone(patch));
    return clone(token);
  }

  // ------------------------------------------------------------------ counters

  /** @param {string} facilityId @returns {Promise<object[]>} */
  async listCounters(facilityId) {
    return clone(
      sortBy(
        [...this.collection('counters').values()].filter((item) => item.facilityId === facilityId),
        (a, b) => a.counterId - b.counterId,
      ),
    );
  }

  /** @param {object} counter @returns {Promise<object>} */
  async upsertCounter(counter) {
    const id = counter.id ?? `CTR-${counter.facilityId}-${counter.counterId}`;
    const stored = { ...clone(counter), id, updatedAt: new Date().toISOString() };
    this.collection('counters').set(id, stored);
    return clone(stored);
  }

  // --------------------------------------------------------------------- wards

  /** @param {string} facilityId @returns {Promise<object[]>} */
  async listWards(facilityId) {
    return clone(
      [...this.collection('wards').values()].filter((item) => item.facilityId === facilityId),
    );
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getWard(id) {
    return clone(this.collection('wards').get(id) ?? null);
  }

  /** @param {object} ward @returns {Promise<object>} */
  async upsertWard(ward) {
    const stored = { ...clone(ward), updatedAt: new Date().toISOString() };
    this.collection('wards').set(stored.id, stored);
    return clone(stored);
  }

  /** @param {object} event @returns {Promise<object>} */
  async addBedEvent(event) {
    const stored = clone(event);
    this.collection('bedEvents').set(stored.id, stored);
    return clone(stored);
  }

  /**
   * @param {string} facilityId
   * @param {number} [limit]
   * @returns {Promise<object[]>}
   */
  async listBedEvents(facilityId, limit = 50) {
    return clone(
      sortBy(
        [...this.collection('bedEvents').values()].filter((item) => item.facilityId === facilityId),
        (a, b) => String(b.at).localeCompare(String(a.at)),
      ).slice(0, limit),
    );
  }

  // ------------------------------------------------------------------- doctors

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.department]
   * @param {ListOptions} [options]
   */
  async listDoctors(filters, options = {}) {
    const items = [...this.collection('doctors').values()].filter((item) =>
      matchesFilters(item, filters),
    );
    return paginate(clone(items), { ...options, sort: options.sort ?? ((a, b) => a.name.localeCompare(b.name)) });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getDoctor(id) {
    return clone(this.collection('doctors').get(id) ?? null);
  }

  /** @param {object} doctor @returns {Promise<object>} */
  async upsertDoctor(doctor) {
    this.collection('doctors').set(doctor.id, clone(doctor));
    return clone(doctor);
  }

  /**
   * @param {string} doctorId
   * @param {string} [fromKey]
   * @returns {Promise<object[]>}
   */
  async listAttendance(doctorId, fromKey) {
    return clone(
      sortBy(
        [...this.collection('attendance').values()].filter(
          (item) => item.doctorId === doctorId && (!fromKey || item.date >= fromKey),
        ),
        (a, b) => a.date.localeCompare(b.date),
      ),
    );
  }

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.date]
   * @returns {Promise<object[]>}
   */
  async listAttendanceByFacility(filters) {
    return clone(
      [...this.collection('attendance').values()].filter((item) => matchesFilters(item, filters)),
    );
  }

  /** @param {object} record @returns {Promise<object>} */
  async upsertAttendance(record) {
    const id = record.id ?? `ATT-${record.doctorId}-${record.date}`;
    const stored = { ...clone(record), id };
    this.collection('attendance').set(id, stored);
    return clone(stored);
  }

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.date]
   * @returns {Promise<object[]>}
   */
  async listRosters(filters) {
    return clone([...this.collection('rosters').values()].filter((item) => matchesFilters(item, filters)));
  }

  /** @param {object} roster @returns {Promise<object>} */
  async upsertRoster(roster) {
    const id = roster.id ?? `ROS-${roster.doctorId}-${roster.date}`;
    const stored = { ...clone(roster), id };
    this.collection('rosters').set(id, stored);
    return clone(stored);
  }

  /**
   * @param {object} filters
   * @param {string} filters.facilityId
   * @param {string} [filters.date]
   * @returns {Promise<object[]>}
   */
  async listLeaves(filters) {
    return clone([...this.collection('leaves').values()].filter((item) => matchesFilters(item, filters)));
  }

  /** @param {object} leave @returns {Promise<object>} */
  async addLeave(leave) {
    const stored = clone(leave);
    this.collection('leaves').set(stored.id, stored);
    return clone(stored);
  }

  // ----------------------------------------------------------------- referrals

  /**
   * @param {object} [filters]
   * @param {ListOptions} [options]
   */
  async listReferrals(filters = {}, options = {}) {
    const args = listArgs(filters, options);
    const items = [...this.collection('referrals').values()].filter((item) =>
      matchesFilters(item, args.filters),
    );
    return paginate(clone(items), {
      ...args,
      sort: options.sort ?? ((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))),
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getReferral(id) {
    return clone(this.collection('referrals').get(id) ?? null);
  }

  /** @param {object} referral @returns {Promise<object>} */
  async addReferral(referral) {
    const stored = clone(referral);
    this.collection('referrals').set(stored.id, stored);
    return clone(stored);
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateReferral(id, patch) {
    const referral = this.collection('referrals').get(id);
    if (!referral) return null;
    Object.assign(referral, clone(patch));
    return clone(referral);
  }

  // ------------------------------------------------------------------- indents

  /**
   * @param {object} [filters]
   * @param {ListOptions} [options]
   */
  async listIndents(filters = {}, options = {}) {
    const args = listArgs(filters, options);
    const items = [...this.collection('indents').values()].filter((item) =>
      matchesFilters(item, args.filters),
    );
    return paginate(clone(items), {
      ...args,
      sort:
        options.sort ??
        ((a, b) => String(b.requestedAt).localeCompare(String(a.requestedAt))),
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getIndent(id) {
    return clone(this.collection('indents').get(id) ?? null);
  }

  /** @param {object} indent @returns {Promise<object>} */
  async addIndent(indent) {
    const stored = clone(indent);
    this.collection('indents').set(stored.id, stored);
    return clone(stored);
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateIndent(id, patch) {
    const indent = this.collection('indents').get(id);
    if (!indent) return null;
    Object.assign(indent, clone(patch));
    return clone(indent);
  }

  // ----------------------------------------------------------------- transfers

  /**
   * @param {object} [filters]
   * @param {ListOptions} [options]
   */
  async listTransfers(filters = {}, options = {}) {
    const args = listArgs(filters, options);
    const items = [...this.collection('transfers').values()].filter((item) =>
      matchesFilters(item, args.filters),
    );
    return paginate(clone(items), {
      ...args,
      sort: options.sort ?? ((a, b) => String(b.requestedAt).localeCompare(String(a.requestedAt))),
    });
  }

  /** @param {string} id @returns {Promise<object|null>} */
  async getTransfer(id) {
    return clone(this.collection('transfers').get(id) ?? null);
  }

  /** @param {object} transfer @returns {Promise<object>} */
  async addTransfer(transfer) {
    const stored = clone(transfer);
    this.collection('transfers').set(stored.id, stored);
    return clone(stored);
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateTransfer(id, patch) {
    const transfer = this.collection('transfers').get(id);
    if (!transfer) return null;
    Object.assign(transfer, clone(patch));
    return clone(transfer);
  }

  // --------------------------------------------------------------------- audit

  /**
   * @param {object} entry
   * @returns {Promise<object>}
   */
  async addAudit(entry) {
    const stored = clone(entry);
    this.collection('audit').set(stored.id, stored);
    return clone(stored);
  }

  /**
   * @param {object} [filters]
   * @param {ListOptions} [options]
   */
  async listAudit(filters = {}, options = {}) {
    const args = listArgs(filters, options);
    const items = [...this.collection('audit').values()].filter((item) =>
      matchesFilters(item, args.filters),
    );
    return paginate(clone(items), {
      ...args,
      sort: options.sort ?? ((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))),
    });
  }

  // -------------------------------------------------------------------- alerts

  /** @param {object} alert @returns {Promise<object>} */
  async addAlert(alert) {
    const stored = clone(alert);
    this.collection('alerts').set(stored.id, stored);
    return clone(stored);
  }

  /**
   * @param {object} [filters]
   * @param {ListOptions} [options]
   */
  async listAlerts(filters = {}, options = {}) {
    const args = listArgs(filters, options);
    const items = [...this.collection('alerts').values()].filter((item) =>
      matchesFilters(item, args.filters),
    );
    return paginate(clone(items), {
      ...args,
      sort: options.sort ?? ((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))),
    });
  }

  /** @param {string} id @param {Record<string, unknown>} patch @returns {Promise<object|null>} */
  async updateAlert(id, patch) {
    const alert = this.collection('alerts').get(id);
    if (!alert) return null;
    Object.assign(alert, clone(patch));
    return clone(alert);
  }

  // -------------------------------------------------------------------- shared

  /**
   * Bulk insert, mirroring Firestore's batched write API.
   *
   * @param {string} collection
   * @param {object[]} documents
   * @returns {Promise<number>} Number of documents written.
   */
  async bulkWrite(collection, documents) {
    const target = this.collection(collection);
    for (const document of documents) target.set(document.id, clone(document));
    return documents.length;
  }

  /**
   * Group helper exposed so services can share one implementation with the
   * Firestore repository.
   *
   * @template T
   * @param {T[]} items
   * @param {(item: T) => string} keyOf
   * @returns {Map<string, T[]>}
   */
  group(items, keyOf) {
    return groupBy(items, keyOf);
  }

  /**
   * No-op for API compatibility with the Firestore implementation.
   *
   * @returns {Promise<void>}
   */
  async close() {
    return undefined;
  }
}

export default InMemoryRepository;
