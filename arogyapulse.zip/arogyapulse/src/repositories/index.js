/**
 * Repository selection.
 *
 * One import site decides where data lives, driven by environment:
 *
 *   REPOSITORY=memory     -> in-process store, zero configuration, always works
 *   REPOSITORY=firestore  -> Cloud Firestore (needs GOOGLE_CLOUD_PROJECT or ADC)
 *   unset + GOOGLE_CLOUD_PROJECT / FIRESTORE_EMULATOR_HOST -> firestore
 *   unset + nothing else  -> memory
 *
 * `createRepository` is also the seam used by tests: a fake `db` object can be
 * injected into the Firestore implementation, and the in-memory store can be
 * constructed directly.
 *
 * @module repositories
 */

import config from '../config/env.js';
import { InMemoryRepository } from './inMemoryRepository.js';
import { FirestoreRepository } from './firestoreRepository.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('repositories');

/** @type {{repository: object, kind: string}|null} */
let singleton = null;

/**
 * @typedef {InMemoryRepository|FirestoreRepository} Repository
 */

/**
 * Create a repository instance (no caching).
 *
 * @param {object} [options]
 * @param {'memory'|'firestore'} [options.kind]
 * @param {object} [options.db] - Injected Firestore instance for tests.
 * @param {string} [options.projectId]
 * @returns {Promise<Repository>}
 */
export async function createRepository(options = {}) {
  const kind = options.kind ?? config.repository;
  if (kind === 'firestore') {
    log.info('Using Cloud Firestore repository', {
      projectId: options.projectId ?? config.googleCloudProject ?? '(from ADC)',
    });
    return new FirestoreRepository({ db: options.db, projectId: options.projectId });
  }
  log.info('Using in-memory repository (zero-configuration demo mode)');
  return new InMemoryRepository();
}

/**
 * Process-wide repository singleton, created on first use.
 *
 * @param {object} [options] - Forwarded to {@link createRepository} on first call.
 * @returns {Promise<Repository>}
 */
export async function getRepository(options) {
  if (!singleton) {
    const repository = await createRepository(options);
    singleton = { repository, kind: repository.kind };
  }
  return singleton.repository;
}

/**
 * Replace the singleton (used by tests and by reseeding).
 *
 * @param {Repository} repository
 * @returns {Repository}
 */
export function setRepository(repository) {
  singleton = { repository, kind: repository.kind };
  return repository;
}

/**
 * Drop the singleton, closing Firestore if it was open.
 *
 * @returns {Promise<void>}
 */
export async function resetRepository() {
  if (singleton?.repository?.close) await singleton.repository.close();
  singleton = null;
}

export { InMemoryRepository, FirestoreRepository };
export default getRepository;
