/**
 * Geographic helpers (pure).
 *
 * Used to rank transfer donors by distance so a two-wheeler or ambulance can
 * actually make the trip the same day.
 *
 * @module services/geo
 */

const EARTH_RADIUS_KM = 6371.0088;

/**
 * Great-circle distance between two coordinates (haversine).
 *
 * @param {{latitude: number, longitude: number}} a
 * @param {{latitude: number, longitude: number}} b
 * @returns {number} Distance in kilometres, rounded to 2 decimals.
 */
export function haversineKm(a, b) {
  if (!a || !b) return Number.POSITIVE_INFINITY;
  const toRadians = (degrees) => (degrees * Math.PI) / 180;
  const dLat = toRadians(b.latitude - a.latitude);
  const dLon = toRadians(b.longitude - a.longitude);
  const lat1 = toRadians(a.latitude);
  const lat2 = toRadians(b.latitude);

  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  const distance = 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(h)));
  return Math.round(distance * 100) / 100;
}

/**
 * Google Maps deep link for a facility ("Open in Google Maps" per facility).
 *
 * @param {{name?: string, latitude?: number, longitude?: number, address?: string}} facility
 * @returns {string} Absolute https URL.
 */
export function mapsUrl(facility) {
  if (!facility) return 'https://www.google.com/maps';
  const hasCoordinates =
    Number.isFinite(facility.latitude) && Number.isFinite(facility.longitude);
  const query = hasCoordinates
    ? `${facility.latitude},${facility.longitude}`
    : `${facility.name ?? ''} ${facility.address ?? ''}`.trim();
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}
