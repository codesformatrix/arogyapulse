/**
 * Stock service.
 *
 * Orchestrates the pure forecast/FEFO functions against a repository and makes
 * sure every mutation leaves behind an audit entry. This is the only place
 * stock quantity changes, which is what makes the audit log trustworthy.
 *
 * @module services/stockService
 */

import { ADJUSTMENT_REASONS, INDENT, MOVEMENT_REASONS } from '../config/constants.js';
import { BusinessRuleError, NotFoundError } from '../utils/errors.js';
import { newId, uuid } from '../utils/ids.js';
import { createLogger } from '../utils/logger.js';
import { addDays, dayKey, toDate } from '../utils/time.js';
import { invalidateFor } from '../utils/caches.js';
import { allocateFefo, batchStatus, fefoOrder, totalUnits } from './inventory.js';
import { forecastLine } from './forecast.js';
import { buildIndent } from './indent.js';

const log = createLogger('stock.service');

/** Default window used when building a forecast for a stock line. */
const FORECAST_WINDOW_DAYS = 14;

/**
 * Build the consumption series for a stock line, preferring the cached series
 * stored on the document and falling back to dispensing records.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {string} medicineId
 * @param {object} [stockLine]
 * @returns {Promise<{date: string, quantity: number}[]>}
 */
async function consumptionSeriesFor(repository, facilityId, medicineId, stockLine) {
  const cached = stockLine?.consumptionSeries;
  if (Array.isArray(cached) && cached.length >= FORECAST_WINDOW_DAYS) return cached;
  const rebuilt = await repository.consumptionFromDispensing(
    facilityId,
    medicineId,
    FORECAST_WINDOW_DAYS,
  );
  return rebuilt;
}

/**
 * Full view of one facility's inventory: stock, batches, forecast and status.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {object} [options]
 * @param {string} [options.todayKey]
 * @param {Date} [options.now]
 * @returns {Promise<object[]>} One entry per medicine, worst first.
 */
export async function inventoryView(repository, facilityId, options = {}) {
  const todayKey = options.todayKey ?? dayKey(options.now ?? new Date());
  const [stockLines, batches] = await Promise.all([
    repository.listStockByFacility({ facilityId }),
    repository.listBatches({ facilityId }),
  ]);

  const batchesByMedicine = new Map();
  for (const batch of batches) {
    const bucket = batchesByMedicine.get(batch.medicineId);
    if (bucket) bucket.push(batch);
    else batchesByMedicine.set(batch.medicineId, [batch]);
  }

  const lines = [];
  for (const line of stockLines) {
    const medicineBatches = batchesByMedicine.get(line.medicineId) ?? [];
    const series = await consumptionSeriesFor(repository, facilityId, line.medicineId, line);
    const medicine = await repository.getMedicine(line.medicineId);
    const forecast = forecastLine(
      {
        stock: totalUnits(medicineBatches.length ? medicineBatches : [{ quantity: line.units, expiryDate: addDays(new Date(), 365) }]),
        reorderLevel: line.reorderLevel,
        consumptionSeries: series,
        batches: medicineBatches,
        todayKey,
      },
      { autoIndentDays: INDENT.AUTO_TRIGGER_DAYS },
    );

    lines.push({
      medicineId: line.medicineId,
      medicineName: medicine?.name ?? line.medicineId,
      medicineNameHi: medicine?.nameHi ?? line.medicineId,
      strength: medicine?.strength ?? '',
      unit: medicine?.unit ?? 'unit',
      coldChain: Boolean(medicine?.coldChain),
      critical: Boolean(medicine?.critical),
      batchCount: medicineBatches.length,
      nextExpiry: medicineBatches.length
        ? fefoOrder(medicineBatches, todayKey)[0]?.expiryDate ?? null
        : null,
      ...forecast,
    });
  }

  const weight = { RED: 0, AMBER: 1, EXPIRY_RISK: 2, GREEN: 3 };
  return lines.sort(
    (a, b) =>
      (weight[a.status] ?? 9) - (weight[b.status] ?? 9) ||
      (a.daysOfCover ?? 9999) - (b.daysOfCover ?? 9999),
  );
}

/**
 * Apply a stock adjustment (receipt, write-off, correction) with FEFO batch
 * handling and an audit entry.
 *
 * @param {object} repository
 * @param {object} input
 * @param {string} input.facilityId
 * @param {string} input.medicineId
 * @param {number} input.delta - Positive for receipts, negative for write-offs.
 * @param {string} input.reason - One of ADJUSTMENT_REASONS.
 * @param {string} [input.batchNo]
 * @param {string} [input.expiryDate] - "YYYY-MM-DD", required for receipts.
 * @param {string} [input.note]
 * @param {object} actor
 * @returns {Promise<{stock: object, forecast: object, batch: object|null}>}
 */
export async function adjustStock(repository, input, actor) {
  const todayKey = dayKey(new Date());
  const stockLine = await repository.getStock(input.facilityId, input.medicineId);
  if (!stockLine) {
    throw new NotFoundError(`No stock line for ${input.medicineId} at ${input.facilityId}`);
  }
  const before = totalUnits(await repository.listBatches(input));

  let batch = null;

  if (input.delta > 0) {
    // Receipts always land in a batch: without one there is no expiry to track.
    const expiryDate =
      input.expiryDate ?? dayKey(addDays(new Date(), 365));
    batch = await repository.upsertBatch({
      id: newId('BAT'),
      facilityId: input.facilityId,
      medicineId: input.medicineId,
      batchNo: input.batchNo ?? `B${Date.now().toString(36).toUpperCase()}`,
      quantity: input.delta,
      expiryDate,
      receivedAt: new Date().toISOString(),
      status: batchStatus({ expiryDate }, { todayKey }),
    });
  } else {
    // Write-offs consume the soonest-expiring stock first.
    const batches = await repository.listBatches({
      facilityId: input.facilityId,
      medicineId: input.medicineId,
    });
    const { allocations, shortfall } = allocateFefo(batches, Math.abs(input.delta), todayKey);
    if (shortfall > 0) {
      throw new BusinessRuleError(
        `Only ${allocations.reduce((total, allocation) => total + allocation.quantity, 0)} units available to write off`,
        { shortfall },
      );
    }
    for (const allocation of allocations) {
      await repository.decrementBatch(allocation.batchId, allocation.quantity);
    }
  }

  const batchesAfter = await repository.listBatches({
    facilityId: input.facilityId,
    medicineId: input.medicineId,
  });
  const unitsAfter = totalUnits(batchesAfter);

  const updated = await repository.upsertStock({
    ...stockLine,
    units: unitsAfter,
    lastMovementAt: new Date().toISOString(),
  });

  const series = await consumptionSeriesFor(
    repository,
    input.facilityId,
    input.medicineId,
    updated,
  );
  const forecast = forecastLine(
    {
      stock: unitsAfter,
      reorderLevel: updated.reorderLevel,
      consumptionSeries: series,
      batches: batchesAfter,
      todayKey,
    },
    { autoIndentDays: INDENT.AUTO_TRIGGER_DAYS },
  );

  await repository.addAudit({
    id: uuid(),
    entityType: 'STOCK',
    entityId: updated.id,
    facilityId: input.facilityId,
    action: 'ADJUST',
    actor: actor.subject,
    role: actor.role,
    before: { units: before },
    after: { units: unitsAfter, delta: input.delta },
    reason: input.reason,
    note: input.note ?? null,
    metadata: { batchId: batch?.id ?? null, batchNo: input.batchNo ?? null },
    createdAt: new Date().toISOString(),
  });

  invalidateFor(input.facilityId);
  log.info('Stock adjusted', {
    facilityId: input.facilityId,
    medicineId: input.medicineId,
    delta: input.delta,
    reason: input.reason,
    actor: actor.subject,
  });

  return { stock: updated, forecast, batch };
}

/**
 * Record dispensing: allocate FEFO, log the movement, update today's
 * consumption point and return the refreshed forecast.
 *
 * @param {object} repository
 * @param {object} input
 * @param {string} input.facilityId
 * @param {string} input.medicineId
 * @param {number} input.quantity
 * @param {string} [input.token]
 * @param {number} [input.counterId]
 * @param {object} actor
 * @returns {Promise<{forecast: object, fulfilled: number, allocations: object[]}>}
 */
export async function recordDispensing(repository, input, actor) {
  const todayKey = dayKey(new Date());
  const batches = await repository.listBatches({
    facilityId: input.facilityId,
    medicineId: input.medicineId,
  });

  const { allocations, fulfilled, shortfall } = allocateFefo(batches, input.quantity, todayKey);
  if (fulfilled === 0) {
    throw new BusinessRuleError('No usable stock to dispense (empty or all expired)', {
      shortfall,
    });
  }

  for (const allocation of allocations) {
    await repository.decrementBatch(allocation.batchId, allocation.quantity);
  }

  const batchesAfter = await repository.listBatches({
    facilityId: input.facilityId,
    medicineId: input.medicineId,
  });
  const stockLine = await repository.getStock(input.facilityId, input.medicineId);
  if (!stockLine) throw new NotFoundError('Stock line missing');

  const updated = await repository.upsertStock({
    ...stockLine,
    units: totalUnits(batchesAfter),
    lastMovementAt: new Date().toISOString(),
  });

  // Keep the daily consumption point accurate: add to whatever is already
  // recorded for today rather than overwriting it.
  const series = await consumptionSeriesFor(repository, input.facilityId, input.medicineId, updated);
  const todayIndex = series.findIndex((entry) => entry.date === todayKey);
  const alreadyToday = todayIndex >= 0 ? series[todayIndex].quantity : 0;
  await repository.appendConsumption(
    input.facilityId,
    input.medicineId,
    { date: todayKey, quantity: alreadyToday + fulfilled },
  );

  await repository.addDispensing({
    id: newId('DSP'),
    facilityId: input.facilityId,
    medicineId: input.medicineId,
    quantity: fulfilled,
    token: input.token ?? null,
    counterId: input.counterId ?? null,
    reason: MOVEMENT_REASONS.DISPENSING,
    recordedBy: actor.subject,
    recordedAt: new Date().toISOString(),
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'STOCK',
    entityId: updated.id,
    facilityId: input.facilityId,
    action: 'DISPENSE',
    actor: actor.subject,
    role: actor.role,
    before: { units: stockLine.units },
    after: { units: updated.units, quantity: fulfilled },
    reason: MOVEMENT_REASONS.DISPENSING,
    metadata: { allocations, shortfall, token: input.token ?? null },
    createdAt: new Date().toISOString(),
  });

  const seriesAfter = await consumptionSeriesFor(
    repository,
    input.facilityId,
    input.medicineId,
    updated,
  );
  const forecast = forecastLine(
    {
      stock: updated.units,
      reorderLevel: updated.reorderLevel,
      consumptionSeries: seriesAfter,
      batches: batchesAfter,
      todayKey,
    },
    { autoIndentDays: INDENT.AUTO_TRIGGER_DAYS },
  );

  invalidateFor(input.facilityId);
  return { forecast, fulfilled, shortfall, allocations };
}

/**
 * Raise an indent automatically for every line below the trigger threshold.
 *
 * Called after stock movements and on boot, so a stock-out never waits for
 * somebody to remember to file a requisition.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {object} [options]
 * @param {object} [options.actor]
 * @param {'AUTO'|'MANUAL'} [options.source]
 * @returns {Promise<object|null>} The created indent, or null when none is needed.
 */
export async function autoIndent(repository, facilityId, options = {}) {
  const lines = await inventoryView(repository, facilityId);
  const facility = await repository.getFacility(facilityId);
  const { needed, document } = buildIndent(
    {
      facilityId,
      facilityName: facility?.name ?? facilityId,
      lines,
    },
    { source: options.source ?? 'AUTO', requestedById: options.actor?.subject ?? 'system:auto-indent' },
  );

  if (!needed) return null;

  const indent = { ...document, id: newId('IND') };
  await repository.addIndent(indent);
  await repository.addAudit({
    id: uuid(),
    entityType: 'INDENT',
    entityId: indent.id,
    facilityId,
    action: 'CREATE',
    actor: indent.requestedBy,
    role: options.actor?.role ?? 'system',
    after: { totalItems: indent.totalItems, totalUnits: indent.totalUnits },
    reason: indent.source === 'AUTO' ? 'AUTO_INDENT' : 'MANUAL_INDENT',
    createdAt: new Date().toISOString(),
  });

  invalidateFor(facilityId);
  log.info('Indent raised', { facilityId, items: indent.totalItems, units: indent.totalUnits });
  return indent;
}

/**
 * Batches needing action at a facility (expired or near expiry).
 *
 * @param {object} repository
 * @param {string} facilityId
 * @returns {Promise<object[]>}
 */
export async function expiryWatch(repository, facilityId) {
  const todayKey = dayKey(new Date());
  const batches = await repository.listBatches({ facilityId });
  return batches
    .map((batch) => ({ ...batch, status: batchStatus(batch, { todayKey }), todayKey }))
    .filter((batch) => batch.status !== 'ACTIVE')
    .sort((a, b) => String(a.expiryDate).localeCompare(String(b.expiryDate)));
}

export { ADJUSTMENT_REASONS, toDate };
