/**
 * OPD queue and footfall analytics (pure).
 *
 * Everything here is derived from anonymous token records - counts and timings
 * only, never patient identity - which is what makes a public "how crowded is
 * it now" page both useful and privacy safe.
 *
 * @module services/waitTime
 */

import { QUEUE } from '../config/constants.js';
import { mean, round } from '../utils/random.js';

/**
 * @typedef {Object} QueueState
 * @property {number} waiting - Tokens currently waiting.
 * @property {number} activeCounters - Counters open right now.
 * @property {number} [avgServiceMinutes] - Observed mean consultation time.
 * @property {number} [arrivalsPerHour] - Live arrival rate (for short waits).
 */

/**
 * @typedef {Object} WaitEstimate
 * @property {number} estimatedWaitMinutes
 * @property {number} aheadOfYou - Tokens ahead of a newly issued token.
 * @property {number} activeCounters
 * @property {number} avgServiceMinutes
 * @property {string} load - 'LOW' | 'MODERATE' | 'HIGH'
 * @property {string} advice - One-line guidance shown to the public.
 */

/**
 * Effective service rate: how many patients the OPD clears per minute.
 *
 * When the live arrival rate exceeds the service rate the queue is genuinely
 * growing, so the wait is projected from arrivals rather than from the current
 * queue length alone.
 *
 * @param {QueueState} state
 * @returns {number} Patients per minute (0 when nothing can be computed).
 */
export function effectiveServiceRate(state) {
  const counters = Math.max(0, Math.floor(Number(state?.activeCounters) || 0));
  const serviceMinutes = Math.max(
    0.5,
    Number(state?.avgServiceMinutes) || QUEUE.DEFAULT_SERVICE_MINUTES,
  );
  if (counters === 0) return 0;
  return counters / serviceMinutes;
}

/**
 * Estimated wait for the next patient to join the queue.
 *
 * @param {QueueState} state
 * @param {object} [options]
 * @param {number} [options.defaultServiceMinutes]
 * @returns {WaitEstimate}
 */
export function estimateWaitTime(state, options = {}) {
  const waiting = Math.max(0, Math.floor(Number(state?.waiting) || 0));
  const counters = Math.max(0, Math.floor(Number(state?.activeCounters) || 0));
  const avgServiceMinutes = Math.max(
    0.5,
    Number(state?.avgServiceMinutes) ||
      options.defaultServiceMinutes ||
      QUEUE.DEFAULT_SERVICE_MINUTES,
  );

  if (counters === 0) {
    return {
      estimatedWaitMinutes: 0,
      aheadOfYou: waiting,
      activeCounters: 0,
      avgServiceMinutes: round(avgServiceMinutes, 1),
      load: waiting > 0 ? 'HIGH' : 'LOW',
      advice: waiting > 0
        ? 'No counter is open right now. Please check with the help desk.'
        : 'No counter is open right now.',
    };
  }

  const rate = effectiveServiceRate({ ...state, avgServiceMinutes });
  const arrivalsPerHour = Number(state?.arrivalsPerHour) || 0;
  const arrivalsPerMinute = arrivalsPerHour / 60;

  // Queueing projection: if people arrive faster than they are served, the
  // effective drain rate shrinks towards zero.
  const drainRate = Math.max(0.02, rate - arrivalsPerMinute);
  const estimated = rate > 0 ? waiting / drainRate : waiting * avgServiceMinutes;

  const estimatedWaitMinutes = Math.max(0, Math.round(estimated));
  const load = loadBand(estimatedWaitMinutes);

  return {
    estimatedWaitMinutes,
    aheadOfYou: waiting,
    activeCounters: counters,
    avgServiceMinutes: round(avgServiceMinutes, 1),
    load,
    advice: adviceFor(load, estimatedWaitMinutes),
  };
}

/**
 * Map a wait to a named band.
 *
 * @param {number} waitMinutes
 * @param {{id: string, maxWaitMinutes: number}[]} [bands]
 * @returns {'LOW'|'MODERATE'|'HIGH'}
 */
export function loadBand(waitMinutes, bands = QUEUE.LOAD_BANDS) {
  const low = bands[0]?.maxWaitMinutes ?? 15;
  const moderate = bands[1]?.maxWaitMinutes ?? 45;
  if (waitMinutes <= low) return 'LOW';
  if (waitMinutes <= moderate) return 'MODERATE';
  return 'HIGH';
}

/**
 * Short, plain-language guidance for the public page (never medical advice).
 *
 * @param {'LOW'|'MODERATE'|'HIGH'} load
 * @param {number} waitMinutes
 * @returns {string}
 */
export function adviceFor(load, waitMinutes) {
  if (load === 'LOW') return 'Not crowded right now. Average wait is about 10 minutes.';
  if (load === 'MODERATE') return `Moderate crowd. Expected wait is about ${waitMinutes} minutes.`;
  return `Very crowded. Expected wait is about ${waitMinutes} minutes - consider a later slot or the nearest facility.`;
}

/**
 * Average consultation time observed from completed tokens.
 *
 * @param {{issuedAt: string|Date, servedAt: string|Date}[]} tokens
 * @param {(a: string|Date, b: string|Date) => number} diffMinutesFn - Injected to stay pure.
 * @returns {number} Minutes, or the default when there is no history.
 */
export function observedServiceMinutes(tokens, diffMinutesFn) {
  if (!Array.isArray(tokens) || tokens.length === 0) return QUEUE.DEFAULT_SERVICE_MINUTES;
  const durations = tokens
    .map((token) => diffMinutesFn(token.issuedAt, token.servedAt))
    .filter((minutes) => Number.isFinite(minutes) && minutes > 0 && minutes < 240);
  if (durations.length === 0) return QUEUE.DEFAULT_SERVICE_MINUTES;
  return round(mean(durations), 1);
}

/**
 * Predict the peak hours for a given weekday from the last N days of the same
 * weekday (default: the last 14 days, i.e. the two previous occurrences).
 *
 * @param {{date: string, hour: number, count: number}[]} history - Hourly footfall rows.
 * @param {object} options
 * @param {number} options.weekday - 0 (Sunday) - 6 (Saturday).
 * @param {string} [options.todayKey] - "YYYY-MM-DD"; used to pick the window.
 * @param {number} [options.historyDays]
 * @param {number} [options.topN]
 * @returns {{hour: number, avgCount: number}[]} Top N hours, busiest first.
 */
export function predictedPeakHours(history, options) {
  const topN = options.topN ?? 3;
  const historyDays = options.historyDays ?? QUEUE.HISTORY_DAYS;
  const rows = Array.isArray(history) ? history : [];
  if (rows.length === 0 || !Number.isInteger(options.weekday)) return [];

  const cutoffKey = cutoffDayKey(options.todayKey, historyDays);
  const relevant = rows.filter(
    (row) =>
      Number(row?.weekday) === options.weekday &&
      (!cutoffKey || String(row.date) >= cutoffKey) &&
      Number(row?.count) >= 0,
  );
  if (relevant.length === 0) return [];

  const byHour = new Map();
  for (const row of relevant) {
    const hour = Number(row.hour);
    byHour.set(hour, (byHour.get(hour) ?? 0) + Number(row.count));
  }
  const occurrences = new Set(relevant.map((row) => String(row.date))).size || 1;

  return [...byHour.entries()]
    .map(([hour, total]) => ({ hour, avgCount: round(total / occurrences, 1) }))
    .sort((a, b) => b.avgCount - a.avgCount || a.hour - b.hour)
    .slice(0, topN);
}

/**
 * Aggregate token/visit rows into a 24-slot hourly series.
 *
 * @param {{hour: number, count?: number}[]} rows
 * @param {number} [startHour]
 * @param {number} [endHour]
 * @returns {{hour: number, count: number}[]}
 */
export function hourlySeries(rows, startHour = QUEUE.OPD_START_HOUR, endHour = QUEUE.OPD_END_HOUR) {
  const totals = new Map();
  for (const row of rows ?? []) {
    const hour = Number(row?.hour);
    if (!Number.isInteger(hour)) continue;
    totals.set(hour, (totals.get(hour) ?? 0) + Math.max(0, Number(row.count) || 0));
  }
  const series = [];
  for (let hour = startHour; hour <= endHour; hour += 1) {
    series.push({ hour, count: totals.get(hour) ?? 0 });
  }
  return series;
}

/**
 * Compare today's footfall so far with the same weekday's historical average.
 *
 * @param {number} todaySoFar
 * @param {number} historicalAverage
 * @returns {{deltaPercent: number, trend: 'UP'|'DOWN'|'FLAT'}}
 */
export function footfallTrend(todaySoFar, historicalAverage) {
  const baseline = Number(historicalAverage) || 0;
  if (baseline <= 0) return { deltaPercent: 0, trend: 'FLAT' };
  const deltaPercent = round(((Number(todaySoFar) || 0) - baseline) / baseline * 100, 1);
  const trend = deltaPercent > 10 ? 'UP' : deltaPercent < -10 ? 'DOWN' : 'FLAT';
  return { deltaPercent, trend };
}

/**
 * Derive a day key N days before a reference day, without depending on the
 * timezone module (keeps this service import-light and fully pure).
 *
 * @param {string|undefined} todayKey
 * @param {number} days
 * @returns {string|null}
 */
function cutoffDayKey(todayKey, days) {
  if (!todayKey) return null;
  const time = Date.parse(`${todayKey}T00:00:00Z`);
  if (Number.isNaN(time)) return null;
  const cutoff = new Date(time - days * 86_400_000);
  return cutoff.toISOString().slice(0, 10);
}
