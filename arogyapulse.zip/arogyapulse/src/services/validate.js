/**
 * Zod validation runner.
 *
 * Every controller parses its input through {@link parseWith} before anything
 * touches a repository, so an invalid payload can never reach business logic
 * and no stack trace can ever escape to a client.
 *
 * @module services/validate
 */

import { ValidationError } from '../utils/errors.js';

/**
 * @typedef {Object} ParseFailure
 * @property {string} path - Dotted path to the offending field.
 * @property {string} message
 * @property {string} [code]
 */

/**
 * Parse a payload, throwing a ValidationError with a machine readable issue list.
 *
 * @template T
 * @param {import('zod').ZodType<T>} schema
 * @param {unknown} data
 * @param {string} [context] - Used in the error message, e.g. "stock.adjust".
 * @returns {T} The parsed (and coerced/defaulted) value.
 * @throws {ValidationError}
 */
export function parseWith(schema, data, context = 'request') {
  const result = schema.safeParse(data);
  if (result.success) return result.data;
  const issues = result.error.issues.map((issue) => ({
    path: issue.path.join('.') || '(root)',
    message: issue.message,
    code: issue.code,
  }));
  throw new ValidationError(`Invalid ${context} payload`, issues);
}

/**
 * Non-throwing variant for optional enrichment (e.g. query string defaults).
 *
 * @template T
 * @param {import('zod').ZodType<T>} schema
 * @param {unknown} data
 * @param {T} fallback
 * @returns {T}
 */
export function parseOr(schema, data, fallback) {
  const result = schema.safeParse(data);
  return result.success ? result.data : fallback;
}

/**
 * Format zod issues for a JSON API response body.
 *
 * @param {ParseFailure[]} issues
 * @returns {{field: string, message: string}[]}
 */
export function formatIssues(issues) {
  return (issues ?? []).map((issue) => ({ field: issue.path, message: issue.message }));
}
