/**
 * Bed and ward service.
 *
 * Updates are one-tap +/- changes because that is what a nurse can actually do
 * while standing in a ward. Every change is bounded by ward capacity and
 * audited.
 *
 * @module services/bedService
 */

import { BEDS } from '../config/constants.js';
import { BusinessRuleError, NotFoundError } from '../utils/errors.js';
import { newId, uuid } from '../utils/ids.js';
import { invalidateFor } from '../utils/caches.js';

/**
 * @typedef {Object} WardView
 * @property {string} id
 * @property {string} name
 * @property {number} total
 * @property {number} occupied
 * @property {number} reserved
 * @property {number} available
 * @property {number} occupancyPercent
 * @property {boolean} reservedAlert
 */

/**
 * Decorate a stored ward with derived availability figures.
 *
 * @param {object} ward
 * @returns {WardView}
 */
export function wardView(ward) {
  const total = Math.max(0, Number(ward?.total) || 0);
  const occupied = Math.min(total, Math.max(0, Number(ward?.occupied) || 0));
  const reserved = Math.min(total - occupied, Math.max(0, Number(ward?.reserved) || 0));
  const available = Math.max(0, total - occupied - reserved);

  return {
    id: ward.id,
    facilityId: ward.facilityId,
    name: ward.name,
    total,
    occupied,
    reserved,
    available,
    occupancyPercent: total > 0 ? Math.round(((occupied + reserved) / total) * 1000) / 10 : 0,
    reservedAlert: total > 0 && reserved / total >= BEDS.RESERVED_SHARE_ALERT,
    updatedAt: ward.updatedAt ?? null,
  };
}

/**
 * All wards at a facility plus a rollup.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @returns {Promise<{wards: WardView[], summary: object}>}
 */
export async function bedAvailability(repository, facilityId) {
  const wards = (await repository.listWards(facilityId)).map(wardView);
  const total = wards.reduce((sum, ward) => sum + ward.total, 0);
  const occupied = wards.reduce((sum, ward) => sum + ward.occupied, 0);
  const reserved = wards.reduce((sum, ward) => sum + ward.reserved, 0);
  const available = Math.max(0, total - occupied - reserved);

  return {
    facilityId,
    wards,
    summary: {
      total,
      occupied,
      reserved,
      available,
      occupancyPercent: total > 0 ? Math.round(((occupied + reserved) / total) * 1000) / 10 : 0,
      status: available === 0 ? 'FULL' : available <= 2 ? 'TIGHT' : 'AVAILABLE',
    },
  };
}

/**
 * Apply a one-tap bed change.
 *
 * @param {object} repository
 * @param {string} wardId
 * @param {object} input
 * @param {'occupied'|'reserved'} input.field
 * @param {number} input.delta - +1 / -1 in practice, bounded for safety.
 * @param {string} [input.reason]
 * @param {object} actor
 * @returns {Promise<WardView>}
 */
export async function updateBed(repository, wardId, input, actor) {
  const ward = await repository.getWard(wardId);
  if (!ward) throw new NotFoundError(`Ward not found: ${wardId}`);

  const before = wardView(ward);
  const next = { ...before };
  next[input.field] = Math.max(0, before[input.field] + input.delta);

  if (next.occupied > before.total) {
    throw new BusinessRuleError(`Ward '${before.name}' only has ${before.total} beds`, {
      total: before.total,
    });
  }
  if (next.occupied + next.reserved > before.total) {
    throw new BusinessRuleError(
      `Only ${Math.max(0, before.total - before.occupied - before.reserved)} bed(s) free in '${before.name}'`,
      { available: before.available },
    );
  }

  const updated = await repository.upsertWard({
    ...ward,
    occupied: next.occupied,
    reserved: next.reserved,
  });

  await repository.addBedEvent({
    id: newId('BED'),
    facilityId: ward.facilityId,
    wardId,
    field: input.field,
    delta: input.delta,
    before: { occupied: before.occupied, reserved: before.reserved },
    after: { occupied: next.occupied, reserved: next.reserved },
    by: actor.subject,
    reason: input.reason ?? null,
    at: new Date().toISOString(),
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'BED',
    entityId: wardId,
    facilityId: ward.facilityId,
    action: 'UPDATE',
    actor: actor.subject,
    role: actor.role,
    before: { occupied: before.occupied, reserved: before.reserved },
    after: { occupied: next.occupied, reserved: next.reserved },
    reason: input.reason ?? null,
    createdAt: new Date().toISOString(),
  });

  invalidateFor(ward.facilityId);
  return wardView(updated);
}

/**
 * Create or update a ward definition.
 *
 * @param {object} repository
 * @param {string} wardId
 * @param {object} input
 * @param {object} actor
 * @returns {Promise<WardView>}
 */
export async function upsertWard(repository, wardId, input, actor) {
  if (input.occupied + input.reserved > input.total) {
    throw new BusinessRuleError('Occupied + reserved cannot exceed total beds');
  }

  const ward = await repository.upsertWard({
    id: wardId,
    facilityId: actor.facilityId,
    name: input.name,
    total: input.total,
    occupied: input.occupied,
    reserved: input.reserved,
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'WARD',
    entityId: wardId,
    facilityId: actor.facilityId,
    action: 'UPSERT',
    actor: actor.subject,
    role: actor.role,
    after: { total: input.total, occupied: input.occupied, reserved: input.reserved },
    createdAt: new Date().toISOString(),
  });

  invalidateFor(actor.facilityId);
  return wardView(ward);
}
