/**
 * Indent (requisition) generation (pure).
 *
 * An indent is auto-raised when days-of-cover falls below a threshold, so a
 * pharmacist never has to remember to ask the district drug store for stock.
 * The quantity is computed from the same forecast the dashboard displays, so
 * the two can never disagree.
 *
 * @module services/indent
 */

import { INDENT, INDENT_STATUS } from '../config/constants.js';
import { dayKey, toDate } from '../utils/time.js';
import { round } from '../utils/random.js';

/**
 * Should an indent be raised for this line?
 *
 * @param {{daysOfCover: number|null, stock: number, status?: string}} line
 * @param {object} [policy]
 * @param {number} [policy.autoTriggerDays]
 * @returns {boolean}
 */
export function needsIndent(line, policy = {}) {
  const threshold = policy.autoTriggerDays ?? INDENT.AUTO_TRIGGER_DAYS;
  if (!line) return false;
  if ((Number(line.stock) || 0) <= 0) return true;
  if (line.status === 'RED') return true;
  const cover = line.daysOfCover;
  if (cover === null || cover === undefined) return false;
  return cover <= threshold;
}

/**
 * Urgency band used to sort the district's indent queue.
 *
 * @param {{daysOfCover: number|null, stock: number}} line
 * @returns {'CRITICAL'|'HIGH'|'MEDIUM'}
 */
export function indentPriority(line) {
  const cover = line?.daysOfCover;
  const stock = Number(line?.stock) || 0;
  if (stock <= 0 || (cover !== null && cover !== undefined && cover < 1)) return 'CRITICAL';
  if (cover !== null && cover !== undefined && cover < 3) return 'CRITICAL';
  if (cover !== null && cover !== undefined && cover < 7) return 'HIGH';
  return 'MEDIUM';
}

/**
 * A single indent line item.
 *
 * @param {object} input
 * @param {string} input.medicineId
 * @param {string} input.medicineName
 * @param {number} input.stock
 * @param {number} input.perDay
 * @param {number} input.daysOfCover
 * @param {number} input.units
 * @returns {{medicineId: string, medicineName: string, currentStock: number, forecastPerDay: number, daysOfCover: number|null, units: number, priority: string}}
 */
export function indentItem(input) {
  return {
    medicineId: input.medicineId,
    medicineName: input.medicineName,
    currentStock: Math.max(0, Math.floor(Number(input.stock) || 0)),
    forecastPerDay: round(Number(input.perDay) || 0, 2),
    daysOfCover: input.daysOfCover ?? null,
    units: Math.max(0, Math.ceil(Number(input.units) || 0)),
    priority: indentPriority({ stock: input.stock, daysOfCover: input.daysOfCover }),
  };
}

/**
 * Build a complete indent document from forecast lines.
 *
 * @param {object} input
 * @param {string} input.facilityId
 * @param {string} input.facilityName
 * @param {{medicineId: string, medicineName: string, stock: number, perDay: number, daysOfCover: number|null, suggestedReorderUnits: number}[]} input.lines
 * @param {object} [options]
 * @param {string} [options.todayKey]
 * @param {number} [options.autoTriggerDays]
 * @param {string} [options.requestedById]
 * @param {'AUTO'|'MANUAL'} [options.source]
 * @returns {{needed: boolean, items: object[], document: object|null}}
 */
export function buildIndent(input, options = {}) {
  const today = options.todayKey ?? dayKey(new Date());
  const threshold = options.autoTriggerDays ?? INDENT.AUTO_TRIGGER_DAYS;
  const source = options.source ?? 'AUTO';

  const candidates = (input?.lines ?? []).filter(
    (line) => source === 'MANUAL' || needsIndent({ ...line, daysOfCover: line.daysOfCover }, { autoTriggerDays: threshold }),
  );

  const items = candidates
    .map((line) =>
      indentItem({
        medicineId: line.medicineId,
        medicineName: line.medicineName,
        stock: line.stock,
        perDay: line.perDay,
        daysOfCover: line.daysOfCover,
        units: line.requestedUnits ?? line.suggestedReorderUnits,
      }),
    )
    .filter((item) => item.units > 0);

  if (items.length === 0) return { needed: false, items: [], document: null };

  const priorityOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2 };
  items.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority] || b.units - a.units);

  const worst = items[0]?.daysOfCover ?? null;
  const document = {
    facilityId: input.facilityId,
    facilityName: input.facilityName,
    status: INDENT_STATUS.REQUESTED,
    source,
    priority: items[0]?.priority ?? 'MEDIUM',
    items,
    totalItems: items.length,
    totalUnits: items.reduce((total, item) => total + item.units, 0),
    daysOfCoverAtRequest: worst,
    requestedBy: options.requestedById ?? 'system:auto-indent',
    requestedAt: toDate(`${today}T09:00:00Z`)?.toISOString() ?? new Date().toISOString(),
    history: [
      {
        status: INDENT_STATUS.REQUESTED,
        at: new Date().toISOString(),
        by: options.requestedById ?? 'system:auto-indent',
        note:
          source === 'AUTO'
            ? `Auto-raised: ${items.length} item(s) below ${threshold} days of cover.`
            : 'Raised manually by facility staff.',
      },
    ],
  };

  return { needed: true, items, document };
}

/**
 * Validate a workflow transition for indents/transfers.
 *
 * @param {'indent'|'transfer'} workflow
 * @param {string} from
 * @param {string} to
 * @param {Record<string, string[]>} transitions
 * @returns {{allowed: boolean, allowedNext: string[]}}
 */
export function canTransition(workflow, from, to, transitions) {
  const table = transitions?.[workflow] ?? {};
  const allowedNext = table[from] ?? [];
  return { allowed: allowedNext.includes(to), allowedNext };
}
