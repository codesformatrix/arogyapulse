/**
 * Facility and district risk scoring (pure).
 *
 * The district officer opens one screen and needs to know *where to look
 * first*. This module converts four independent operational signals - stock,
 * beds, queue, attendance - into a single comparable 0-100 score plus the
 * reasons behind it, so the ranking is explainable and contestable.
 *
 * @module services/risk
 */

import { round } from '../utils/random.js';
import { STOCK_STATUS } from '../config/constants.js';

/** Weights used by {@link computeFacilityRisk}; they sum to 100. */
export const RISK_WEIGHTS = Object.freeze({
  stock: 40,
  beds: 20,
  queue: 20,
  attendance: 20,
});

/**
 * Stock component: share of tracked medicines in each risk band.
 *
 * @param {{status: string, daysOfCover: number|null}[]} lines
 * @returns {{score: number, red: number, amber: number, green: number, expiryRisk: number, total: number}}
 */
export function stockRiskScore(lines) {
  const list = Array.isArray(lines) ? lines : [];
  const total = list.length;
  if (total === 0) return { score: 0, red: 0, amber: 0, green: 0, expiryRisk: 0, total: 0 };

  const red = list.filter((line) => line.status === STOCK_STATUS.RED).length;
  const amber = list.filter((line) => line.status === STOCK_STATUS.AMBER).length;
  const expiryRisk = list.filter((line) => line.status === STOCK_STATUS.EXPIRY_RISK).length;
  const green = total - red - amber - expiryRisk;

  const score = ((red * 1 + amber * 0.55 + expiryRisk * 0.3) / total) * 100;
  return { score: round(score, 1), red, amber, green, expiryRisk, total };
}

/**
 * Bed component: how little room is left for an emergency admission.
 *
 * @param {{total: number, occupied: number, reserved: number}[]} wards
 * @returns {{score: number, total: number, occupied: number, reserved: number, available: number, occupancyPercent: number}}
 */
export function bedRiskScore(wards) {
  const list = Array.isArray(wards) ? wards : [];
  const total = list.reduce((sum, ward) => sum + Math.max(0, Number(ward?.total) || 0), 0);
  const occupied = list.reduce((sum, ward) => sum + Math.max(0, Number(ward?.occupied) || 0), 0);
  const reserved = list.reduce((sum, ward) => sum + Math.max(0, Number(ward?.reserved) || 0), 0);
  const available = Math.max(0, total - occupied - reserved);

  if (total === 0) return { score: 0, total: 0, occupied: 0, reserved: 0, available: 0, occupancyPercent: 0 };

  const availableShare = available / total;
  const score = availableShare <= 0 ? 100 : Math.max(0, (1 - availableShare) * 100);
  return {
    score: round(score, 1),
    total,
    occupied,
    reserved,
    available,
    occupancyPercent: round(((occupied + reserved) / total) * 100, 1),
  };
}

/**
 * Queue component: how bad the OPD wait is right now.
 *
 * @param {{estimatedWaitMinutes?: number, load?: string}} wait
 * @returns {{score: number, estimatedWaitMinutes: number, load: string}}
 */
export function queueRiskScore(wait) {
  const minutes = Math.max(0, Number(wait?.estimatedWaitMinutes) || 0);
  // 90 minutes of waiting is treated as the worst case.
  const score = Math.min(100, (minutes / 90) * 100);
  return { score: round(score, 1), estimatedWaitMinutes: minutes, load: wait?.load ?? 'LOW' };
}

/**
 * Attendance component: is the OPD actually staffed today?
 *
 * A doctor on approved leave, or not rostered, is still a doctor the OPD does
 * not have. Counting them as present would report "staffed" on a morning when
 * the clinic is empty - which is exactly the failure this feature exists to
 * surface.
 *
 * @param {{presentCount: number, absentCount: number, entries?: {status: string}[]}} summary
 * @returns {{score: number, anyPresent: boolean, presentCount: number, absentCount: number, alerts: number}}
 */
export function attendanceRiskScore(summary) {
  const entries = Array.isArray(summary?.entries) ? summary.entries : null;

  // Preferred path: derive straight from per-doctor statuses.
  if (entries) {
    const present = entries.filter(
      (entry) => entry.status === 'PRESENT' || entry.status === 'LATE',
    ).length;
    const absent = entries.filter(
      (entry) => entry.status === 'NO_CHECK_IN' || entry.status === 'ON_LEAVE',
    ).length;
    return {
      score: scoreFrom(present, absent),
      anyPresent: present > 0,
      presentCount: present,
      absentCount: absent,
      alerts: Array.isArray(summary?.alerts) ? summary.alerts.length : 0,
    };
  }

  const present = Number(summary?.presentCount) || 0;
  const absent = Number(summary?.absentCount) || 0;
  return {
    score: scoreFrom(present, absent),
    anyPresent: summary?.anyPresent === undefined ? present > 0 : Boolean(summary.anyPresent),
    presentCount: present,
    absentCount: absent,
    alerts: Array.isArray(summary?.alerts) ? summary.alerts.length : 0,
  };
}

/**
 * Share of expected doctors who are not available, as a 0-100 score.
 *
 * @param {number} present
 * @param {number} absent
 * @returns {number}
 */
function scoreFrom(present, absent) {
  const expected = present + absent;
  if (expected === 0) return 0;
  return round((absent / expected) * 100, 1);
}

/**
 * @typedef {Object} FacilityRisk
 * @property {string} facilityId
 * @property {string} facilityName
 * @property {string} facilityType
 * @property {number} riskScore - 0 (healthy) - 100 (critical).
 * @property {string} riskBand - 'CRITICAL' | 'HIGH' | 'MODERATE' | 'OK'
 * @property {{stock: object, beds: object, queue: object, attendance: object}} components
 * @property {string[]} topReasons
 */

/**
 * Combine the four components into one comparable facility score.
 *
 * @param {object} input
 * @param {string} input.facilityId
 * @param {string} input.facilityName
 * @param {string} [input.facilityType]
 * @param {object} input.components - Output of the four component functions.
 * @param {typeof RISK_WEIGHTS} [weights]
 * @returns {FacilityRisk}
 */
export function computeFacilityRisk(input, weights = RISK_WEIGHTS) {
  const components = input.components ?? {};
  const stock = components.stock ?? stockRiskScore([]);
  const beds = components.beds ?? bedRiskScore([]);
  const queue = components.queue ?? queueRiskScore({});
  const attendance = components.attendance ?? attendanceRiskScore({ presentCount: 1, absentCount: 0 });

  const riskScore = round(
    (stock.score * weights.stock +
      beds.score * weights.beds +
      queue.score * weights.queue +
      attendance.score * weights.attendance) /
      100,
    1,
  );

  return {
    facilityId: input.facilityId,
    facilityName: input.facilityName,
    facilityType: input.facilityType ?? 'PHC',
    riskScore,
    riskBand: bandFor(riskScore),
    components: { stock, beds, queue, attendance },
    topReasons: topReasons({ stock, beds, queue, attendance }),
  };
}

/**
 * Band a 0-100 score for display (always paired with text, never colour only).
 *
 * @param {number} score
 * @returns {'CRITICAL'|'HIGH'|'MODERATE'|'OK'}
 */
export function bandFor(score) {
  if (score >= 70) return 'CRITICAL';
  if (score >= 45) return 'HIGH';
  if (score >= 20) return 'MODERATE';
  return 'OK';
}

/**
 * Plain-language reasons, worst first, for the district dashboard and the
 * daily AI briefing (the model is only allowed to rephrase these facts).
 *
 * @param {{stock: object, beds: object, queue: object, attendance: object}} components
 * @returns {string[]}
 */
export function topReasons(components) {
  const reasons = [];
  const { stock, beds, queue, attendance } = components;

  if (stock?.red > 0) {
    reasons.push(`${stock.red} of ${stock.total} medicines are below 3 days of cover`);
  }
  if (stock?.amber > 0) {
    reasons.push(`${stock.amber} medicines are below 7 days of cover`);
  }
  if (stock?.expiryRisk > 0) {
    reasons.push(`${stock.expiryRisk} medicines hold stock that expires within 60 days`);
  }
  if (beds && beds.total > 0 && beds.available === 0) {
    reasons.push(`No free bed (${beds.occupied}/${beds.total} occupied, ${beds.reserved} reserved)`);
  } else if (beds && beds.total > 0 && beds.available / beds.total < 0.2) {
    reasons.push(`Only ${beds.available} of ${beds.total} beds free`);
  }
  if (queue && queue.estimatedWaitMinutes >= 45) {
    reasons.push(`OPD wait is about ${queue.estimatedWaitMinutes} minutes`);
  }
  if (attendance && attendance.absentCount > 0) {
    reasons.push(`${attendance.absentCount} rostered doctor(s) have not checked in`);
  }
  if (reasons.length === 0) reasons.push('No active operational risk detected');
  return reasons;
}

/**
 * Rank facilities worst-first for the district dashboard.
 *
 * @param {FacilityRisk[]} facilities
 * @returns {FacilityRisk[]}
 */
export function rankFacilities(facilities) {
  return [...(facilities ?? [])].sort(
    (a, b) => b.riskScore - a.riskScore || a.facilityName.localeCompare(b.facilityName),
  );
}

/**
 * District-level rollup used by the district dashboard header and the briefing.
 *
 * @param {FacilityRisk[]} facilities
 * @returns {{facilityCount: number, criticalCount: number, highCount: number, averageRiskScore: number, worstFacility: FacilityRisk|null, totalRedMedicines: number, totalFreeBeds: number}}
 */
export function districtSummary(facilities) {
  const list = Array.isArray(facilities) ? facilities : [];
  const ranked = rankFacilities(list);
  const criticalCount = list.filter((facility) => facility.riskBand === 'CRITICAL').length;
  const highCount = list.filter((facility) => facility.riskBand === 'HIGH').length;

  return {
    facilityCount: list.length,
    criticalCount,
    highCount,
    averageRiskScore: list.length
      ? round(list.reduce((total, facility) => total + facility.riskScore, 0) / list.length, 1)
      : 0,
    worstFacility: ranked[0] ?? null,
    totalRedMedicines: list.reduce((total, facility) => total + (facility.components?.stock?.red ?? 0), 0),
    totalFreeBeds: list.reduce((total, facility) => total + (facility.components?.beds?.available ?? 0), 0),
  };
}
