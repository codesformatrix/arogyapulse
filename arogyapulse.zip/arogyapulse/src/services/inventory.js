/**
 * Batch-level inventory operations (pure).
 *
 * FEFO - First Expiry, First Out - is the dispensing rule used across Indian
 * public health stores. Applying it in code (rather than trusting memory) is
 * what keeps near-expiry batches from being written off.
 *
 * @module services/inventory
 */

import { EXPIRY } from '../config/constants.js';
import { addDays, dayKey, daysBetweenKeys, toDate } from '../utils/time.js';

/**
 * @typedef {Object} Batch
 * @property {string} id
 * @property {string} [batchNo]
 * @property {number} quantity
 * @property {string|Date} expiryDate
 * @property {string} [status] - ACTIVE | NEAR_EXPIRY | EXPIRED
 */

/**
 * Total units across batches.
 *
 * @param {{quantity: number}[]} batches
 * @returns {number}
 */
export function totalUnits(batches) {
  if (!Array.isArray(batches)) return 0;
  return batches.reduce((total, batch) => total + Math.max(0, Number(batch?.quantity) || 0), 0);
}

/**
 * Days remaining until a batch expires (negative when already expired).
 *
 * @param {string|Date} expiryDate
 * @param {string} [todayKey]
 * @returns {number|null}
 */
export function daysUntilExpiry(expiryDate, todayKey) {
  const expiry = toDate(expiryDate);
  if (!expiry) return null;
  const today = todayKey ?? dayKey(new Date());
  return daysBetweenKeys(today, dayKey(expiry));
}

/**
 * Derive a batch's lifecycle status from its expiry date.
 *
 * @param {{expiryDate: string|Date, quantity?: number}} batch
 * @param {object} [options]
 * @param {string} [options.todayKey]
 * @param {number} [options.nearExpiryDays]
 * @returns {'EXPIRED'|'NEAR_EXPIRY'|'ACTIVE'}
 */
export function batchStatus(batch, options = {}) {
  const window = options.nearExpiryDays ?? EXPIRY.NEAR_EXPIRY_DAYS;
  const days = daysUntilExpiry(batch?.expiryDate, options.todayKey);
  if (days === null) return 'ACTIVE';
  if (days < 0) return 'EXPIRED';
  if (days <= window) return 'NEAR_EXPIRY';
  return 'ACTIVE';
}

/**
 * Order batches for dispensing: soonest expiry first, then oldest receipt.
 *
 * @param {Batch[]} batches
 * @param {string} [todayKey]
 * @returns {Batch[]} New array, sorted. Expired batches are excluded.
 */
export function fefoOrder(batches, todayKey) {
  if (!Array.isArray(batches)) return [];
  return batches
    .filter((batch) => (Number(batch?.quantity) || 0) > 0)
    .filter((batch) => batchStatus(batch, { todayKey }) !== 'EXPIRED')
    .sort((a, b) => {
      const expiryA = dayKey(toDate(a.expiryDate) ?? new Date('2999-12-31T00:00:00Z'));
      const expiryB = dayKey(toDate(b.expiryDate) ?? new Date('2999-12-31T00:00:00Z'));
      if (expiryA !== expiryB) return expiryA.localeCompare(expiryB);
      const receivedA = toDate(a.receivedAt)?.getTime() ?? 0;
      const receivedB = toDate(b.receivedAt)?.getTime() ?? 0;
      return receivedA - receivedB;
    });
}

/**
 * Allocate a dispensing quantity across batches using FEFO.
 *
 * @param {Batch[]} batches
 * @param {number} quantity - Units to dispense.
 * @param {string} [todayKey]
 * @returns {{allocations: {batchId: string, quantity: number, expiryDate: string}[], fulfilled: number, shortfall: number}}
 */
export function allocateFefo(batches, quantity, todayKey) {
  const needed = Math.max(0, Math.floor(Number(quantity) || 0));
  const allocations = [];
  let remaining = needed;

  for (const batch of fefoOrder(batches, todayKey)) {
    if (remaining <= 0) break;
    const take = Math.min(remaining, Math.floor(Number(batch.quantity) || 0));
    if (take <= 0) continue;
    allocations.push({
      batchId: batch.id,
      quantity: take,
      expiryDate: dayKey(toDate(batch.expiryDate) ?? new Date()),
    });
    remaining -= take;
  }

  return { allocations, fulfilled: needed - remaining, shortfall: remaining };
}

/**
 * Write-offs due to expiry that a facility should action today.
 *
 * @param {Batch[]} batches
 * @param {object} [options]
 * @param {string} [options.todayKey]
 * @param {boolean} [options.includeNearExpiry] - Default true.
 * @returns {{batchId: string, batchNo?: string, quantity: number, expiryDate: string, reason: 'EXPIRED'|'NEAR_EXPIRY'}[]}
 */
export function writeOffCandidates(batches, options = {}) {
  const today = options.todayKey;
  const includeNearExpiry = options.includeNearExpiry ?? true;
  if (!Array.isArray(batches)) return [];

  return batches
    .map((batch) => {
      const status = batchStatus(batch, { todayKey: today });
      const quantity = Math.max(0, Number(batch?.quantity) || 0);
      if (quantity <= 0) return null;
      if (status === 'EXPIRED') {
        return { batchId: batch.id, batchNo: batch.batchNo, quantity, expiryDate: dayKey(batch.expiryDate), reason: 'EXPIRED' };
      }
      if (includeNearExpiry && status === 'NEAR_EXPIRY') {
        return { batchId: batch.id, batchNo: batch.batchNo, quantity, expiryDate: dayKey(batch.expiryDate), reason: 'NEAR_EXPIRY' };
      }
      return null;
    })
    .filter(Boolean)
    .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));
}

/**
 * Build a batch expiry date from a received date and shelf life.
 *
 * @param {string|Date} receivedAt
 * @param {number} [shelfLifeDays]
 * @returns {string} "YYYY-MM-DD"
 */
export function expiryFromShelfLife(receivedAt, shelfLifeDays = EXPIRY.DEFAULT_SHELF_LIFE_DAYS) {
  const received = toDate(receivedAt) ?? new Date();
  return dayKey(addDays(received, shelfLifeDays));
}
