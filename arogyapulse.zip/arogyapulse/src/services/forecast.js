/**
 * Stock forecasting - pure functions, no AI, no I/O.
 *
 * The forecast is a deterministic 7-day weighted moving average of logged
 * dispensing. AI is deliberately NOT used for this arithmetic: a district drug
 * store must be able to audit and reproduce every number, and a hallucinated
 * stock-out is worse than no prediction at all. Gemini only *narrates* the
 * result of these functions.
 *
 * @module services/forecast
 */

import { EXPIRY, FORECAST, INDENT, STOCK_STATUS } from '../config/constants.js';
import { addDays, dayKey, daysBetweenKeys, toDate } from '../utils/time.js';
import { mean, round, sum } from '../utils/random.js';

/**
 * @typedef {Object} BatchLike
 * @property {number} quantity - Current units in this batch.
 * @property {string|Date} expiryDate - Batch expiry.
 * @property {string} [id]
 * @property {string} [batchNo]
 */

/**
 * @typedef {Object} ForecastInput
 * @property {number} stock - Total units on hand.
 * @property {number} [reorderLevel] - Configured reorder point (units).
 * @property {BatchLike[]} [batches] - Live batches for FEFO and expiry risk.
 * @property {{date: string, quantity: number}[]} [consumptionSeries] - Daily
 *   consumption, oldest first.
 * @property {string} [todayKey] - "YYYY-MM-DD" override for deterministic tests.
 */

/**
 * @typedef {Object} ForecastResult
 * @property {number} stock
 * @property {number} dailyAverage - Simple mean over the window.
 * @property {number} forecastPerDay - Weighted moving average.
 * @property {number|null} daysOfCover - Null when there is no consumption.
 * @property {number} daysOfCoverCapped - daysOfCover capped at 999 for UI.
 * @property {string|null} predictedStockoutDate - "YYYY-MM-DD" or null.
 * @property {string} status - RED | AMBER | GREEN | EXPIRY_RISK.
 * @property {number} expiryRiskUnits
 * @property {number} expiryRiskShare
 * @property {number} suggestedReorderUnits
 * @property {boolean} reorderNeeded
 * @property {number} windowDays
 */

/**
 * Weighted moving average of a daily consumption series.
 *
 * Missing days are treated as zero consumption (a closed OPD really does
 * consume nothing), and the newest observations weigh most heavily so the
 * forecast reacts to a monsoon diarrhoea spike within a couple of days.
 *
 * @param {{date: string, quantity: number}[]} series - Daily quantities.
 * @param {object} [options]
 * @param {number[]} [options.weights] - Oldest -> newest; default [1,1,1.5,1.5,2,2,3].
 * @param {number} [options.windowDays] - Default 7.
 * @returns {number} Units per day, rounded to 3 decimals.
 */
export function weightedMovingAverage(series, options = {}) {
  const weights = options.weights ?? FORECAST.WEIGHTS;
  const windowDays = options.windowDays ?? FORECAST.WINDOW_DAYS;
  if (!Array.isArray(series) || series.length === 0) return 0;

  const window = weights.slice(-windowDays);
  const recent = series.slice(-window.length);
  const quantities = recent.map((entry) => (Number.isFinite(entry?.quantity) ? entry.quantity : 0));

  // Align weights to the tail of the series so a 3-day history still uses the
  // three most recent (heaviest) weights.
  const aligned = window.slice(-quantities.length);
  const weightedSum = aligned.reduce((total, weight, index) => total + weight * quantities[index], 0);
  const weightSum = sum(aligned);
  if (weightSum <= 0) return 0;
  return round(weightedSum / weightSum, 3);
}

/**
 * Simple daily average over the supplied series.
 *
 * @param {{quantity: number}[]} series
 * @returns {number}
 */
export function simpleDailyAverage(series) {
  if (!Array.isArray(series) || series.length === 0) return 0;
  return round(
    mean(series.map((entry) => (Number.isFinite(entry?.quantity) ? entry.quantity : 0))),
    3,
  );
}

/**
 * Standard deviation of daily consumption (demand variability).
 *
 * @param {{quantity: number}[]} series
 * @returns {number}
 */
export function consumptionStdDev(series) {
  if (!Array.isArray(series) || series.length < 2) return 0;
  const values = series.map((entry) => (Number.isFinite(entry?.quantity) ? entry.quantity : 0));
  const average = mean(values);
  const variance = mean(values.map((value) => (value - average) ** 2));
  return round(Math.sqrt(variance), 3);
}

/**
 * Days of cover: how long current stock lasts at the forecast consumption rate.
 *
 * @param {number} stock
 * @param {number} perDay
 * @returns {number|null} Null when consumption is zero (stock does not deplete).
 */
export function daysOfCover(stock, perDay) {
  const units = Number(stock) || 0;
  const rate = Number(perDay) || 0;
  if (units <= 0) return 0;
  if (rate <= FORECAST.MIN_FORECAST) return null;
  return round(units / rate, 2);
}

/**
 * Traffic-light status for a stock line.
 *
 * Expiry risk is reported separately from availability so a pharmacist can see
 * "we have plenty, but it expires next month" as its own actionable state.
 *
 * @param {object} input
 * @param {number|null} input.daysOfCover
 * @param {number} [input.stock]
 * @param {number} [input.reorderLevel]
 * @param {number} [input.expiryRiskShare]
 * @param {object} [thresholds]
 * @param {number} [thresholds.redDays]
 * @param {number} [thresholds.amberDays]
 * @param {number} [thresholds.expiryRiskShare]
 * @returns {string} One of STOCK_STATUS values.
 */
export function statusFor(input, thresholds = {}) {
  const redDays = thresholds.redDays ?? FORECAST.RED_DAYS;
  const amberDays = thresholds.amberDays ?? FORECAST.AMBER_DAYS;
  const expiryShareLimit = thresholds.expiryRiskShare ?? EXPIRY.EXPIRY_RISK_SHARE;
  const cover = input?.daysOfCover;
  const stock = Number(input?.stock) || 0;

  if (stock <= 0 || cover === 0) return STOCK_STATUS.RED;
  if (cover !== null && cover !== undefined) {
    if (cover < redDays) return STOCK_STATUS.RED;
    if (cover < amberDays) return STOCK_STATUS.AMBER;
  }
  if ((Number(input?.expiryRiskShare) || 0) >= expiryShareLimit) return STOCK_STATUS.EXPIRY_RISK;
  if (
    Number.isFinite(input?.reorderLevel) &&
    input.reorderLevel > 0 &&
    stock <= input.reorderLevel &&
    cover === null
  ) {
    return STOCK_STATUS.AMBER;
  }
  return STOCK_STATUS.GREEN;
}

/**
 * Predict the calendar date on which stock reaches zero.
 *
 * @param {object} input
 * @param {number} input.stock
 * @param {number} input.perDay - Forecast consumption per day.
 * @param {string} [input.todayKey] - "YYYY-MM-DD"; defaults to today.
 * @returns {string|null} "YYYY-MM-DD" or null when stock will not deplete.
 */
export function predictStockoutDate({ stock, perDay, todayKey }) {
  const cover = daysOfCover(stock, perDay);
  if (cover === null) return null;
  if (cover <= 0) return todayKey ?? dayKey(new Date());
  const reference = todayKey ? toDate(`${todayKey}T00:00:00Z`) : new Date();
  return dayKey(addDays(reference, Math.floor(cover)));
}

/**
 * Units expiring inside a window, plus their share of total stock.
 *
 * @param {BatchLike[]} batches
 * @param {object} [options]
 * @param {string} [options.todayKey]
 * @param {number} [options.windowDays]
 * @returns {{riskUnits: number, totalUnits: number, share: number, soonestExpiry: string|null, expiringBatches: {id?: string, batchNo?: string, quantity: number, expiryDate: string}[]}}
 */
export function expiryRisk(batches, options = {}) {
  const list = Array.isArray(batches) ? batches : [];
  const today = options.todayKey ?? dayKey(new Date());
  const windowDays = options.windowDays ?? EXPIRY.NEAR_EXPIRY_DAYS;

  let riskUnits = 0;
  let totalUnits = 0;
  let soonestExpiry = null;
  const expiringBatches = [];

  for (const batch of list) {
    const quantity = Math.max(0, Number(batch?.quantity) || 0);
    totalUnits += quantity;
    const expiry = toDate(batch?.expiryDate);
    if (!expiry || quantity <= 0) continue;
    const expiryKey = dayKey(expiry);
    if (soonestExpiry === null || expiryKey < soonestExpiry) soonestExpiry = expiryKey;
    const daysLeft = daysBetweenKeys(today, expiryKey);
    if (daysLeft <= windowDays) {
      riskUnits += quantity;
      expiringBatches.push({
        id: batch.id,
        batchNo: batch.batchNo,
        quantity,
        expiryDate: expiryKey,
      });
    }
  }

  return {
    riskUnits,
    totalUnits,
    share: totalUnits > 0 ? round(riskUnits / totalUnits, 3) : 0,
    soonestExpiry,
    expiringBatches: expiringBatches.sort((a, b) => a.expiryDate.localeCompare(b.expiryDate)),
  };
}

/**
 * Suggested reorder quantity.
 *
 * Aim: enough stock to cover the lead time, a safety margin against demand
 * variability, and reach the target days of cover. Never negative, always a
 * whole unit.
 *
 * @param {object} input
 * @param {number} input.stock
 * @param {number} input.perDay
 * @param {number} [input.stdDev]
 * @param {number} [input.reorderLevel]
 * @param {object} [policy]
 * @param {number} [policy.targetDaysOfCover]
 * @param {number} [policy.leadTimeDays]
 * @param {number} [policy.safetyDays]
 * @param {number} [policy.safetyFactor]
 * @returns {number}
 */
export function suggestedReorderUnits(input, policy = {}) {
  const targetDays = policy.targetDaysOfCover ?? INDENT.TARGET_DAYS_OF_COVER;
  const leadTimeDays = policy.leadTimeDays ?? INDENT.LEAD_TIME_DAYS;
  const safetyDays = policy.safetyDays ?? INDENT.SAFETY_DAYS;
  const safetyFactor = policy.safetyFactor ?? 1.5;

  const stock = Math.max(0, Number(input?.stock) || 0);
  const perDay = Math.max(0, Number(input?.perDay) || 0);
  const stdDev = Math.max(0, Number(input?.stdDev) || 0);

  const demandDuringLeadTime = perDay * (leadTimeDays + safetyDays);
  const safetyStock = safetyFactor * stdDev * Math.sqrt(leadTimeDays + safetyDays);
  const targetStock = perDay * targetDays + safetyStock;
  const suggested = Math.max(targetStock, demandDuringLeadTime, Number(input?.reorderLevel) || 0);

  return Math.max(0, Math.ceil(suggested - stock));
}

/**
 * Full forecast for one facility/medicine line.
 *
 * @param {ForecastInput} input
 * @param {object} [policy]
 * @returns {ForecastResult}
 */
export function forecastLine(input, policy = {}) {
  const stock = Math.max(0, Number(input?.stock) || 0);
  const series = Array.isArray(input?.consumptionSeries) ? input.consumptionSeries : [];
  const perDay = weightedMovingAverage(series, policy);
  const stdDev = consumptionStdDev(series);
  const cover = daysOfCover(stock, perDay);
  const expiry = expiryRisk(input?.batches, {
    todayKey: input?.todayKey,
    windowDays: policy.expiryWindowDays,
  });

  const status = statusFor(
    { daysOfCover: cover, stock, reorderLevel: input?.reorderLevel, expiryRiskShare: expiry.share },
    policy.thresholds,
  );

  return {
    stock,
    dailyAverage: simpleDailyAverage(series),
    forecastPerDay: perDay,
    daysOfCover: cover,
    daysOfCoverCapped: cover === null ? 999 : Math.min(999, Math.round(cover)),
    predictedStockoutDate: predictStockoutDate({ stock, perDay, todayKey: input?.todayKey }),
    status,
    expiryRiskUnits: expiry.riskUnits,
    expiryRiskShare: expiry.share,
    soonestExpiry: expiry.soonestExpiry,
    suggestedReorderUnits: suggestedReorderUnits(
      { stock, perDay, stdDev, reorderLevel: input?.reorderLevel },
      policy,
    ),
    reorderNeeded: cover !== null && cover <= (policy.autoIndentDays ?? INDENT.AUTO_TRIGGER_DAYS),
    windowDays: policy.windowDays ?? FORECAST.WINDOW_DAYS,
  };
}

/**
 * Rank a set of forecast lines by urgency (worst first).
 *
 * @param {{status: string, daysOfCover: number|null, expiryRiskShare?: number}[]} lines
 * @returns {typeof lines}
 */
export function rankByRisk(lines) {
  const weight = { RED: 0, AMBER: 1, EXPIRY_RISK: 2, GREEN: 3 };
  return [...lines].sort((a, b) => {
    const statusDelta = (weight[a.status] ?? 9) - (weight[b.status] ?? 9);
    if (statusDelta !== 0) return statusDelta;
    const coverA = a.daysOfCover ?? 9999;
    const coverB = b.daysOfCover ?? 9999;
    if (coverA !== coverB) return coverA - coverB;
    return (b.expiryRiskShare ?? 0) - (a.expiryRiskShare ?? 0);
  });
}
