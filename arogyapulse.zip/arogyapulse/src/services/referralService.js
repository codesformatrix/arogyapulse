/**
 * PHC -> CHC referral service.
 *
 * A referral request always carries the receiving CHC's *live* bed availability
 * at the moment of the request, because "is there a bed?" is the only question
 * the referring PHC actually needs answered.
 *
 * @module services/referralService
 */

import { REFERRAL_STATUS } from '../config/constants.js';
import { BusinessRuleError, ConflictError, NotFoundError } from '../utils/errors.js';
import { newId, uuid } from '../utils/ids.js';
import { invalidateFor } from '../utils/caches.js';
import { bedAvailability, wardView } from './bedService.js';

/** Allowed referral transitions. */
const TRANSITIONS = {
  REQUESTED: ['ACCEPTED', 'REJECTED', 'CLOSED'],
  ACCEPTED: ['TRANSFERRED', 'CLOSED'],
  TRANSFERRED: ['CLOSED'],
  REJECTED: [],
  CLOSED: [],
};

/**
 * Create a referral request from one facility to another.
 *
 * @param {object} repository
 * @param {object} input
 * @param {object} actor
 * @returns {Promise<object>}
 */
export async function createReferral(repository, input, actor) {
  const [from, to] = await Promise.all([
    repository.getFacility(input.fromFacilityId),
    repository.getFacility(input.toFacilityId),
  ]);
  if (!from) throw new NotFoundError(`Facility not found: ${input.fromFacilityId}`);
  if (!to) throw new NotFoundError(`Facility not found: ${input.toFacilityId}`);

  const availability = input.needsBed ? await bedAvailability(repository, input.toFacilityId) : null;
  const bedsAvailable = availability?.summary.available ?? 0;

  if (input.needsBed && bedsAvailable === 0) {
    throw new BusinessRuleError(
      `${to.name} has no free bed right now. Request anyway or choose another facility.`,
      { bedsAvailable },
    );
  }

  const at = new Date().toISOString();
  const referral = {
    id: newId('REF'),
    fromFacilityId: input.fromFacilityId,
    fromFacilityName: from.name,
    toFacilityId: input.toFacilityId,
    toFacilityName: to.name,
    patientToken: input.patientToken,
    category: input.category,
    urgency: input.urgency,
    needsBed: input.needsBed,
    status: REFERRAL_STATUS.REQUESTED,
    wardId: null,
    bedsAvailableAtRequest: bedsAvailable,
    note: input.note ?? null,
    createdBy: actor.subject,
    createdAt: at,
    history: [{ status: REFERRAL_STATUS.REQUESTED, at, by: actor.subject, note: input.note ?? null }],
  };

  await repository.addReferral(referral);
  await repository.addAudit({
    id: uuid(),
    entityType: 'REFERRAL',
    entityId: referral.id,
    facilityId: input.fromFacilityId,
    action: 'CREATE',
    actor: actor.subject,
    role: actor.role,
    after: { toFacilityId: input.toFacilityId, category: input.category, urgency: input.urgency },
    createdAt: at,
  });

  invalidateFor(input.fromFacilityId);
  return referral;
}

/**
 * Accept, reject, transfer or close a referral.
 *
 * ACCEPTED with a ward reserves one bed; TRANSFERRED occupies it.
 *
 * @param {object} repository
 * @param {string} referralId
 * @param {object} input
 * @param {string} input.status
 * @param {string} [input.wardId]
 * @param {string} [input.note]
 * @param {object} actor
 * @returns {Promise<object>}
 */
export async function decideReferral(repository, referralId, input, actor) {
  const referral = await repository.getReferral(referralId);
  if (!referral) throw new NotFoundError(`Referral not found: ${referralId}`);

  const allowedNext = TRANSITIONS[referral.status] ?? [];
  if (!allowedNext.includes(input.status)) {
    throw new ConflictError(`Cannot move a referral from ${referral.status} to ${input.status}`, {
      allowedNext,
    });
  }

  const at = new Date().toISOString();
  let ward = null;

  if (referral.needsBed && (input.status === 'ACCEPTED' || input.status === 'TRANSFERRED')) {
    const wards = await repository.listWards(referral.toFacilityId);
    ward = input.wardId
      ? wards.find((candidate) => candidate.id === input.wardId)
      : wards.find((candidate) => candidate.total - candidate.occupied - candidate.reserved > 0);

    if (!ward) throw new BusinessRuleError('No ward has a free bed for this referral');

    const view = wardView(ward);
    if (input.status === 'ACCEPTED' && view.available > 0) {
      await repository.upsertWard({ ...ward, reserved: ward.reserved + 1 });
    }
    if (input.status === 'TRANSFERRED') {
      const reservedDelta = view.reserved > 0 ? -1 : 0;
      await repository.upsertWard({
        ...ward,
        occupied: ward.occupied + 1,
        reserved: Math.max(0, ward.reserved + reservedDelta),
      });
    }
  }

  const updated = await repository.updateReferral(referralId, {
    status: input.status,
    wardId: ward?.id ?? referral.wardId ?? null,
    history: [
      ...(referral.history ?? []),
      { status: input.status, at, by: actor.subject, note: input.note ?? null, wardId: ward?.id ?? null },
    ],
    updatedAt: at,
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'REFERRAL',
    entityId: referralId,
    facilityId: referral.toFacilityId,
    action: input.status,
    actor: actor.subject,
    role: actor.role,
    before: { status: referral.status },
    after: { status: input.status, wardId: ward?.id ?? null },
    reason: input.note ?? null,
    createdAt: at,
  });

  invalidateFor(referral.toFacilityId);
  invalidateFor(referral.fromFacilityId);
  return updated;
}

/**
 * Live bed availability at candidate CHCs, for the referral screen.
 *
 * @param {object} repository
 * @param {string} [excludeFacilityId]
 * @returns {Promise<object[]>}
 */
export async function receivingFacilities(repository, excludeFacilityId) {
  const page = await repository.listFacilities({ limit: 100, offset: 0 });
  const candidates = page.items.filter(
    (facility) => facility.type === 'CHC' && facility.id !== excludeFacilityId,
  );

  const results = [];
  for (const facility of candidates) {
    const availability = await bedAvailability(repository, facility.id);
    results.push({
      facilityId: facility.id,
      name: facility.name,
      address: facility.address,
      mapsUrl: facility.mapsUrl,
      ...availability.summary,
      wards: availability.wards.map((ward) => ({
        id: ward.id,
        name: ward.name,
        available: ward.available,
        total: ward.total,
      })),
    });
  }

  return results.sort((a, b) => b.available - a.available);
}
