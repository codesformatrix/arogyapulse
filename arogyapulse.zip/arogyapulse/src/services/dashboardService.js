/**
 * Dashboard aggregation.
 *
 * Combines the four operational signals into one facility view and one district
 * ranking. Results are cached for a few seconds because a district officer's
 * screen refreshes far more often than the underlying data changes.
 *
 * @module services/dashboardService
 */

import { ATTENDANCE, CACHE_TTL_MS } from '../config/constants.js';
import { addDays, dayKey, minutesSinceMidnight } from '../utils/time.js';
import { cacheKey } from '../utils/cache.js';
import { dashboardCache } from '../utils/caches.js';
import { attendanceRisk, reliabilityPercent, summarizeAttendance } from './attendance.js';
import { bedAvailability } from './bedService.js';
import { queueState } from './queueService.js';
import { inventoryView } from './stockService.js';
import {
  attendanceRiskScore,
  bedRiskScore,
  computeFacilityRisk,
  districtSummary,
  queueRiskScore,
  stockRiskScore,
} from './risk.js';

/**
 * Single-facility operational snapshot.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {object} [options]
 * @param {Date} [options.now]
 * @param {boolean} [options.skipCache]
 * @returns {Promise<object>}
 */
export async function facilityDashboard(repository, facilityId, options = {}) {
  const now = options.now ?? new Date();
  const key = cacheKey(`facility:${facilityId}:dashboard`, dayKey(now), Math.floor(now.getTime() / 15_000));
  if (!options.skipCache) {
    const cached = dashboardCache.get(key);
    if (cached) return cached;
  }

  const facility = await repository.getFacility(facilityId);
  const [inventory, beds, queue, attendance] = await Promise.all([
    inventoryView(repository, facilityId),
    bedAvailability(repository, facilityId),
    queueState(repository, facilityId, { now }),
    doctorAttendance(repository, facilityId, { now }),
  ]);

  const risk = computeFacilityRisk({
    facilityId,
    facilityName: facility?.name ?? facilityId,
    facilityType: facility?.type ?? 'PHC',
    components: {
      stock: stockRiskScore(inventory),
      beds: bedRiskScore(
        beds.wards.map((ward) => ({ total: ward.total, occupied: ward.occupied, reserved: ward.reserved })),
      ),
      queue: queueRiskScore(queue),
      // Pass the per-doctor entries so leave and non-rostered days count as
      // "not available", which is what the OPD actually experiences.
      attendance: attendanceRiskScore({ ...attendance.summary, entries: attendance.entries }),
    },
  });

  const dashboard = {
    facility: {
      id: facility?.id ?? facilityId,
      name: facility?.name ?? facilityId,
      nameHi: facility?.nameHi ?? null,
      type: facility?.type ?? 'PHC',
      block: facility?.block ?? null,
      address: facility?.address ?? null,
      mapsUrl: facility?.mapsUrl ?? null,
    },
    risk,
    stock: {
      total: inventory.length,
      red: inventory.filter((line) => line.status === 'RED').length,
      amber: inventory.filter((line) => line.status === 'AMBER').length,
      expiryRisk: inventory.filter((line) => line.status === 'EXPIRY_RISK').length,
      green: inventory.filter((line) => line.status === 'GREEN').length,
      worst: inventory.slice(0, 5),
      lines: inventory,
    },
    beds,
    queue,
    attendance,
    generatedAt: now.toISOString(),
  };

  dashboardCache.set(key, dashboard, CACHE_TTL_MS.DASHBOARD);
  return dashboard;
}

/**
 * Doctor attendance rows for a facility today (shared by dashboard + AI).
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {object} [options]
 * @param {Date} [options.now]
 * @returns {Promise<object>}
 */
export async function doctorAttendance(repository, facilityId, options = {}) {
  const now = options.now ?? new Date();
  const todayKey = dayKey(now);
  const alertTime = (await repository.getFacility(facilityId))?.attendanceAlertTime ?? ATTENDANCE.DEFAULT_ALERT_TIME;

  const [doctorsPage, logs, rosters, leaves] = await Promise.all([
    repository.listDoctors({ facilityId }, { limit: 200, offset: 0 }),
    repository.listAttendanceByFacility({ facilityId, date: todayKey }),
    repository.listRosters({ facilityId, date: todayKey }),
    repository.listLeaves({ facilityId, date: todayKey }),
  ]);

  const logByDoctor = new Map(logs.map((entry) => [entry.doctorId, entry]));
  const rosterByDoctor = new Map(rosters.map((entry) => [entry.doctorId, entry]));
  const leaveByDoctor = new Map(leaves.map((entry) => [entry.doctorId, entry]));
  const nowMinutes = minutesSinceMidnight(now);

  const entries = [];
  for (const doctor of doctorsPage.items) {
    const history = await repository.listAttendance(
      doctor.id,
      dayKey(addDays(now, -(ATTENDANCE.WINDOW_DAYS - 1))),
    );
    const reliability = reliabilityPercent(history, { windowDays: ATTENDANCE.WINDOW_DAYS });
    const log = logByDoctor.get(doctor.id);
    const roster = rosterByDoctor.get(doctor.id);
    const leave = leaveByDoctor.get(doctor.id);

    entries.push({
      doctorId: doctor.id,
      name: doctor.name,
      department: doctor.department,
      checkInAt: log?.checkInAt ?? null,
      onLeave: Boolean(leave) || Boolean(log?.onLeave),
      reliabilityPercent: reliability.reliabilityPercent,
      ...attendanceRisk({
        doctorId: doctor.id,
        onRosterToday: roster ? roster.shift !== 'OFF' : true,
        checkInAt: log?.checkInAt ?? null,
        onLeave: Boolean(leave) || Boolean(log?.onLeave),
        nowMinutes,
        alertTime: doctor.alertTime ?? alertTime,
      }),
    });
  }

  return {
    facilityId,
    date: todayKey,
    alertTime,
    entries,
    summary: summarizeAttendance(entries),
  };
}

/**
 * District-wide ranking plus rollup.
 *
 * @param {object} repository
 * @param {object} [options]
 * @param {Date} [options.now]
 * @param {boolean} [options.skipCache]
 * @returns {Promise<object>}
 */
export async function districtDashboard(repository, options = {}) {
  const now = options.now ?? new Date();
  const key = cacheKey('district:dashboard', dayKey(now), Math.floor(now.getTime() / 30_000));
  if (!options.skipCache) {
    const cached = dashboardCache.get(key);
    if (cached) return cached;
  }

  const facilitiesPage = await repository.listFacilities({ limit: 100, offset: 0 });
  const serviceFacilities = facilitiesPage.items.filter(
    (facility) => facility.type !== 'DISTRICT_STORE',
  );

  const facilities = await Promise.all(
    serviceFacilities.map(async (facility) => {
      const dashboard = await facilityDashboard(repository, facility.id, { now, skipCache: true });
      return {
        facilityId: facility.id,
        name: facility.name,
        type: facility.type,
        block: facility.block,
        mapsUrl: facility.mapsUrl,
        riskScore: dashboard.risk.riskScore,
        riskBand: dashboard.risk.riskBand,
        topReasons: dashboard.risk.topReasons,
        redMedicines: dashboard.stock.red,
        amberMedicines: dashboard.stock.amber,
        freeBeds: dashboard.beds.summary.available,
        totalBeds: dashboard.beds.summary.total,
        opdWaitMinutes: dashboard.queue.estimatedWaitMinutes,
        doctorsPresent: dashboard.attendance.summary.presentCount,
        doctorsAbsent: dashboard.attendance.summary.absentCount,
      };
    }),
  );

  facilities.sort((a, b) => b.riskScore - a.riskScore || a.name.localeCompare(b.name));

  const pendingIndents = await repository.listIndents({ status: 'REQUESTED' }, { limit: 100, offset: 0 });
  const openTransfers = await repository.listTransfers({}, { limit: 100, offset: 0 });

  const dashboard = {
    summary: districtSummary(
      facilities.map((facility) => ({
        ...facility,
        components: {
          stock: { red: facility.redMedicines },
          beds: { available: facility.freeBeds },
        },
      })),
    ),
    facilities,
    pendingIndents: pendingIndents.items,
    openTransfers: openTransfers.items.filter(
      (transfer) => transfer.status !== 'RECEIVED' && transfer.status !== 'CANCELLED',
    ),
    generatedAt: now.toISOString(),
  };

  dashboardCache.set(key, dashboard, CACHE_TTL_MS.DISTRICT);
  return dashboard;
}
