/**
 * District supply-chain service: indents, transfers and the district risk view.
 *
 * Both workflows run through the same explicit state machine so an indent can
 * never jump from REQUESTED to RECEIVED, and every transition is audited.
 *
 * @module services/supplyChainService
 */

import {
  INDENT_STATUS,
  TRANSFER,
  TRANSFER_STATUS,
  WORKFLOW_TRANSITIONS,
} from '../config/constants.js';
import { BusinessRuleError, ConflictError, NotFoundError } from '../utils/errors.js';
import { newId, uuid } from '../utils/ids.js';
import { invalidateFor } from '../utils/caches.js';
import { createLogger } from '../utils/logger.js';
import { haversineKm } from './geo.js';
import { canTransition, indentItem } from './indent.js';
import { inventoryView } from './stockService.js';
import { suggestExpiryRedistribution, suggestTransfers } from './transfers.js';

const log = createLogger('supply-chain.service');

/**
 * District ranking of every facility by risk, worst first.
 *
 * @param {object} repository
 * @param {(repository: object, facilityId: string) => Promise<object>} facilityRiskFn
 *   Injected so this service stays free of dashboard internals.
 * @returns {Promise<object>}
 */
export async function districtRisk(repository, facilityRiskFn) {
  const facilitiesPage = await repository.listFacilities({ limit: 100, offset: 0 });
  const facilities = facilitiesPage.items.filter((facility) => facility.type !== 'DISTRICT_STORE');

  const risks = await Promise.all(facilities.map((facility) => facilityRiskFn(repository, facility.id)));
  return risks.sort((a, b) => b.riskScore - a.riskScore);
}

/**
 * Build transfer suggestions across the whole district.
 *
 * @param {object} repository
 * @param {object} [options]
 * @param {number} [options.limit]
 * @returns {Promise<{surplusToDeficit: object[], expiryRisk: object[], facilities: Map<string, object>}>}
 */
export async function transferSuggestions(repository, options = {}) {
  const facilitiesPage = await repository.listFacilities({ limit: 100, offset: 0 });
  const serviceFacilities = facilitiesPage.items.filter(
    (facility) => facility.type !== 'DISTRICT_STORE',
  );

  const facilities = new Map(serviceFacilities.map((facility) => [facility.id, facility]));
  const lines = [];

  for (const facility of serviceFacilities) {
    const inventory = await inventoryView(repository, facility.id);
    const batches = await repository.listBatches({ facilityId: facility.id });
    const batchesByMedicine = new Map();
    for (const batch of batches) {
      const bucket = batchesByMedicine.get(batch.medicineId);
      if (bucket) bucket.push(batch);
      else batchesByMedicine.set(batch.medicineId, [batch]);
    }

    for (const line of inventory) {
      lines.push({
        facilityId: facility.id,
        medicineId: line.medicineId,
        stock: line.stock,
        perDay: line.forecastPerDay,
        daysOfCover: line.daysOfCover,
        coordinates: { latitude: facility.latitude, longitude: facility.longitude },
        batches: batchesByMedicine.get(line.medicineId) ?? [],
      });
    }
  }

  const decorate = (suggestion) => ({
    ...suggestion,
    fromFacilityName: facilities.get(suggestion.fromFacilityId)?.name ?? suggestion.fromFacilityId,
    toFacilityName: facilities.get(suggestion.toFacilityId)?.name ?? suggestion.toFacilityId,
  });

  return {
    surplusToDeficit: suggestTransfers(lines, { limit: options.limit ?? 15 }).map(decorate),
    expiryRisk: suggestExpiryRedistribution(lines, { limit: options.limit ?? 10 }).map(decorate),
    facilities,
  };
}

/**
 * Create an indent (manual, from a staff screen).
 *
 * @param {object} repository
 * @param {object} input
 * @param {object} actor
 * @returns {Promise<object>}
 */
export async function createIndent(repository, input, actor) {
  const facility = await repository.getFacility(input.facilityId);
  if (!facility) throw new NotFoundError(`Facility not found: ${input.facilityId}`);

  const items = [];
  for (const entry of input.items) {
    const medicine = await repository.getMedicine(entry.medicineId);
    if (!medicine) throw new NotFoundError(`Medicine not found: ${entry.medicineId}`);
    const stock = await repository.getStock(input.facilityId, entry.medicineId);
    const inventory = await inventoryView(repository, input.facilityId);
    const line = inventory.find((candidate) => candidate.medicineId === entry.medicineId);
    items.push(
      indentItem({
        medicineId: entry.medicineId,
        medicineName: medicine.name,
        stock: stock?.units ?? 0,
        perDay: line?.forecastPerDay ?? 0,
        daysOfCover: line?.daysOfCover ?? null,
        units: entry.units,
      }),
    );
  }

  const indent = {
    id: newId('IND'),
    facilityId: input.facilityId,
    facilityName: facility.name,
    status: INDENT_STATUS.REQUESTED,
    source: 'MANUAL',
    priority: items[0]?.priority ?? 'MEDIUM',
    items,
    totalItems: items.length,
    totalUnits: items.reduce((total, item) => total + item.units, 0),
    note: input.note ?? null,
    requestedBy: actor.subject,
    requestedAt: new Date().toISOString(),
    history: [
      {
        status: INDENT_STATUS.REQUESTED,
        at: new Date().toISOString(),
        by: actor.subject,
        note: input.note ?? 'Raised from facility screen.',
      },
    ],
  };

  await repository.addIndent(indent);
  await repository.addAudit({
    id: uuid(),
    entityType: 'INDENT',
    entityId: indent.id,
    facilityId: input.facilityId,
    action: 'CREATE',
    actor: actor.subject,
    role: actor.role,
    after: { totalItems: indent.totalItems, totalUnits: indent.totalUnits },
    createdAt: indent.requestedAt,
  });

  invalidateFor(input.facilityId);
  return indent;
}

/**
 * Move an indent through its workflow, applying stock on RECEIVED.
 *
 * @param {object} repository
 * @param {string} indentId
 * @param {string} status
 * @param {object} actor
 * @param {string} [note]
 * @returns {Promise<object>}
 */
export async function transitionIndent(repository, indentId, status, actor, note) {
  const indent = await repository.getIndent(indentId);
  if (!indent) throw new NotFoundError(`Indent not found: ${indentId}`);

  const { allowed, allowedNext } = canTransition('indent', indent.status, status, WORKFLOW_TRANSITIONS);
  if (!allowed) {
    throw new ConflictError(`Cannot move an indent from ${indent.status} to ${status}`, {
      allowedNext,
    });
  }

  const at = new Date().toISOString();
  const updated = await repository.updateIndent(indentId, {
    status,
    history: [
      ...(indent.history ?? []),
      { status, at, by: actor.subject, note: note ?? null },
    ],
    updatedAt: at,
  });

  // Goods received: credit every line into a tracked batch.
  if (status === INDENT_STATUS.RECEIVED) {
    for (const item of indent.items ?? []) {
      const stock = await repository.getStock(indent.facilityId, item.medicineId);
      const expiryDate = new Date(Date.now() + 540 * 86_400_000).toISOString().slice(0, 10);
      await repository.upsertBatch({
        id: newId('BAT'),
        facilityId: indent.facilityId,
        medicineId: item.medicineId,
        batchNo: `IND-${indent.id.slice(-6)}-${item.medicineId.slice(-4)}`,
        quantity: item.units,
        expiryDate,
        receivedAt: at,
        status: 'ACTIVE',
      });
      if (stock) {
        await repository.upsertStock({ ...stock, units: (stock.units ?? 0) + item.units });
      }
    }
  }

  await repository.addAudit({
    id: uuid(),
    entityType: 'INDENT',
    entityId: indentId,
    facilityId: indent.facilityId,
    action: status,
    actor: actor.subject,
    role: actor.role,
    before: { status: indent.status },
    after: { status },
    reason: note ?? null,
    createdAt: at,
  });

  invalidateFor(indent.facilityId);
  return updated;
}

/**
 * Create a transfer between two facilities.
 *
 * @param {object} repository
 * @param {object} input
 * @param {object} actor
 * @returns {Promise<object>}
 */
export async function createTransfer(repository, input, actor) {
  const [from, to, batch] = await Promise.all([
    repository.getFacility(input.fromFacilityId),
    repository.getFacility(input.toFacilityId),
    repository.getBatch(input.batchId),
  ]);

  if (!from) throw new NotFoundError(`Facility not found: ${input.fromFacilityId}`);
  if (!to) throw new NotFoundError(`Facility not found: ${input.toFacilityId}`);
  if (!batch) throw new NotFoundError(`Batch not found: ${input.batchId}`);
  if (batch.facilityId !== input.fromFacilityId) {
    throw new BusinessRuleError('That batch does not belong to the sending facility');
  }
  if (batch.quantity < input.units) {
    throw new BusinessRuleError(`Batch holds only ${batch.quantity} units`, {
      available: batch.quantity,
    });
  }

  const transfer = {
    id: newId('TRF'),
    fromFacilityId: input.fromFacilityId,
    fromFacilityName: from.name,
    toFacilityId: input.toFacilityId,
    toFacilityName: to.name,
    medicineId: input.medicineId,
    batchId: input.batchId,
    batchNo: batch.batchNo ?? null,
    units: input.units,
    reason: input.reason,
    status: TRANSFER_STATUS.REQUESTED,
    distanceKm: haversineKm(
      { latitude: from.latitude, longitude: from.longitude },
      { latitude: to.latitude, longitude: to.longitude },
    ),
    note: input.note ?? null,
    requestedBy: actor.subject,
    requestedAt: new Date().toISOString(),
    history: [
      {
        status: TRANSFER_STATUS.REQUESTED,
        at: new Date().toISOString(),
        by: actor.subject,
        note: input.note ?? null,
      },
    ],
  };

  await repository.addTransfer(transfer);
  await repository.addAudit({
    id: uuid(),
    entityType: 'TRANSFER',
    entityId: transfer.id,
    facilityId: input.fromFacilityId,
    action: 'CREATE',
    actor: actor.subject,
    role: actor.role,
    after: { toFacilityId: input.toFacilityId, units: input.units },
    createdAt: transfer.requestedAt,
  });

  invalidateFor(input.fromFacilityId);
  return transfer;
}

/**
 * Move a transfer through its workflow, moving stock at DISPATCHED/RECEIVED.
 *
 * @param {object} repository
 * @param {string} transferId
 * @param {string} status
 * @param {object} actor
 * @param {string} [note]
 * @returns {Promise<object>}
 */
export async function transitionTransfer(repository, transferId, status, actor, note) {
  const transfer = await repository.getTransfer(transferId);
  if (!transfer) throw new NotFoundError(`Transfer not found: ${transferId}`);

  const { allowed, allowedNext } = canTransition(
    'transfer',
    transfer.status,
    status,
    WORKFLOW_TRANSITIONS,
  );
  if (!allowed) {
    throw new ConflictError(`Cannot move a transfer from ${transfer.status} to ${status}`, {
      allowedNext,
    });
  }

  const at = new Date().toISOString();

  if (status === TRANSFER_STATUS.DISPATCHED) {
    await repository.decrementBatch(transfer.batchId, transfer.units);
    const stock = await repository.getStock(transfer.fromFacilityId, transfer.medicineId);
    if (stock) {
      await repository.upsertStock({
        ...stock,
        units: Math.max(0, (stock.units ?? 0) - transfer.units),
      });
    }
  }

  if (status === TRANSFER_STATUS.RECEIVED) {
    const batch = await repository.getBatch(transfer.batchId);
    await repository.upsertBatch({
      id: newId('BAT'),
      facilityId: transfer.toFacilityId,
      medicineId: transfer.medicineId,
      batchNo: transfer.batchNo ?? `TRF-${transfer.id.slice(-6)}`,
      quantity: transfer.units,
      expiryDate: batch?.expiryDate ?? new Date(Date.now() + 365 * 86_400_000).toISOString().slice(0, 10),
      receivedAt: at,
      status: 'ACTIVE',
      sourceTransferId: transfer.id,
    });
    const stock = await repository.getStock(transfer.toFacilityId, transfer.medicineId);
    if (stock) {
      await repository.upsertStock({ ...stock, units: (stock.units ?? 0) + transfer.units });
    }
  }

  const updated = await repository.updateTransfer(transferId, {
    status,
    history: [...(transfer.history ?? []), { status, at, by: actor.subject, note: note ?? null }],
    updatedAt: at,
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'TRANSFER',
    entityId: transferId,
    facilityId: transfer.fromFacilityId,
    action: status,
    actor: actor.subject,
    role: actor.role,
    before: { status: transfer.status },
    after: { status },
    reason: note ?? null,
    createdAt: at,
  });

  invalidateFor(transfer.fromFacilityId);
  invalidateFor(transfer.toFacilityId);
  log.info('Transfer transition', { transferId, from: transfer.status, to: status });
  return updated;
}

export { TRANSFER };
