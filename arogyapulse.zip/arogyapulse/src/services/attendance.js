/**
 * Doctor attendance analytics (pure).
 *
 * "Unpredictable doctor attendance" is one of the four gaps in the problem
 * statement. These functions turn raw check-ins into a 30-day reliability
 * percentage, a same-day "will the doctor come?" risk and the 09:30 no-show
 * alert that the district officer actually acts on.
 *
 * @module services/attendance
 */

import { ATTENDANCE } from '../config/constants.js';
import { hhmmToMinutes, minutesSinceMidnight } from '../utils/time.js';
import { round } from '../utils/random.js';

/**
 * @typedef {Object} AttendanceLog
 * @property {string} doctorId
 * @property {string} date - "YYYY-MM-DD"
 * @property {string|null} checkInAt - ISO instant or null.
 * @property {string|null} [checkOutAt]
 * @property {boolean} [onLeave]
 * @property {string} [leaveType]
 */

/**
 * @typedef {Object} ReliabilityResult
 * @property {number} reliabilityPercent - 0-100.
 * @property {number} dutyDays - Days on roster inside the window.
 * @property {number} presentDays
 * @property {number} absentDays
 * @property {number} lateDays
 * @property {number} leaveDays
 * @property {number} onTimePercent
 * @property {string} rating - 'RELIABLE' | 'WATCH' | 'AT_RISK'
 */

/**
 * 30-day attendance reliability percentage.
 *
 * Approved leave is excluded from the denominator: penalising a sanctioned
 * leave would make staff hide leave requests, which is exactly the behaviour
 * that creates an empty OPD with nobody able to explain why.
 *
 * @param {AttendanceLog[]} logs
 * @param {object} [options]
 * @param {number} [options.windowDays]
 * @param {number} [options.lateGraceMinutes]
 * @param {string} [options.shiftStartMinutes] - Not used for reliability, kept for symmetry.
 * @returns {ReliabilityResult}
 */
export function reliabilityPercent(logs, options = {}) {
  const lateGrace = options.lateGraceMinutes ?? ATTENDANCE.LATE_GRACE_MINUTES;
  const list = (Array.isArray(logs) ? logs : []).slice(-Math.max(1, options.windowDays ?? ATTENDANCE.WINDOW_DAYS));

  let dutyDays = 0;
  let presentDays = 0;
  let absentDays = 0;
  let lateDays = 0;
  let leaveDays = 0;

  for (const log of list) {
    if (log?.onLeave) {
      leaveDays += 1;
      continue;
    }
    dutyDays += 1;
    if (log?.checkInAt) {
      presentDays += 1;
      if (isLate(log, { lateGraceMinutes: lateGrace })) lateDays += 1;
    } else {
      absentDays += 1;
    }
  }

  const reliability = dutyDays > 0 ? round((presentDays / dutyDays) * 100, 1) : 100;
  const onTimePercent = presentDays > 0 ? round(((presentDays - lateDays) / presentDays) * 100, 1) : 100;

  return {
    reliabilityPercent: reliability,
    dutyDays,
    presentDays,
    absentDays,
    lateDays,
    leaveDays,
    onTimePercent,
    rating: ratingFor(reliabilityPercent),
  };
}

/**
 * Human-facing reliability band.
 *
 * @param {number} percent
 * @param {number} [lowThreshold]
 * @returns {'RELIABLE'|'WATCH'|'AT_RISK'}
 */
export function ratingFor(percent, lowThreshold = ATTENDANCE.LOW_RELIABILITY_PERCENT) {
  if (percent >= 95) return 'RELIABLE';
  if (percent >= lowThreshold) return 'WATCH';
  return 'AT_RISK';
}

/**
 * Was this check-in late relative to the configured alert time?
 *
 * @param {AttendanceLog} log
 * @param {object} [options]
 * @param {string} [options.alertTime] - "HH:mm"; defaults to 09:30.
 * @param {number} [options.lateGraceMinutes]
 * @param {(hhmm: string) => number} [options.hhmmToMinutes]
 * @param {(instant: string|Date) => number} [options.minutesSinceMidnight]
 * @returns {boolean}
 */
export function isLate(log, options = {}) {
  if (!log?.checkInAt) return false;
  const toMinutesFromClock = options.hhmmToMinutes ?? hhmmToMinutes;
  const toMinutesFromInstant = options.minutesSinceMidnight ?? minutesSinceMidnight;

  const alertMinutes = toMinutesFromClock(options.alertTime ?? ATTENDANCE.DEFAULT_ALERT_TIME);
  const grace = options.lateGraceMinutes ?? ATTENDANCE.LATE_GRACE_MINUTES;
  return toMinutesFromInstant(log.checkInAt) > alertMinutes + grace;
}

/**
 * @typedef {Object} AttendanceRisk
 * @property {string} doctorId
 * @property {string} status - 'PRESENT' | 'LATE' | 'ON_LEAVE' | 'NO_CHECK_IN' | 'NOT_ROSTERED'
 * @property {boolean} alert
 * @property {string} reason
 * @property {number} [minutesLate]
 */

/**
 * Same-day attendance risk for one doctor.
 *
 * The alert only fires once the configured alert time has actually passed, so
 * a screen opened at 07:00 does not scream "doctor absent".
 *
 * @param {object} input
 * @param {boolean} input.onRosterToday
 * @param {string|null} [input.checkInAt]
 * @param {boolean} [input.onLeave]
 * @param {string} [input.nowKey] - "YYYY-MM-DD"
 * @param {number} [input.nowMinutes] - Minutes since local midnight.
 * @param {string} [input.alertTime] - "HH:mm".
 * @param {ReliabilityResult} [input.reliability]
 * @returns {AttendanceRisk}
 */
export function attendanceRisk(input) {
  const alertTime = input.alertTime ?? ATTENDANCE.DEFAULT_ALERT_TIME;
  const alertMinutes = hhmmToMinutes(alertTime);
  const nowMinutes = Number.isFinite(input?.nowMinutes) ? input.nowMinutes : 0;
  const pastAlertTime = nowMinutes >= alertMinutes;

  if (input?.onLeave) {
    return {
      doctorId: input.doctorId,
      status: 'ON_LEAVE',
      alert: false,
      reason: 'Approved leave recorded for today.',
    };
  }

  if (!input?.onRosterToday) {
    return {
      doctorId: input.doctorId,
      status: 'NOT_ROSTERED',
      alert: false,
      reason: 'Not on duty today.',
    };
  }

  if (input?.checkInAt) {
    const checkInMinutes = minutesSinceMidnight(input.checkInAt);
    const late = checkInMinutes > alertMinutes + ATTENDANCE.LATE_GRACE_MINUTES;
    return {
      doctorId: input.doctorId,
      status: late ? 'LATE' : 'PRESENT',
      alert: false,
      minutesLate: Math.max(0, checkInMinutes - alertMinutes),
      reason: late
        ? `Checked in ${checkInMinutes - alertMinutes} minutes after ${alertTime}.`
        : 'Checked in on time.',
    };
  }

  return {
    doctorId: input.doctorId,
    status: 'NO_CHECK_IN',
    alert: pastAlertTime,
    reason: pastAlertTime
      ? `No check-in by ${alertTime}.`
      : 'Not checked in yet; alert starts at the configured time.',
  };
}

/**
 * District-level summary: is at least one doctor available right now?
 *
 * @param {AttendanceRisk[]} risks
 * @returns {{anyPresent: boolean, presentCount: number, absentCount: number, alerts: AttendanceRisk[]}}
 */
export function summarizeAttendance(risks) {
  const list = Array.isArray(risks) ? risks : [];
  const present = list.filter((risk) => risk.status === 'PRESENT' || risk.status === 'LATE');
  return {
    anyPresent: present.length > 0,
    presentCount: present.length,
    absentCount: list.filter((risk) => risk.status === 'NO_CHECK_IN').length,
    alerts: list.filter((risk) => risk.alert),
  };
}
