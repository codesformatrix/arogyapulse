/**
 * Attendance service: check-in/out, roster, leave, reliability and the
 * "has nobody checked in by 09:30?" alert.
 *
 * @module services/attendanceService
 */

import { ATTENDANCE } from '../config/constants.js';
import { NotFoundError } from '../utils/errors.js';
import { newId, uuid } from '../utils/ids.js';
import { addDays, dayKey, minutesSinceMidnight } from '../utils/time.js';
import { invalidateFor } from '../utils/caches.js';
import { attendanceRisk, isLate, reliabilityPercent, summarizeAttendance } from './attendance.js';

/**
 * Per-doctor attendance board for one facility today.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {object} [options]
 * @param {Date} [options.now]
 * @param {string} [options.alertTime]
 * @returns {Promise<object>}
 */
export async function attendanceBoard(repository, facilityId, options = {}) {
  const now = options.now ?? new Date();
  const todayKey = dayKey(now);
  const alertTime = options.alertTime ?? ATTENDANCE.DEFAULT_ALERT_TIME;

  const [doctorsPage, attendanceLogs, rosters, leaves] = await Promise.all([
    repository.listDoctors({ facilityId }, { limit: 200, offset: 0 }),
    repository.listAttendanceByFacility({ facilityId, date: todayKey }),
    repository.listRosters({ facilityId, date: todayKey }),
    repository.listLeaves({ facilityId, date: todayKey }),
  ]);

  const logsByDoctor = new Map(attendanceLogs.map((log) => [log.doctorId, log]));
  const rosterByDoctor = new Map(rosters.map((roster) => [roster.doctorId, roster]));
  const leaveByDoctor = new Map(leaves.map((leave) => [leave.doctorId, leave]));
  const nowMinutes = minutesSinceMidnight(now);

  const entries = [];
  for (const doctor of doctorsPage.items) {
    const log = logsByDoctor.get(doctor.id) ?? null;
    const roster = rosterByDoctor.get(doctor.id) ?? null;
    const leave = leaveByDoctor.get(doctor.id) ?? null;

    const history = await repository.listAttendance(
      doctor.id,
      dayKey(addDays(now, -(ATTENDANCE.WINDOW_DAYS - 1))),
    );
    const reliability = reliabilityPercent(history, { windowDays: ATTENDANCE.WINDOW_DAYS });

    const risk = attendanceRisk({
      doctorId: doctor.id,
      onRosterToday: roster ? roster.shift !== 'OFF' : true,
      checkInAt: log?.checkInAt ?? null,
      onLeave: Boolean(leave) || Boolean(log?.onLeave),
      nowMinutes,
      alertTime: doctor.alertTime ?? alertTime,
    });

    entries.push({
      doctorId: doctor.id,
      name: doctor.name,
      department: doctor.department,
      shift: roster?.shift ?? 'DAY',
      shiftStart: roster?.shiftStart ?? '09:00',
      checkInAt: log?.checkInAt ?? null,
      checkOutAt: log?.checkOutAt ?? null,
      onLeave: Boolean(leave) || Boolean(log?.onLeave),
      leaveType: leave?.type ?? null,
      reliabilityPercent: reliability.reliabilityPercent,
      reliabilityRating: reliability.rating,
      lateDays: reliability.lateDays,
      ...risk,
    });
  }

  const summary = summarizeAttendance(entries);
  return {
    facilityId,
    date: todayKey,
    alertTime,
    nowMinutes,
    entries,
    summary,
    doctorPresentToday: summary.anyPresent,
  };
}

/**
 * Record a doctor check-in.
 *
 * @param {object} repository
 * @param {object} input
 * @param {string} input.doctorId
 * @param {string} input.facilityId
 * @param {string} [input.note]
 * @param {object} actor
 * @param {object} [options]
 * @param {Date} [options.now]
 * @returns {Promise<object>}
 */
export async function checkIn(repository, input, actor, options = {}) {
  const now = options.now ?? new Date();
  const todayKey = dayKey(now);
  const doctor = await repository.getDoctor(input.doctorId);
  if (!doctor) throw new NotFoundError(`Doctor not found: ${input.doctorId}`);

  const alertTime = doctor.alertTime ?? ATTENDANCE.DEFAULT_ALERT_TIME;
  const late = isLate({ checkInAt: now.toISOString() }, { alertTime });

  const record = await repository.upsertAttendance({
    id: `ATT-${input.doctorId}-${todayKey}`,
    doctorId: input.doctorId,
    facilityId: input.facilityId,
    date: todayKey,
    checkInAt: now.toISOString(),
    checkOutAt: null,
    onLeave: false,
    late,
    note: input.note ?? null,
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'ATTENDANCE',
    entityId: record.id,
    facilityId: input.facilityId,
    action: 'CHECK_IN',
    actor: actor.subject,
    role: actor.role,
    after: { doctorId: input.doctorId, at: record.checkInAt, late },
    createdAt: now.toISOString(),
  });

  invalidateFor(input.facilityId);
  return { ...record, late, alertTime };
}

/**
 * Record a doctor check-out.
 *
 * @param {object} repository
 * @param {object} input
 * @param {object} actor
 * @param {object} [options]
 * @param {Date} [options.now]
 * @returns {Promise<object>}
 */
export async function checkOut(repository, input, actor, options = {}) {
  const now = options.now ?? new Date();
  const todayKey = dayKey(now);
  const id = `ATT-${input.doctorId}-${todayKey}`;
  const existing = await repository.upsertAttendance({
    id,
    doctorId: input.doctorId,
    facilityId: input.facilityId,
    date: todayKey,
    checkOutAt: now.toISOString(),
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'ATTENDANCE',
    entityId: id,
    facilityId: input.facilityId,
    action: 'CHECK_OUT',
    actor: actor.subject,
    role: actor.role,
    after: { doctorId: input.doctorId, at: existing.checkOutAt },
    createdAt: now.toISOString(),
  });

  invalidateFor(input.facilityId);
  return existing;
}

/**
 * Record an approved leave (excluded from the reliability denominator).
 *
 * @param {object} repository
 * @param {object} input
 * @param {object} actor
 * @returns {Promise<object>}
 */
export async function recordLeave(repository, input, actor) {
  const doctor = await repository.getDoctor(input.doctorId);
  if (!doctor) throw new NotFoundError(`Doctor not found: ${input.doctorId}`);

  const leave = await repository.addLeave({
    id: newId('LV'),
    doctorId: input.doctorId,
    facilityId: doctor.facilityId,
    date: input.date,
    type: input.type,
    note: input.note ?? null,
    approvedBy: actor.subject,
    approvedAt: new Date().toISOString(),
  });

  await repository.upsertAttendance({
    id: `ATT-${input.doctorId}-${input.date}`,
    doctorId: input.doctorId,
    facilityId: doctor.facilityId,
    date: input.date,
    checkInAt: null,
    checkOutAt: null,
    onLeave: true,
    leaveType: input.type,
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'ATTENDANCE',
    entityId: leave.id,
    facilityId: doctor.facilityId,
    action: 'LEAVE',
    actor: actor.subject,
    role: actor.role,
    after: { doctorId: input.doctorId, date: input.date, type: input.type },
    createdAt: new Date().toISOString(),
  });

  invalidateFor(doctor.facilityId);
  return leave;
}
