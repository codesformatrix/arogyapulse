/**
 * OPD queue service: token issuance, counter state, wait estimation and
 * peak-hour prediction.
 *
 * Only anonymous tokens, counters and timings are stored or returned - there is
 * no patient identity anywhere in this flow, which is what allows the public
 * "how crowded is it now" page to exist at all.
 *
 * @module services/queueService
 */

import { DEPARTMENTS, QUEUE } from '../config/constants.js';
import { NotFoundError } from '../utils/errors.js';
import { newId, uuid } from '../utils/ids.js';
import { addDays, dayKey, diffMinutes, partsInTz, toDate } from '../utils/time.js';
import { invalidateFor } from '../utils/caches.js';
import {
  estimateWaitTime,
  footfallTrend,
  hourlySeries,
  observedServiceMinutes,
  predictedPeakHours,
} from './waitTime.js';

/** Single-letter anonymous token prefix per department. */
const DEPARTMENT_PREFIX = {
  OPD_GENERAL: 'A',
  OPD_ANC: 'M',
  OPD_CHILD: 'C',
  IMMUNISATION: 'I',
  NCD_CLINIC: 'N',
  EMERGENCY: 'E',
};

/**
 * Live queue state for one facility.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {object} [options]
 * @param {Date} [options.now]
 * @returns {Promise<object>}
 */
export async function queueState(repository, facilityId, options = {}) {
  const now = options.now ?? new Date();
  const todayKey = dayKey(now);

  const [tokensPage, counters] = await Promise.all([
    repository.listTokens({ facilityId, date: todayKey }, { limit: 2000, offset: 0 }),
    repository.listCounters(facilityId),
  ]);

  const tokens = tokensPage.items;
  const waiting = tokens.filter((token) => token.status === 'WAITING');
  const served = tokens.filter((token) => token.status === 'SERVED');
  const openCounters = counters.filter((counter) => counter.isOpen);

  const avgServiceMinutes = observedServiceMinutes(served, diffMinutes);
  const estimate = estimateWaitTime({
    waiting: waiting.length,
    activeCounters: openCounters.length,
    avgServiceMinutes,
  });

  return {
    facilityId,
    date: todayKey,
    issuedToday: tokens.length,
    waiting: waiting.length,
    served: served.length,
    noShow: tokens.filter((token) => token.status === 'NO_SHOW').length,
    counters: counters.map((counter) => ({
      counterId: counter.counterId,
      department: counter.department,
      isOpen: counter.isOpen,
    })),
    openCounters: openCounters.length,
    ...estimate,
    currentToken: served.at(-1)?.token ?? null,
    nowServing: waiting.length ? waiting[0].token : null,
  };
}

/**
 * Issue the next anonymous token for a department.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {string} department
 * @param {object} actor
 * @param {object} [options]
 * @param {Date} [options.now]
 * @returns {Promise<object>}
 */
export async function issueToken(repository, facilityId, department, actor, options = {}) {
  const now = options.now ?? new Date();
  const todayKey = dayKey(now);
  const prefix = DEPARTMENT_PREFIX[department] ?? 'X';

  const page = await repository.listTokens({ facilityId, date: todayKey }, { limit: 2000, offset: 0 });
  const sequence = page.items.length + 1;

  const token = {
    id: newId('TOK'),
    facilityId,
    department,
    token: `${prefix}-${String(sequence).padStart(3, '0')}`,
    date: todayKey,
    hour: partsInTz(now).hour,
    status: 'WAITING',
    counterId: null,
    issuedAt: now.toISOString(),
    servedAt: null,
    waitMinutes: null,
  };

  await repository.addToken(token);
  await addFootfallPoint(repository, facilityId, department, now);
  await repository.addAudit({
    id: uuid(),
    entityType: 'TOKEN',
    entityId: token.id,
    facilityId,
    action: 'ISSUE',
    actor: actor.subject,
    role: actor.role,
    after: { token: token.token, department },
    createdAt: now.toISOString(),
  });

  invalidateFor(facilityId);
  return token;
}

/**
 * Mark a token served at a counter.
 *
 * @param {object} repository
 * @param {string} tokenId
 * @param {number} counterId
 * @param {object} actor
 * @returns {Promise<object>}
 */
export async function serveToken(repository, tokenId, counterId, actor) {
  const token = await repository.getToken(tokenId);
  if (!token) throw new NotFoundError(`Token not found: ${tokenId}`);
  if (token.status !== 'WAITING') {
    throw new NotFoundError(`Token ${token.token} is not waiting`);
  }

  const servedAt = new Date();
  const updated = await repository.updateToken(tokenId, {
    status: 'SERVED',
    counterId,
    servedAt: servedAt.toISOString(),
    waitMinutes: Math.max(0, diffMinutes(token.issuedAt, servedAt)),
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'TOKEN',
    entityId: tokenId,
    facilityId: token.facilityId,
    action: 'SERVE',
    actor: actor.subject,
    role: actor.role,
    before: { status: 'WAITING' },
    after: { status: 'SERVED', counterId, waitMinutes: updated.waitMinutes },
    createdAt: servedAt.toISOString(),
  });

  invalidateFor(token.facilityId);
  return updated;
}

/**
 * Open or close an OPD counter.
 *
 * @param {object} repository
 * @param {object} input
 * @param {object} actor
 * @returns {Promise<object>}
 */
export async function setCounter(repository, input, actor) {
  const counter = await repository.upsertCounter({
    id: `CTR-${input.facilityId}-${input.counterId}`,
    facilityId: input.facilityId,
    counterId: input.counterId,
    department: input.department,
    isOpen: input.isOpen,
  });

  await repository.addAudit({
    id: uuid(),
    entityType: 'TOKEN',
    entityId: counter.id,
    facilityId: input.facilityId,
    action: input.isOpen ? 'COUNTER_OPEN' : 'COUNTER_CLOSE',
    actor: actor.subject,
    role: actor.role,
    after: { counterId: input.counterId, isOpen: input.isOpen },
    createdAt: new Date().toISOString(),
  });

  invalidateFor(input.facilityId);
  return counter;
}

/**
 * Hourly footfall chart plus predicted peak hours for the current weekday.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {object} [options]
 * @param {Date} [options.now]
 * @param {string} [options.department]
 * @returns {Promise<object>}
 */
export async function footfallReport(repository, facilityId, options = {}) {
  const now = options.now ?? new Date();
  const todayKey = dayKey(now);
  const fromKey = dayKey(addDays(now, -(QUEUE.HISTORY_DAYS - 1)));

  const rows = await repository.footfallBetween(facilityId, fromKey, todayKey);
  const filtered = options.department
    ? rows.filter((row) => row.department === options.department)
    : rows;

  const todaysRows = filtered.filter((row) => row.date === todayKey);
  const todayByHour = hourlySeries(todaysRows);
  const todaySoFar = todayByHour.reduce((total, slot) => total + slot.count, 0);

  // Same weekday, previous occurrences inside the window.
  const weekday = partsInTz(now).weekday;
  const history = filtered
    .filter((row) => row.date !== todayKey)
    .map((row) => ({ ...row, weekday: row.weekday ?? partsInTz(`${row.date}T00:00:00Z`).weekday }));

  const peaks = predictedPeakHours(history, { weekday, todayKey, historyDays: QUEUE.HISTORY_DAYS });
  const previousSameWeekday = history.filter((row) => row.weekday === weekday);
  const occurrences = new Set(previousSameWeekday.map((row) => row.date)).size || 1;
  const historicalAverage =
    previousSameWeekday.reduce((total, row) => total + row.count, 0) / occurrences;

  return {
    facilityId,
    date: todayKey,
    department: options.department ?? null,
    hourly: todayByHour,
    todaySoFar,
    historicalAverage: Math.round(historicalAverage),
    trend: footfallTrend(todaySoFar, historicalAverage),
    predictedPeakHours: peaks,
    historyDays: QUEUE.HISTORY_DAYS,
  };
}

/**
 * Add (or increment) today's hourly footfall counter for a department.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {string} department
 * @param {Date} at
 * @returns {Promise<object>}
 */
export async function addFootfallPoint(repository, facilityId, department, at) {
  const date = dayKey(at);
  const { hour, weekday } = partsInTz(at);
  const id = `FF-${facilityId}-${department}-${date}-${hour}`;

  const existing = (await repository.listFootfall({ facilityId, department, date })).find(
    (row) => row.hour === hour,
  );

  return repository.addFootfall({
    id,
    facilityId,
    department,
    date,
    weekday,
    hour,
    count: (existing?.count ?? 0) + 1,
  });
}

/**
 * Public "how crowded is it now" payload - aggregate counts only.
 *
 * @param {object} repository
 * @param {string} facilityId
 * @param {object} [options]
 * @param {Date} [options.now]
 * @returns {Promise<object>}
 */
export async function publicCrowding(repository, facilityId, options = {}) {
  const state = await queueState(repository, facilityId, options);
  return {
    facilityId,
    load: state.load,
    estimatedWaitMinutes: state.estimatedWaitMinutes,
    advice: state.advice,
    waiting: state.waiting,
    openCounters: state.openCounters,
    currentToken: state.currentToken,
    updatedAt: new Date().toISOString(),
  };
}

export { DEPARTMENTS, toDate };
