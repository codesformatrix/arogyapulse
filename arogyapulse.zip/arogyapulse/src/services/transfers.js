/**
 * Inter-facility transfer matching (pure).
 *
 * Two redistribution strategies, both auditable and both explainable:
 *   1. Surplus -> deficit, nearest donor first (minimises vehicle time).
 *   2. Expiry-risk redistribution: move stock that will expire before the
 *      holding facility can consume it to a facility that will.
 *
 * @module services/transfers
 */

import { TRANSFER } from '../config/constants.js';
import { haversineKm } from './geo.js';
import { round } from '../utils/random.js';
import { dayKey, daysBetweenKeys, toDate } from '../utils/time.js';

/**
 * @typedef {Object} StockLine
 * @property {string} facilityId
 * @property {string} medicineId
 * @property {number} stock
 * @property {number} perDay - Forecast consumption per day.
 * @property {number|null} daysOfCover
 * @property {{latitude: number, longitude: number}} [coordinates]
 * @property {{id: string, batchNo?: string, quantity: number, expiryDate: string|Date}[]} [batches]
 */

/**
 * @typedef {Object} TransferSuggestion
 * @property {string} medicineId
 * @property {string} fromFacilityId
 * @property {string} toFacilityId
 * @property {number} units
 * @property {number} distanceKm
 * @property {string} reason - 'SURPLUS_TO_DEFICIT' | 'EXPIRY_RISK'
 * @property {number} donorDaysOfCoverAfter
 * @property {number|null} recipientDaysOfCoverBefore
 * @property {number|null} recipientDaysOfCoverAfter
 * @property {number} score
 * @property {string} rationale - One-line human explanation (shown in UI + briefing).
 */

/**
 * How many units a donor can spare without dropping below its own safety cover.
 *
 * @param {object} line
 * @param {number} line.stock
 * @param {number} line.perDay
 * @param {object} [policy]
 * @param {number} [policy.donorMinDaysOfCover]
 * @returns {number}
 */
export function donorSpareUnits(line, policy = {}) {
  const minCover = policy.donorMinDaysOfCover ?? TRANSFER.DONOR_MIN_DAYS_OF_COVER;
  const stock = Math.max(0, Number(line?.stock) || 0);
  const perDay = Math.max(0, Number(line?.perDay) || 0);
  const keep = perDay * minCover;
  const cap = stock * (policy.maxShareOfDonor ?? TRANSFER.MAX_SHARE_OF_DONOR);
  return Math.max(0, Math.floor(Math.min(stock - keep, cap)));
}

/**
 * How many units a recipient still needs to reach a safe cover.
 *
 * @param {object} line
 * @param {number} line.stock
 * @param {number} line.perDay
 * @param {object} [policy]
 * @param {number} [policy.targetDaysOfCover] - Defaults to 7 days, matching the
 *   AMBER threshold; the eligibility threshold is a separate constant.
 * @returns {number}
 */
export function recipientNeedUnits(line, policy = {}) {
  const target = policy.targetDaysOfCover ?? TRANSFER.TARGET_DAYS_OF_COVER;
  const stock = Math.max(0, Number(line?.stock) || 0);
  const perDay = Math.max(0, Number(line?.perDay) || 0);
  return Math.max(0, Math.ceil(perDay * target - stock));
}

/**
 * Match surplus facilities to deficit facilities for every medicine in need.
 *
 * Donors are considered nearest-first and are consumed greedily: a single
 * donor can serve several recipients until it is exhausted, but never below
 * its own safety cover.
 *
 * @param {StockLine[]} lines - Facility x medicine stock lines with forecasts.
 * @param {object} [policy]
 * @param {number} [policy.minUnits]
 * @param {number} [policy.maxDistanceKm]
 * @param {number} [policy.donorMinDaysOfCover]
 * @param {number} [policy.recipientMaxDaysOfCover]
 * @param {number} [policy.limit] - Maximum number of suggestions to return.
 * @returns {TransferSuggestion[]} Sorted by score (most urgent + cheapest trip first).
 */
export function suggestTransfers(lines, policy = {}) {
  const minUnits = policy.minUnits ?? TRANSFER.MIN_UNITS;
  const maxDistanceKm = policy.maxDistanceKm ?? TRANSFER.MAX_DISTANCE_KM;
  const limit = policy.limit ?? 25;
  const list = Array.isArray(lines) ? lines : [];

  const medicineIds = [...new Set(list.map((line) => line.medicineId))];
  const suggestions = [];

  for (const medicineId of medicineIds) {
    const forMedicine = list.filter((line) => line.medicineId === medicineId);
    const deficits = forMedicine
      .filter((line) => (line.daysOfCover ?? 0) < (policy.recipientMaxDaysOfCover ?? TRANSFER.RECIPIENT_MAX_DAYS_OF_COVER))
      .map((line) => ({ line, need: recipientNeedUnits(line, policy) }))
      .filter((entry) => entry.need > 0)
      .sort((a, b) => a.need - b.need === 0 ? a.line.daysOfCover - b.line.daysOfCover : b.need - a.need);

    const donors = forMedicine
      .map((line) => ({ line, spare: donorSpareUnits(line, policy) }))
      .filter((entry) => entry.spare >= minUnits);

    if (deficits.length === 0 || donors.length === 0) continue;

    const available = new Map(donors.map((entry) => [entry.line.facilityId, entry.spare]));

    for (const deficit of deficits) {
      const recipient = deficit.line;
      let stillNeeded = deficit.need;

      const candidates = donors
        .map((entry) => ({
          donor: entry.line,
          distanceKm: haversineKm(donorCoordinates(entry.line), donorCoordinates(recipient)),
        }))
        .filter((entry) => entry.donor.facilityId !== recipient.facilityId)
        .filter((entry) => Number.isFinite(entry.distanceKm) && entry.distanceKm <= maxDistanceKm)
        .sort((a, b) => a.distanceKm - b.distanceKm);

      for (const candidate of candidates) {
        if (stillNeeded <= 0) break;
        const remaining = available.get(candidate.donor.facilityId) ?? 0;
        const units = Math.min(stillNeeded, remaining);
        if (units < minUnits) continue;

        available.set(candidate.donor.facilityId, remaining - units);
        stillNeeded -= units;

        const donorStockAfter = Math.max(0, candidate.donor.stock - units);
        const recipientStockAfter = recipient.stock + units;
        const donorCoverAfter =
          candidate.donor.perDay > 0 ? round(donorStockAfter / candidate.donor.perDay, 1) : null;
        const recipientCoverAfter =
          recipient.perDay > 0 ? round(recipientStockAfter / recipient.perDay, 1) : null;

        suggestions.push({
          medicineId,
          fromFacilityId: candidate.donor.facilityId,
          toFacilityId: recipient.facilityId,
          units,
          distanceKm: candidate.distanceKm,
          reason: 'SURPLUS_TO_DEFICIT',
          donorDaysOfCoverAfter: donorCoverAfter,
          recipientDaysOfCoverBefore: recipient.daysOfCover ?? null,
          recipientDaysOfCoverAfter: recipientCoverAfter,
          score: round(units / Math.max(1, candidate.distanceKm), 3),
          rationale: `Move ${units} units ${candidate.distanceKm} km: donor keeps ${donorCoverAfter ?? 'unlimited'} days of cover, recipient rises to ${recipientCoverAfter ?? 'unlimited'} days.`,
        });
      }
    }
  }

  return suggestions.sort((a, b) => b.score - a.score).slice(0, limit);
}

/**
 * Suggest expiry-risk redistribution.
 *
 * A batch is worth moving when the holding facility cannot consume it before
 * it expires, but a nearby facility with higher demand can.
 *
 * @param {StockLine[]} lines
 * @param {object} [options]
 * @param {string} [options.todayKey]
 * @param {number} [options.windowDays] - Only consider batches expiring inside this window.
 * @param {number} [options.maxDistanceKm]
 * @param {number} [policy.limit]
 * @returns {TransferSuggestion[]}
 */
export function suggestExpiryRedistribution(lines, options = {}) {
  const today = options.todayKey ?? dayKey(new Date());
  const windowDays = options.windowDays ?? TRANSFER.EXPIRY_RISK_DAYS;
  const maxDistanceKm = options.maxDistanceKm ?? TRANSFER.MAX_DISTANCE_KM;
  const limit = options.limit ?? 15;
  const list = Array.isArray(lines) ? lines : [];
  const suggestions = [];

  const byMedicine = new Map();
  for (const line of list) {
    const bucket = byMedicine.get(line.medicineId);
    if (bucket) bucket.push(line);
    else byMedicine.set(line.medicineId, [line]);
  }

  for (const [medicineId, medicineLines] of byMedicine) {
    for (const holder of medicineLines) {
      const batches = Array.isArray(holder.batches) ? holder.batches : [];
      for (const batch of batches) {
        const quantity = Math.max(0, Number(batch?.quantity) || 0);
        if (quantity < (options.minUnits ?? TRANSFER.MIN_UNITS)) continue;
        const expiry = toDate(batch.expiryDate);
        if (!expiry) continue;
        const daysLeft = daysBetweenKeys(today, dayKey(expiry));
        if (daysLeft < 0 || daysLeft > windowDays) continue;

        // Can the holder burn this batch in time at its own consumption rate?
        const consumableInTime = holder.perDay * Math.max(0, daysLeft);
        if (consumableInTime >= quantity) continue;

        const receivers = medicineLines
          .filter((line) => line.facilityId !== holder.facilityId)
          .map((line) => ({
            line,
            distanceKm: haversineKm(donorCoordinates(holder), donorCoordinates(line)),
            canConsume: line.perDay * Math.max(0, daysLeft),
          }))
          .filter((entry) => Number.isFinite(entry.distanceKm) && entry.distanceKm <= maxDistanceKm)
          .filter((entry) => entry.canConsume >= quantity * 0.5)
          .sort((a, b) => b.canConsume - a.canConsume || a.distanceKm - b.distanceKm);

        const receiver = receivers[0];
        if (!receiver) continue;

        suggestions.push({
          medicineId,
          fromFacilityId: holder.facilityId,
          toFacilityId: receiver.line.facilityId,
          units: quantity,
          distanceKm: receiver.distanceKm,
          reason: 'EXPIRY_RISK',
          donorDaysOfCoverAfter: holder.daysOfCover ?? null,
          recipientDaysOfCoverBefore: receiver.line.daysOfCover ?? null,
          recipientDaysOfCoverAfter:
            receiver.line.perDay > 0
              ? round((receiver.line.stock + quantity) / receiver.line.perDay, 1)
              : null,
          score: round(quantity / Math.max(1, daysLeft), 3),
          rationale: `Batch ${batch.batchNo ?? batch.id} expires in ${daysLeft} days; ${holder.facilityId} can only use ${Math.floor(consumableInTime)} of ${quantity} units.`,
        });
      }
    }
  }

  return suggestions.sort((a, b) => b.score - a.score).slice(0, limit);
}

/**
 * Read coordinates defensively so a facility with a missing geocode never
 * breaks the whole matching pass.
 *
 * @param {StockLine} line
 * @returns {{latitude: number, longitude: number}|undefined}
 */
function donorCoordinates(line) {
  const coordinates = line?.coordinates;
  if (!coordinates) return undefined;
  if (!Number.isFinite(coordinates.latitude) || !Number.isFinite(coordinates.longitude)) {
    return undefined;
  }
  return coordinates;
}
