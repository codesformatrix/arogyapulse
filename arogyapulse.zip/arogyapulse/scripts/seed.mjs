#!/usr/bin/env node
/**
 * Seed script.
 *
 *   npm run seed              # repository chosen by env (REPOSITORY / GOOGLE_CLOUD_PROJECT)
 *   npm run seed -- --memory  # force the in-memory store (used by tests / CI)
 *
 * Options
 *   --memory            force the in-memory repository
 *   --firestore         force Cloud Firestore
 *   --days <n>          days of history to generate (default 45, minimum 14)
 *   --key <seedKey>     change every random value in the dataset
 *   --at <ISO instant>  pin "now" so the dataset is fully reproducible
 *   --print             print the generated summary as JSON and exit
 *
 * The generator is pure, so `--at` + `--key` reproduce a byte-identical
 * dataset - which is what makes the demo script and the integration tests
 * stable across machines.
 *
 * @module scripts/seed
 */

import process from 'node:process';
import { pathToFileURL } from 'node:url';

import { generateDataset } from '../src/seed/generator.js';
import { createRepository } from '../src/repositories/index.js';
import { createLogger } from '../src/utils/logger.js';
import { toDate } from '../src/utils/time.js';

const log = createLogger('seed');

/**
 * Parse the process argv into options.
 *
 * @param {string[]} argv
 * @returns {{kind: string|undefined, days: number, seedKey: string, generatedAt: Date|undefined, print: boolean, help: boolean}}
 */
export function parseArgs(argv) {
  const options = {
    kind: undefined,
    days: 45,
    seedKey: 'arogyapulse-demo',
    generatedAt: undefined,
    print: false,
    help: false,
  };

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    switch (arg) {
      case '--memory':
        options.kind = 'memory';
        break;
      case '--firestore':
        options.kind = 'firestore';
        break;
      case '--days':
        options.days = Number(argv[index + 1]) || 45;
        index += 1;
        break;
      case '--key':
        options.seedKey = String(argv[index + 1] ?? options.seedKey);
        index += 1;
        break;
      case '--at':
        options.generatedAt = toDate(argv[index + 1]) ?? undefined;
        index += 1;
        break;
      case '--print':
        options.print = true;
        break;
      case '--help':
      case '-h':
        options.help = true;
        break;
      default:
        break;
    }
  }

  return options;
}

const HELP = `ArogyaPulse seed

  npm run seed -- [options]

  --memory            use the in-memory repository
  --firestore         use Cloud Firestore
  --days <n>          days of history (default 45)
  --key <seedKey>     vary the synthetic data
  --at <ISO instant>  pin "now" for a reproducible dataset
  --print             print the summary JSON and exit
`;

/**
 * Write a generated dataset into a repository using batched writes.
 *
 * @param {object} repository
 * @param {ReturnType<typeof generateDataset>} dataset
 * @returns {Promise<Record<string, number>>}
 */
export async function loadDataset(repository, dataset) {
  const written = {};
  const collections = [
    ['facilities', dataset.facilities],
    ['medicines', dataset.medicines],
    ['stock', dataset.stock],
    ['batches', dataset.batches],
    ['dispensing', dataset.dispensing],
    ['footfall', dataset.footfall],
    ['tokens', dataset.tokens],
    ['counters', dataset.counters],
    ['wards', dataset.wards],
    ['doctors', dataset.doctors],
    ['attendance', dataset.attendance],
    ['rosters', dataset.rosters],
    ['leaves', dataset.leaves],
    ['indents', dataset.indents],
    ['transfers', dataset.transfers],
    ['referrals', dataset.referrals],
    ['audit', dataset.audit],
  ];

  for (const [name, documents] of collections) {
    if (!documents?.length) {
      written[name] = 0;
      continue;
    }
    written[name] = await repository.bulkWrite(name, documents);
  }

  return written;
}

/**
 * Seed a repository and return the dataset metadata.
 *
 * @param {object} [options]
 * @param {object} [options.repository] - Repository to write into (created when omitted).
 * @param {number} [options.days]
 * @param {string} [options.seedKey]
 * @param {Date} [options.generatedAt]
 * @param {'memory'|'firestore'} [options.kind]
 * @returns {Promise<{dataset: ReturnType<typeof generateDataset>, written: Record<string, number>, repository: object}>}
 */
export async function seed(options = {}) {
  const dataset = generateDataset({
    days: options.days,
    seedKey: options.seedKey,
    generatedAt: options.generatedAt,
  });

  const repository = options.repository ?? (await createRepository({ kind: options.kind }));

  if (typeof repository.reset === 'function') repository.reset();
  const written = await loadDataset(repository, dataset);

  log.info('Seed complete', { kind: repository.kind, meta: dataset.meta, written });
  return { dataset, written, repository };
}

/**
 * CLI entry point.
 *
 * @param {string[]} argv
 * @returns {Promise<number>} Exit code.
 */
export async function main(argv) {
  const options = parseArgs(argv);

  if (options.help) {
    process.stdout.write(HELP);
    return 0;
  }

  const dataset = generateDataset({
    days: options.days,
    seedKey: options.seedKey,
    generatedAt: options.generatedAt,
  });

  if (options.print) {
    process.stdout.write(`${JSON.stringify(dataset.meta, null, 2)}\n`);
    return 0;
  }

  const repository = await createRepository({ kind: options.kind });
  const written = await loadDataset(repository, dataset);

  process.stdout.write(
    `${JSON.stringify(
      {
        repository: repository.kind,
        note: dataset.meta.note,
        generatedAt: dataset.meta.generatedAt,
        historyDays: dataset.meta.historyDays,
        written,
      },
      null,
      2,
    )}\n`,
  );

  if (repository.kind === 'memory') {
    process.stdout.write(
      '\nIn-memory seed finished. The data is not persisted - start the server with\nSEED_ON_BOOT=true (the default) so it reseeds on boot, or run: REPOSITORY=firestore npm run seed\n',
    );
  }

  await repository.close?.();
  return 0;
}

const isDirectRun =
  typeof process.argv[1] === 'string' && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isDirectRun) {
  main(process.argv.slice(2))
    .then((code) => process.exit(code))
    .catch((error) => {
      log.error('Seed failed', { error });
      process.exit(1);
    });
}

export default seed;
