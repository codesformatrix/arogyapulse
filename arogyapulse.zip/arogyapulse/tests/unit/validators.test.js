import { describe, expect, it } from '@jest/globals';

import { formatIssues, parseOr, parseWith } from '../../src/services/validate.js';
import { ValidationError } from '../../src/utils/errors.js';
import {
  askSchema,
  bedUpdateSchema,
  briefingSchema,
  dispensingSchema,
  indentSchema,
  loginSchema,
  nlEntrySchema,
  offlineBatchSchema,
  paginationSchema,
  stockAdjustSchema,
  tokenIssueSchema,
} from '../../src/validators/index.js';

describe('parseWith', () => {
  it('returns the parsed value with defaults applied', () => {
    expect(parseWith(paginationSchema, {})).toEqual({ limit: 25, offset: 0 });
    expect(parseWith(paginationSchema, { limit: '10', offset: '5' })).toEqual({ limit: 10, offset: 5 });
  });

  it('throws a ValidationError carrying machine readable issues', () => {
    expect.assertions(4);
    try {
      parseWith(paginationSchema, { limit: 5000 }, 'stock.list');
    } catch (error) {
      expect(error).toBeInstanceOf(ValidationError);
      expect(error.statusCode).toBe(400);
      expect(error.message).toContain('stock.list');
      expect(error.details.issues[0].path).toBe('limit');
    }
  });

  it('caps the page size so a list endpoint cannot be abused', () => {
    expect(() => parseWith(paginationSchema, { limit: 101 })).toThrow(ValidationError);
  });
});

describe('parseOr and formatIssues', () => {
  it('falls back instead of throwing', () => {
    expect(parseOr(paginationSchema, { limit: 'nope' }, { limit: 25, offset: 0 })).toEqual({
      limit: 25,
      offset: 0,
    });
  });

  it('flattens issues for the API error body', () => {
    expect(formatIssues([{ path: 'quantity', message: 'too small' }])).toEqual([
      { field: 'quantity', message: 'too small' },
    ]);
  });
});

describe('stockAdjustSchema', () => {
  it('accepts a signed adjustment with a reason', () => {
    const parsed = parseWith(stockAdjustSchema, {
      facilityId: 'FAC-PHC-RAHATA',
      medicineId: 'MED-ORS',
      delta: '200',
      reason: 'RECEIPT',
    });
    expect(parsed).toMatchObject({ delta: 200, reason: 'RECEIPT' });
  });

  it('rejects a zero delta and an unknown reason', () => {
    expect(() =>
      parseWith(stockAdjustSchema, { facilityId: 'F', medicineId: 'M', delta: 0, reason: 'RECEIPT' }),
    ).toThrow(ValidationError);
    expect(() =>
      parseWith(stockAdjustSchema, { facilityId: 'F', medicineId: 'M', delta: 5, reason: 'MADE_UP' }),
    ).toThrow(ValidationError);
  });

  it('validates the expiry date format', () => {
    expect(() =>
      parseWith(stockAdjustSchema, {
        facilityId: 'F',
        medicineId: 'M',
        delta: 5,
        reason: 'RECEIPT',
        expiryDate: '18/10/2026',
      }),
    ).toThrow(ValidationError);
  });
});

describe('dispensingSchema', () => {
  it('requires a positive quantity', () => {
    expect(
      parseWith(dispensingSchema, { facilityId: 'F', medicineId: 'M', quantity: '30' }).quantity,
    ).toBe(30);
    expect(() => parseWith(dispensingSchema, { facilityId: 'F', medicineId: 'M', quantity: 0 })).toThrow(
      ValidationError,
    );
  });
});

describe('bedUpdateSchema', () => {
  it('accepts a one-tap +/- change', () => {
    expect(parseWith(bedUpdateSchema, { field: 'occupied', delta: '-1' })).toEqual({
      field: 'occupied',
      delta: -1,
    });
  });

  it('rejects an unknown field', () => {
    expect(() => parseWith(bedUpdateSchema, { field: 'total', delta: 1 })).toThrow(ValidationError);
  });
});

describe('tokenIssueSchema', () => {
  it('only accepts known OPD departments', () => {
    expect(parseWith(tokenIssueSchema, { facilityId: 'F', department: 'OPD_ANC' }).department).toBe('OPD_ANC');
    expect(() => parseWith(tokenIssueSchema, { facilityId: 'F', department: 'DENTAL' })).toThrow(ValidationError);
  });
});

describe('loginSchema', () => {
  it('accepts the four product roles and nothing else', () => {
    for (const role of ['district_officer', 'chc_admin', 'facility_staff', 'public']) {
      expect(parseWith(loginSchema, { role }).role).toBe(role);
    }
    expect(() => parseWith(loginSchema, { role: 'superuser' })).toThrow(ValidationError);
  });
});

describe('AI schemas', () => {
  it('bounds natural-language entry length', () => {
    expect(parseWith(nlEntrySchema, { text: 'paracetamol 200 aaye', facilityId: 'F' }).text).toContain('paracetamol');
    expect(() => parseWith(nlEntrySchema, { text: 'x', facilityId: 'F' })).toThrow(ValidationError);
    expect(() => parseWith(nlEntrySchema, { text: 'a'.repeat(500), facilityId: 'F' })).toThrow(ValidationError);
  });

  it('defaults briefing and ask to English', () => {
    expect(parseWith(briefingSchema, {})).toMatchObject({ scope: 'facility', language: 'en' });
    expect(parseWith(askSchema, { question: 'ORS kitna bacha hai?' }).language).toBe('en');
    expect(() => parseWith(askSchema, { question: 'hi' })).toThrow(ValidationError);
  });
});

describe('indentSchema', () => {
  it('requires at least one line item with positive units', () => {
    expect(
      parseWith(indentSchema, { facilityId: 'F', items: [{ medicineId: 'M', units: '10' }] }).items[0].units,
    ).toBe(10);
    expect(() => parseWith(indentSchema, { facilityId: 'F', items: [] })).toThrow(ValidationError);
    expect(() =>
      parseWith(indentSchema, { facilityId: 'F', items: [{ medicineId: 'M', units: 0 }] }),
    ).toThrow(ValidationError);
  });
});

describe('offlineBatchSchema', () => {
  it('accepts queued API mutations and rejects non-API paths', () => {
    const valid = {
      operations: [
        { id: 'op-1', method: 'POST', path: '/api/stock/adjust', body: { delta: 5 }, capturedAt: '2026-10-18T04:00:00Z' },
      ],
    };
    expect(parseWith(offlineBatchSchema, valid).operations).toHaveLength(1);
    expect(() =>
      parseWith(offlineBatchSchema, { operations: [{ id: 'op-1', method: 'POST', path: '/etc/passwd' }] }),
    ).toThrow(ValidationError);
  });
});
