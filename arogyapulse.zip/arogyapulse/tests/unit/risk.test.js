import { describe, expect, it } from '@jest/globals';

import {
  attendanceRiskScore,
  bandFor,
  bedRiskScore,
  computeFacilityRisk,
  districtSummary,
  queueRiskScore,
  rankFacilities,
  stockRiskScore,
} from '../../src/services/risk.js';

describe('stockRiskScore', () => {
  it('weights RED lines more than AMBER and EXPIRY_RISK', () => {
    const result = stockRiskScore([
      { status: 'RED' },
      { status: 'AMBER' },
      { status: 'EXPIRY_RISK' },
      { status: 'GREEN' },
    ]);
    expect(result).toMatchObject({ red: 1, amber: 1, expiryRisk: 1, green: 1, total: 4 });
    expect(result.score).toBe(46.3); // 1.85/4 * 100, rounded to 1dp
  });

  it('returns a neutral score for a facility with no tracked stock', () => {
    expect(stockRiskScore([])).toMatchObject({ score: 0, total: 0 });
  });
});

describe('bedRiskScore', () => {
  it('scores a fully occupied facility at 100', () => {
    expect(bedRiskScore([{ total: 10, occupied: 9, reserved: 1 }])).toMatchObject({
      score: 100,
      available: 0,
      occupancyPercent: 100,
    });
  });

  it('never reports negative availability', () => {
    expect(bedRiskScore([{ total: 5, occupied: 8, reserved: 0 }]).available).toBe(0);
  });

  it('handles a facility with no wards', () => {
    expect(bedRiskScore([]).total).toBe(0);
  });
});

describe('queueRiskScore', () => {
  it('caps the score at a 90 minute wait', () => {
    expect(queueRiskScore({ estimatedWaitMinutes: 45 }).score).toBe(50);
    expect(queueRiskScore({ estimatedWaitMinutes: 900 }).score).toBe(100);
    expect(queueRiskScore({}).score).toBe(0);
  });
});

describe('attendanceRiskScore', () => {
  it('scores the share of rostered doctors who have not checked in', () => {
    expect(attendanceRiskScore({ presentCount: 1, absentCount: 1 })).toMatchObject({ score: 50, anyPresent: true });
  });

  it('treats an empty roster as no risk', () => {
    expect(attendanceRiskScore({ presentCount: 0, absentCount: 0 }).score).toBe(0);
  });
});

describe('computeFacilityRisk', () => {
  it('combines the four weighted components', () => {
    const facility = computeFacilityRisk({
      facilityId: 'F1',
      facilityName: 'PHC Rahata',
      facilityType: 'PHC',
      components: {
        stock: { ...stockRiskScore([{ status: 'RED' }, { status: 'RED' }]), },
        beds: bedRiskScore([{ total: 10, occupied: 10, reserved: 0 }]),
        queue: queueRiskScore({ estimatedWaitMinutes: 45 }),
        attendance: attendanceRiskScore({ presentCount: 1, absentCount: 1 }),
      },
    });

    // (100*40 + 100*20 + 50*20 + 50*20) / 100 = 80
    expect(facility.riskScore).toBe(80);
    expect(facility.riskBand).toBe('CRITICAL');
    expect(facility.topReasons[0]).toContain('below 3 days of cover');
  });

  it('produces a healthy score with default components', () => {
    const facility = computeFacilityRisk({ facilityId: 'F1', facilityName: 'PHC Newasa', components: {} });
    expect(facility.riskBand).toBe('OK');
    expect(facility.topReasons).toEqual(['No active operational risk detected']);
  });
});

describe('bandFor, rankFacilities and districtSummary', () => {
  const facilities = [
    { facilityId: 'A', facilityName: 'A', riskScore: 20, riskBand: 'MODERATE', components: { stock: { red: 1 }, beds: { available: 2 } } },
    { facilityId: 'B', facilityName: 'B', riskScore: 80, riskBand: 'CRITICAL', components: { stock: { red: 4 }, beds: { available: 0 } } },
    { facilityId: 'C', facilityName: 'C', riskScore: 10, riskBand: 'OK', components: { stock: { red: 0 }, beds: { available: 5 } } },
  ];

  it('bands a score', () => {
    expect(bandFor(75)).toBe('CRITICAL');
    expect(bandFor(50)).toBe('HIGH');
    expect(bandFor(25)).toBe('MODERATE');
    expect(bandFor(5)).toBe('OK');
  });

  it('ranks the worst facility first', () => {
    expect(rankFacilities(facilities).map((facility) => facility.facilityId)).toEqual(['B', 'A', 'C']);
  });

  it('rolls the district up into one header', () => {
    const summary = districtSummary(facilities);
    expect(summary).toMatchObject({
      facilityCount: 3,
      criticalCount: 1,
      totalRedMedicines: 5,
      totalFreeBeds: 7,
    });
    expect(summary.worstFacility.facilityId).toBe('B');
    expect(summary.averageRiskScore).toBeCloseTo(36.7, 1);
  });

  it('handles an empty district', () => {
    expect(districtSummary([])).toMatchObject({ facilityCount: 0, worstFacility: null, averageRiskScore: 0 });
  });
});
