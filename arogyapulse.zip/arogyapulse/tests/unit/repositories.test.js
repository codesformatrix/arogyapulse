import { describe, expect, it } from '@jest/globals';

import { InMemoryRepository } from '../../src/repositories/inMemoryRepository.js';
import { FirestoreRepository, normalize, prepare } from '../../src/repositories/firestoreRepository.js';
import { generateDataset } from '../../src/seed/generator.js';
import { loadDataset } from '../../scripts/seed.mjs';
import { createRepository, getRepository, resetRepository, setRepository } from '../../src/repositories/index.js';

/**
 * Minimal in-process stand-in for the Firestore Admin SDK surface used by
 * FirestoreRepository: enough of `collection().doc()/where()/orderBy()/get()`
 * and `batch()` to exercise the real query-building code paths.
 */
function createFakeFirestore() {
  /** @type {Map<string, Map<string, object>>} */
  const store = new Map();
  const calls = [];

  const collection = (name) => {
    if (!store.has(name)) store.set(name, new Map());
    const docs = store.get(name);

    const doc = (id) => ({
      id,
      async get() {
        const data = docs.get(id);
        return { exists: Boolean(data), id, data: () => (data ? { ...data } : undefined) };
      },
      async set(data, options) {
        const existing = docs.get(id);
        docs.set(id, options?.merge && existing ? { ...existing, ...data } : { ...data });
        return { writeTime: 'fake' };
      },
      async update(patch) {
        const existing = docs.get(id);
        if (!existing) throw new Error('No document to update');
        docs.set(id, { ...existing, ...patch });
        return { writeTime: 'fake' };
      },
      async delete() {
        docs.delete(id);
        return { writeTime: 'fake' };
      },
    });

    const query = (filters, ranges, orderBy, direction, limit, offset) => ({
      doc,
      async get() {
        calls.push({ name, filters, ranges, orderBy, direction, limit, offset });
        let rows = [...docs.entries()].map(([id, data]) => ({ id, data: () => ({ ...data }) }));
        for (const [field, value] of Object.entries(filters)) {
          rows = rows.filter((row) => row.data()[field] === value);
        }
        for (const range of ranges) {
          rows = rows.filter((row) => {
            const value = row.data()[range.field];
            if (range.op === '>=') return value >= range.value;
            if (range.op === '<=') return value <= range.value;
            return true;
          });
        }
        if (orderBy) {
          rows.sort((a, b) => {
            const left = a.data()[orderBy];
            const right = b.data()[orderBy];
            if (left === right) return 0;
            const comparison = left > right ? 1 : -1;
            return direction === 'desc' ? -comparison : comparison;
          });
        }
        if (offset) rows = rows.slice(offset);
        if (Number.isFinite(limit)) rows = rows.slice(0, limit);
        return { docs: rows };
      },
      where(field, op, value) {
        if (op === '==') return query({ ...filters, [field]: value }, ranges, orderBy, direction, limit, offset);
        return query(filters, [...ranges, { field, op, value }], orderBy, direction, limit, offset);
      },
      orderBy(field, dir) {
        return query(filters, ranges, field, dir, limit, offset);
      },
      offset(value) {
        return query(filters, ranges, orderBy, direction, limit, value);
      },
      limit(value) {
        return query(filters, ranges, orderBy, direction, value, offset);
      },
    });

    // An unfiltered query whose chained calls accumulate into `query(...)`;
    // `get` must honour whatever the chain accumulated.
    return query({}, [], null, 'asc', Infinity, 0);
  };

  return {
    collection,
    batch: () => {
      const operations = [];
      return {
        set: (ref, data) => operations.push({ ref, data }),
        async commit() {
          for (const operation of operations) await operation.ref.set(operation.data, { merge: true });
          return operations.map(() => ({ writeTime: 'fake' }));
        },
      };
    },
    calls,
    store,
  };
}

describe('InMemoryRepository', () => {
  const repository = new InMemoryRepository();

  it('round-trips a stock line and refuses unknown collections', async () => {
    await repository.upsertStock({ facilityId: 'F1', medicineId: 'M1', units: 100 });
    const line = await repository.getStock('F1', 'M1');
    expect(line).toMatchObject({ id: 'STK-F1-M1', units: 100 });
    expect(() => repository.collection('nope')).toThrow();
  });

  it('returns copies so callers cannot mutate the store', async () => {
    await repository.upsertFacility({ id: 'F1', name: 'PHC Test' });
    const facility = await repository.getFacility('F1');
    facility.name = 'hacked';
    expect((await repository.getFacility('F1')).name).toBe('PHC Test');
  });

  it('filters, sorts and paginates facilities', async () => {
    const local = new InMemoryRepository();
    await local.upsertFacility({ id: 'F1', name: 'Beta', type: 'PHC' });
    await local.upsertFacility({ id: 'F2', name: 'Alpha', type: 'CHC' });
    const page = await local.listFacilities({ filters: { type: 'PHC' }, limit: 10, offset: 0 });
    expect(page.total).toBe(1);
    expect(page.items[0].name).toBe('Beta');
  });

  it('appends and bounds a consumption series', async () => {
    const local = new InMemoryRepository();
    await local.upsertStock({ facilityId: 'F1', medicineId: 'M1', units: 10, consumptionSeries: [] });
    await local.appendConsumption('F1', 'M1', { date: '2026-10-17', quantity: 5 }, 3);
    await local.appendConsumption('F1', 'M1', { date: '2026-10-18', quantity: 7 }, 3);
    await local.appendConsumption('F1', 'M1', { date: '2026-10-18', quantity: 9 }, 3); // same day -> replace
    const line = await local.getStock('F1', 'M1');
    expect(line.consumptionSeries).toEqual([
      { date: '2026-10-17', quantity: 5 },
      { date: '2026-10-18', quantity: 9 },
    ]);
    expect(await local.appendConsumption('F9', 'M9', { date: '2026-10-18', quantity: 1 })).toBeNull();
  });

  it('rebuilds consumption from dispensing records', async () => {
    const local = new InMemoryRepository();
    await local.addDispensing({
      id: 'D1',
      facilityId: 'F1',
      medicineId: 'M1',
      quantity: 4,
      recordedAt: '2026-10-17T06:00:00Z',
    });
    const series = await local.consumptionFromDispensing('F1', 'M1', 2, new Date('2026-10-18T06:00:00Z'));
    expect(series).toHaveLength(2);
    expect(series[0]).toEqual({ date: '2026-10-17', quantity: 4 });
  });

  it('decrements a batch and removes it at zero', async () => {
    const local = new InMemoryRepository();
    await local.upsertBatch({ id: 'B1', facilityId: 'F1', medicineId: 'M1', quantity: 10, expiryDate: '2027-01-01' });
    expect((await local.decrementBatch('B1', 4)).quantity).toBe(6);
    expect(await local.decrementBatch('B1', 6)).toBeNull();
    expect(await local.getBatch('B1')).toBeNull();
    expect(await local.decrementBatch('missing', 1)).toBeNull();
    await local.upsertBatch({ id: 'B2', quantity: 5 });
    expect((await local.incrementBatch('B2', 5)).quantity).toBe(10);
  });

  it('updates tokens, wards, indents, transfers, referrals and alerts', async () => {
    const local = new InMemoryRepository();
    await local.addToken({ id: 'T1', facilityId: 'F1', status: 'WAITING', issuedAt: '2026-10-18T04:00:00Z' });
    expect((await local.updateToken('T1', { status: 'SERVED' })).status).toBe('SERVED');
    expect(await local.updateToken('missing', {})).toBeNull();

    await local.upsertWard({ id: 'W1', facilityId: 'F1', total: 10, occupied: 2, reserved: 0 });
    await local.addBedEvent({ id: 'BE1', facilityId: 'F1', at: '2026-10-18T04:00:00Z', field: 'occupied', delta: 1 });
    expect(await local.listBedEvents('F1')).toHaveLength(1);

    await local.addIndent({ id: 'I1', facilityId: 'F1', requestedAt: '2026-10-18T04:00:00Z', status: 'REQUESTED' });
    expect((await local.updateIndent('I1', { status: 'APPROVED' })).status).toBe('APPROVED');
    expect((await local.listIndents({ filters: { status: 'APPROVED' } })).total).toBe(1);

    await local.addTransfer({ id: 'TR1', fromFacilityId: 'F1', toFacilityId: 'F2', requestedAt: '2026-10-18T04:00:00Z' });
    expect((await local.updateTransfer('TR1', { status: 'DISPATCHED' })).status).toBe('DISPATCHED');
    expect((await local.listTransfers()).total).toBe(1);

    await local.addReferral({ id: 'R1', fromFacilityId: 'F1', toFacilityId: 'F2', createdAt: '2026-10-18T04:00:00Z' });
    expect((await local.updateReferral('R1', { status: 'ACCEPTED' })).status).toBe('ACCEPTED');
    expect((await local.listReferrals()).total).toBe(1);

    await local.addAlert({ id: 'A1', facilityId: 'F1', createdAt: '2026-10-18T04:00:00Z' });
    expect((await local.updateAlert('A1', { acknowledged: true })).acknowledged).toBe(true);
    expect((await local.listAlerts()).total).toBe(1);
    expect((await local.listAudit()).total).toBe(0);
  });

  it('exposes repository stats and a no-op close', async () => {
    const local = new InMemoryRepository();
    await local.upsertFacility({ id: 'F1', name: 'X' });
    expect(local.stats().facilities).toBe(1);
    expect(local.kind).toBe('memory');
    expect(local.count('facilities')).toBe(1);
    await expect(local.close()).resolves.toBeUndefined();
    local.reset();
    expect(local.count('facilities')).toBe(0);
  });

  it('lists the remaining collections with filters', async () => {
    const local = new InMemoryRepository();
    await local.upsertMedicine({ id: 'M1', name: 'ORS', category: 'Rehydration' });
    await local.addFootfall({ facilityId: 'F1', department: 'OPD_GENERAL', date: '2026-10-18', hour: 10, count: 5 });
    await local.upsertCounter({ facilityId: 'F1', counterId: 1, department: 'OPD_GENERAL', isOpen: true });
    await local.upsertDoctor({ id: 'D1', facilityId: 'F1', name: 'Dr. A' });
    await local.upsertAttendance({ doctorId: 'D1', facilityId: 'F1', date: '2026-10-18', checkInAt: null });
    await local.upsertRoster({ doctorId: 'D1', facilityId: 'F1', date: '2026-10-18', shift: 'DAY' });
    await local.addLeave({ id: 'L1', doctorId: 'D1', facilityId: 'F1', date: '2026-10-20' });
    await local.addDispensing({ id: 'DSP1', facilityId: 'F1', medicineId: 'M1', quantity: 2, recordedAt: '2026-10-18T05:00:00Z' });
    await local.addAudit({ id: 'AUD1', facilityId: 'F1', entityType: 'STOCK', createdAt: '2026-10-18T05:00:00Z' });
    await local.upsertStock({ facilityId: 'F1', medicineId: 'M1', units: 3 });

    expect((await local.listMedicines()).total).toBe(1);
    expect(await local.listFootfall({ facilityId: 'F1' })).toHaveLength(1);
    expect(await local.footfallBetween('F1', '2026-10-01', '2026-10-31')).toHaveLength(1);
    expect(await local.listCounters('F1')).toHaveLength(1);
    expect((await local.listDoctors({ facilityId: 'F1' })).total).toBe(1);
    expect(await local.listAttendance('D1', '2026-10-01')).toHaveLength(1);
    expect(await local.listAttendanceByFacility({ facilityId: 'F1' })).toHaveLength(1);
    expect(await local.listRosters({ facilityId: 'F1' })).toHaveLength(1);
    expect(await local.listLeaves({ facilityId: 'F1' })).toHaveLength(1);
    expect((await local.listDispensing({ facilityId: 'F1' })).total).toBe(1);
    expect((await local.listStockByFacility({ facilityId: 'F1' }))).toHaveLength(1);
    expect((await local.listAudit({ filters: { entityType: 'STOCK' } })).total).toBe(1);
    expect((await local.listTokens({ facilityId: 'F1' })).total).toBe(0);
    expect(await local.getToken('T1')).toBeNull();
    expect(await local.getWard('W1')).toBeNull();
    expect(await local.getDoctor('D1')).not.toBeNull();
    expect(await local.getMedicine('M1')).not.toBeNull();
    expect(local.group([{ k: 'a' }, { k: 'a' }, { k: 'b' }], (item) => item.k).size).toBe(2);
  });
});

describe('prepare and normalize', () => {
  it('drops undefined and converts dates on the way in', () => {
    expect(prepare({ a: 1, b: undefined, c: new Date('2026-10-18T00:00:00Z') })).toEqual({
      a: 1,
      c: '2026-10-18T00:00:00.000Z',
    });
    expect(prepare([1, undefined, 2])).toEqual([1, 2]);
  });

  it('converts Firestore timestamps to ISO strings on the way out', () => {
    const fakeTimestamp = { toDate: () => new Date('2026-10-18T04:00:00Z') };
    expect(normalize({ at: fakeTimestamp, nested: { at: fakeTimestamp }, list: [fakeTimestamp] })).toEqual({
      at: '2026-10-18T04:00:00.000Z',
      nested: { at: '2026-10-18T04:00:00.000Z' },
      list: ['2026-10-18T04:00:00.000Z'],
    });
    expect(normalize(undefined)).toBeNull();
  });
});

describe('FirestoreRepository against a fake Firestore', () => {
  const db = createFakeFirestore();
  const repository = new FirestoreRepository({ db });

  it('writes and reads a facility through the real query builder', async () => {
    await repository.upsertFacility({ id: 'F1', name: 'PHC Rahata', type: 'PHC' });
    const facility = await repository.getFacility('F1');
    expect(facility).toMatchObject({ id: 'F1', name: 'PHC Rahata' });
    const page = await repository.listFacilities({ limit: 10, offset: 0 });
    expect(page.total).toBe(1);
    expect(await repository.requireFacility('F1')).not.toBeNull();
    await expect(repository.requireFacility('missing')).rejects.toThrow('Facility not found');
  });

  it('finds a stock line by composite id and by filter fallback', async () => {
    await repository.upsertStock({ facilityId: 'F1', medicineId: 'M1', units: 50 });
    expect((await repository.getStock('F1', 'M1')).units).toBe(50);
    expect(await repository.getStock('F1', 'NOPE')).toBeNull();
    const line = await repository.getStock('F1', 'M1');
    await repository.appendConsumption('F1', 'M1', { date: '2026-10-18', quantity: 6 });
    const updated = await repository.getStock('F1', 'M1');
    expect(updated.consumptionSeries).toEqual([{ date: '2026-10-18', quantity: 6 }]);
    expect(line.id).toBe('STK-F1-M1');
    expect(await repository.appendConsumption('F1', 'NONE', { date: '2026-10-18', quantity: 1 })).toBeNull();
  });

  it('uses an indexed range query for a footfall date window', async () => {
    await repository.addFootfall({ facilityId: 'F1', department: 'OPD_GENERAL', date: '2026-10-18', hour: 10, count: 3 });
    const rows = await repository.footfallBetween('F1', '2026-10-01', '2026-10-31');
    expect(rows).toHaveLength(1);
    const lastCall = db.calls.at(-1);
    expect(lastCall.ranges.map((range) => range.op)).toEqual(['>=', '<=']);
  });

  it('rebuilds consumption from dispensing with a range filter', async () => {
    await repository.addDispensing({ id: 'D1', facilityId: 'F1', medicineId: 'M1', quantity: 4, recordedAt: '2026-10-17T06:00:00Z' });
    const series = await repository.consumptionFromDispensing('F1', 'M1', 2, new Date('2026-10-18T06:00:00Z'));
    expect(series[0]).toEqual({ date: '2026-10-17', quantity: 4 });
  });

  it('decrements and deletes batches, and updates documents', async () => {
    await repository.upsertBatch({ id: 'B1', facilityId: 'F1', medicineId: 'M1', quantity: 10, expiryDate: '2027-01-01' });
    expect((await repository.decrementBatch('B1', 10))).toBeNull();
    expect(await repository.getBatch('B1')).toBeNull();
    await repository.upsertBatch({ id: 'B2', quantity: 5 });
    expect((await repository.incrementBatch('B2', 3)).quantity).toBe(8);
    expect(await repository.decrementBatch('missing', 1)).toBeNull();
    expect(await repository.incrementBatch('missing', 1)).toBeNull();

    await repository.addToken({ id: 'T1', facilityId: 'F1', status: 'WAITING' });
    expect((await repository.updateToken('T1', { status: 'SERVED' })).status).toBe('SERVED');
    expect(await repository.updateToken('missing', {})).toBeNull();
  });

  it('supports the ward, doctor, workflow and audit surfaces', async () => {
    await repository.upsertWard({ id: 'W1', facilityId: 'F1', name: 'General', total: 10, occupied: 1, reserved: 0 });
    await repository.addBedEvent({ id: 'BE1', facilityId: 'F1', at: '2026-10-18T04:00:00Z' });
    expect(await repository.listWards('F1')).toHaveLength(1);
    expect(await repository.listBedEvents('F1')).toHaveLength(1);

    await repository.upsertDoctor({ id: 'D1', facilityId: 'F1', name: 'Dr. A' });
    await repository.upsertAttendance({ doctorId: 'D1', facilityId: 'F1', date: '2026-10-18', checkInAt: null });
    await repository.upsertRoster({ doctorId: 'D1', facilityId: 'F1', date: '2026-10-18', shift: 'DAY' });
    await repository.addLeave({ id: 'L1', doctorId: 'D1', facilityId: 'F1', date: '2026-10-20' });
    expect(await repository.listDoctors({ facilityId: 'F1' })).toMatchObject({ total: 1 });
    expect(await repository.listAttendance('D1', '2026-10-01')).toHaveLength(1);
    expect(await repository.listAttendanceByFacility({ facilityId: 'F1' })).toHaveLength(1);
    expect(await repository.listRosters({ facilityId: 'F1' })).toHaveLength(1);
    expect(await repository.listLeaves({ facilityId: 'F1' })).toHaveLength(1);
    expect(await repository.getDoctor('D1')).not.toBeNull();

    await repository.addReferral({ id: 'R1', createdAt: '2026-10-18T04:00:00Z' });
    expect((await repository.updateReferral('R1', { status: 'ACCEPTED' })).status).toBe('ACCEPTED');
    expect(await repository.getReferral('R1')).not.toBeNull();
    expect(await repository.listReferrals()).toMatchObject({ total: 1 });
    expect(await repository.updateReferral('missing', {})).toBeNull();

    await repository.addIndent({ id: 'I1', requestedAt: '2026-10-18T04:00:00Z' });
    expect((await repository.updateIndent('I1', { status: 'APPROVED' })).status).toBe('APPROVED');
    expect(await repository.listIndents()).toMatchObject({ total: 1 });
    expect(await repository.getIndent('I1')).not.toBeNull();
    expect(await repository.updateIndent('missing', {})).toBeNull();

    await repository.addTransfer({ id: 'TR1', requestedAt: '2026-10-18T04:00:00Z' });
    expect((await repository.updateTransfer('TR1', { status: 'DISPATCHED' })).status).toBe('DISPATCHED');
    expect(await repository.listTransfers()).toMatchObject({ total: 1 });
    expect(await repository.getTransfer('TR1')).not.toBeNull();
    expect(await repository.updateTransfer('missing', {})).toBeNull();

    await repository.addAlert({ id: 'AL1', createdAt: '2026-10-18T04:00:00Z' });
    expect((await repository.updateAlert('AL1', { acknowledged: true })).acknowledged).toBe(true);
    expect(await repository.listAlerts()).toMatchObject({ total: 1 });
    expect(await repository.updateAlert('missing', {})).toBeNull();

    await repository.addAudit({ id: 'AUD1', facilityId: 'F1', entityType: 'STOCK', createdAt: '2026-10-18T04:00:00Z' });
    expect(await repository.listAudit({ filters: { entityType: 'STOCK' } })).toMatchObject({ total: 1 });

    await repository.upsertCounter({ facilityId: 'F1', counterId: 1, department: 'OPD_GENERAL', isOpen: true });
    expect(await repository.listCounters('F1')).toHaveLength(1);
    expect(await repository.listDispensing({ facilityId: 'F1' })).toMatchObject({ total: 1 });
    expect(await repository.listFootfall({ facilityId: 'F1' })).toHaveLength(1);
    expect(await repository.listStockByFacility({ facilityId: 'F1' })).toHaveLength(1);
    expect(await repository.listBatches({ facilityId: 'F1' })).toHaveLength(0);
    expect((await repository.listMedicines()).total).toBe(0);
    expect(await repository.getMedicine('M1')).toBeNull();
  });

  it('bulk writes in chunks below the Firestore batch limit', async () => {
    const documents = Array.from({ length: 900 }, (_unused, index) => ({ id: `bulk-${index}`, value: index }));
    expect(await repository.bulkWrite('bulk', documents)).toBe(900);
    expect(db.store.get('bulk').size).toBe(900);
  });

  it('reports its kind', () => {
    expect(repository.kind).toBe('firestore');
    expect(new FirestoreRepository().kind).toBe('firestore');
  });
});

describe('repository selection', () => {
  it('defaults to the zero-configuration in-memory store', async () => {
    await resetRepository();
    const repository = await getRepository();
    expect(repository.kind).toBe('memory');
    expect(await getRepository()).toBe(repository);
  });

  it('can be forced to Firestore and injected with a fake db', async () => {
    const repository = await createRepository({ kind: 'firestore', db: createFakeFirestore() });
    expect(repository.kind).toBe('firestore');
    await repository.upsertFacility({ id: 'F1', name: 'X' });
    expect(await repository.getFacility('F1')).not.toBeNull();
  });

  it('allows a test to replace and reset the singleton', async () => {
    const replacement = new InMemoryRepository();
    setRepository(replacement);
    expect(await getRepository()).toBe(replacement);
    await resetRepository();
    expect(await getRepository()).not.toBe(replacement);
  });
});

describe('loading the seeded dataset into a repository', () => {
  it('writes every collection', async () => {
    const repository = new InMemoryRepository();
    const dataset = generateDataset({ days: 20, generatedAt: '2026-10-18T05:00:00Z' });
    const written = await loadDataset(repository, dataset);

    expect(written.facilities).toBe(11);
    expect(written.medicines).toBe(25);
    expect(written.stock).toBe(250); // 10 service facilities x 25 medicines
    expect(written.footfall).toBeGreaterThan(1000);
    expect(repository.count('wards')).toBeGreaterThan(0);
  });
});
