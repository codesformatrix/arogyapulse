import { describe, expect, it } from '@jest/globals';

import {
  attendanceRisk,
  isLate,
  ratingFor,
  reliabilityPercent,
  summarizeAttendance,
} from '../../src/services/attendance.js';

const log = (overrides = {}) => ({
  doctorId: 'DOC-1',
  date: '2026-10-10',
  checkInAt: null,
  onLeave: false,
  ...overrides,
});

describe('reliabilityPercent', () => {
  it('counts present days over duty days', () => {
    const logs = [
      log({ checkInAt: '2026-10-10T04:00:00Z' }),
      log({ checkInAt: '2026-10-11T04:00:00Z' }),
      log({ checkInAt: '2026-10-12T04:00:00Z' }),
      log({ checkInAt: null }),
    ];
    const result = reliabilityPercent(logs);
    expect(result.reliabilityPercent).toBe(75);
    expect(result.dutyDays).toBe(4);
    expect(result.absentDays).toBe(1);
    expect(result.rating).toBe('AT_RISK');
  });

  it('excludes approved leave from the denominator', () => {
    const logs = [
      log({ checkInAt: '2026-10-10T04:00:00Z' }),
      log({ checkInAt: null, onLeave: true }),
    ];
    const result = reliabilityPercent(logs);
    expect(result.leaveDays).toBe(1);
    expect(result.dutyDays).toBe(1);
    expect(result.reliabilityPercent).toBe(100);
  });

  it('counts late arrivals separately from presence', () => {
    const logs = [
      log({ checkInAt: '2026-10-10T05:20:00Z' }), // 10:50 IST -> late
      log({ checkInAt: '2026-10-11T03:45:00Z' }), // 09:15 IST -> on time
    ];
    const result = reliabilityPercent(logs);
    expect(result.lateDays).toBe(1);
    expect(result.onTimePercent).toBe(50);
  });

  it('treats an empty history as fully reliable', () => {
    expect(reliabilityPercent([]).reliabilityPercent).toBe(100);
  });
});

describe('ratingFor', () => {
  it('bands the reliability percentage', () => {
    expect(ratingFor(97)).toBe('RELIABLE');
    expect(ratingFor(85)).toBe('WATCH');
    expect(ratingFor(60)).toBe('AT_RISK');
  });
});

describe('isLate', () => {
  it('compares the check-in wall clock (IST) against the alert time', () => {
    expect(isLate(log({ checkInAt: '2026-10-10T05:20:00Z' }))).toBe(true); // 10:50 IST
    expect(isLate(log({ checkInAt: '2026-10-10T03:40:00Z' }))).toBe(false); // 09:10 IST
  });

  it('is never late when there is no check-in', () => {
    expect(isLate(log())).toBe(false);
  });

  it('accepts injected clock functions', () => {
    const late = isLate(log({ checkInAt: 'x' }), {
      alertTime: '09:30',
      hhmmToMinutes: () => 570,
      minutesSinceMidnight: () => 620,
    });
    expect(late).toBe(true);
  });
});

describe('attendanceRisk', () => {
  const nowMinutes = 10 * 60 + 30; // 10:30 IST

  it('reports PRESENT for an on-time check-in', () => {
    const risk = attendanceRisk({
      doctorId: 'DOC-1',
      onRosterToday: true,
      checkInAt: '2026-10-18T03:45:00Z', // 09:15 IST
      nowMinutes,
    });
    expect(risk).toMatchObject({ status: 'PRESENT', alert: false });
  });

  it('reports LATE with the minutes overdue', () => {
    const risk = attendanceRisk({
      doctorId: 'DOC-1',
      onRosterToday: true,
      checkInAt: '2026-10-18T05:15:00Z', // 10:45 IST
      nowMinutes: 11 * 60,
    });
    expect(risk.status).toBe('LATE');
    expect(risk.minutesLate).toBe(75);
  });

  it('fires the no-show alert only after the configured time', () => {
    const before = attendanceRisk({ doctorId: 'DOC-1', onRosterToday: true, nowMinutes: 8 * 60 });
    const after = attendanceRisk({ doctorId: 'DOC-1', onRosterToday: true, nowMinutes });
    expect(before).toMatchObject({ status: 'NO_CHECK_IN', alert: false });
    expect(after).toMatchObject({ status: 'NO_CHECK_IN', alert: true });
  });

  it('never alerts for approved leave or a non-rostered day', () => {
    expect(attendanceRisk({ doctorId: 'DOC-1', onRosterToday: true, onLeave: true, nowMinutes })).toMatchObject({
      status: 'ON_LEAVE',
      alert: false,
    });
    expect(attendanceRisk({ doctorId: 'DOC-1', onRosterToday: false, nowMinutes })).toMatchObject({
      status: 'NOT_ROSTERED',
      alert: false,
    });
  });
});

describe('summarizeAttendance', () => {
  it('answers "is a doctor present today?" for the public page', () => {
    const summary = summarizeAttendance([
      { status: 'PRESENT', alert: false },
      { status: 'NO_CHECK_IN', alert: true },
      { status: 'ON_LEAVE', alert: false },
    ]);
    expect(summary).toMatchObject({ anyPresent: true, presentCount: 1, absentCount: 1 });
    expect(summary.alerts).toHaveLength(1);
  });

  it('reports nobody present when the OPD is unstaffed', () => {
    expect(summarizeAttendance([{ status: 'NO_CHECK_IN', alert: true }]).anyPresent).toBe(false);
    expect(summarizeAttendance([])).toMatchObject({ anyPresent: false, presentCount: 0 });
  });
});
