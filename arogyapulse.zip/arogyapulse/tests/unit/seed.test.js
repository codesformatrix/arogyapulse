import { describe, expect, it } from '@jest/globals';

import { generateDataset } from '../../src/seed/generator.js';
import { FACILITIES } from '../../src/seed/facilities.js';
import { CRITICAL_MEDICINE_IDS, MEDICINES } from '../../src/seed/medicines.js';
import { forecastLine } from '../../src/services/forecast.js';
import { parseArgs, seed } from '../../scripts/seed.mjs';
import { InMemoryRepository } from '../../src/repositories/inMemoryRepository.js';

const OPTIONS = { days: 30, generatedAt: '2026-10-18T05:00:00Z', seedKey: 'arogyapulse-demo' };

describe('parseArgs', () => {
  it('reads every supported flag', () => {
    const options = parseArgs(['--memory', '--days', '21', '--key', 'custom', '--at', '2026-10-18T05:00:00Z', '--print']);
    expect(options).toMatchObject({ kind: 'memory', days: 21, seedKey: 'custom', print: true });
    expect(options.generatedAt?.toISOString()).toBe('2026-10-18T05:00:00.000Z');
  });

  it('defaults to 45 days and the demo key', () => {
    expect(parseArgs([])).toMatchObject({ days: 45, seedKey: 'arogyapulse-demo', print: false, kind: undefined });
    expect(parseArgs(['--help']).help).toBe(true);
  });
});

describe('generateDataset', () => {
  const dataset = generateDataset(OPTIONS);

  it('is deterministic for the same key and instant', () => {
    const again = generateDataset(OPTIONS);
    expect(JSON.stringify(again.stock)).toBe(JSON.stringify(dataset.stock));
    expect(JSON.stringify(again.footfall)).toBe(JSON.stringify(dataset.footfall));
  });

  it('changes when the seed key changes', () => {
    const other = generateDataset({ ...OPTIONS, seedKey: 'different' });
    expect(JSON.stringify(other.stock)).not.toBe(JSON.stringify(dataset.stock));
  });

  it('models one district with 2 CHCs, 8 PHCs and the district drug store', () => {
    expect(dataset.facilities).toHaveLength(11);
    expect(dataset.facilities.filter((facility) => facility.type === 'CHC')).toHaveLength(2);
    expect(dataset.facilities.filter((facility) => facility.type === 'PHC')).toHaveLength(8);
    expect(dataset.facilities.filter((facility) => facility.type === 'DISTRICT_STORE')).toHaveLength(1);
    expect(FACILITIES).toHaveLength(11);
  });

  it('seeds 25 essential medicines including the emergency commodities', () => {
    expect(dataset.medicines).toHaveLength(25);
    const names = dataset.medicines.map((medicine) => medicine.name).join('|');
    for (const expected of [
      'Paracetamol',
      'Oral Rehydration Salts (ORS)',
      'Zinc Sulphate (Dispersible)',
      'Amoxicillin',
      'Azithromycin',
      'Metformin',
      'Amlodipine',
      'Iron and Folic Acid',
      'Oxytocin Injection',
      'Tetanus Toxoid (TT)',
      'Anti-Snake Venom Serum',
      'Anti-Rabies Vaccine',
      'Salbutamol Inhaler',
    ]) {
      expect(names).toContain(expected);
    }
    expect(MEDICINES).toHaveLength(25);
    expect(CRITICAL_MEDICINE_IDS.length).toBeGreaterThan(10);
  });

  it('carries a Hindi label for every medicine and facility', () => {
    expect(dataset.medicines.every((medicine) => /\p{Script=Devanagari}/u.test(medicine.nameHi))).toBe(true);
    expect(dataset.facilities.every((facility) => /\p{Script=Devanagari}/u.test(facility.nameHi))).toBe(true);
  });

  it('gives every facility a Google Maps link and coordinates', () => {
    for (const facility of dataset.facilities) {
      expect(facility.mapsUrl).toContain('https://www.google.com/maps/search/?api=1&query=');
      expect(Number.isFinite(facility.latitude)).toBe(true);
      expect(Number.isFinite(facility.longitude)).toBe(true);
    }
  });

  it('produces a stock line for every facility x medicine pair', () => {
    expect(dataset.stock).toHaveLength(10 * 25);
    for (const line of dataset.stock) {
      expect(line.consumptionSeries).toHaveLength(30);
      expect(line.units).toBeGreaterThanOrEqual(0);
    }
  });

  it('creates every forecast status so the demo needs no manual data', () => {
    const statuses = new Set();
    for (const line of dataset.stock) {
      const forecast = forecastLine({
        stock: line.units,
        reorderLevel: line.reorderLevel,
        consumptionSeries: line.consumptionSeries,
        batches: dataset.batches.filter(
          (batch) => batch.facilityId === line.facilityId && batch.medicineId === line.medicineId,
        ),
        todayKey: '2026-10-18',
      });
      statuses.add(forecast.status);
    }
    expect(statuses.has('RED')).toBe(true);
    expect(statuses.has('AMBER')).toBe(true);
    expect(statuses.has('GREEN')).toBe(true);
    expect(statuses.has('EXPIRY_RISK')).toBe(true);
  });

  it('generates 14+ days of hourly footfall with weekday variation', () => {
    const dates = new Set(dataset.footfall.map((row) => row.date));
    expect(dates.size).toBeGreaterThanOrEqual(14);
    const monday = dataset.footfall.filter((row) => row.weekday === 1);
    const sunday = dataset.footfall.filter((row) => row.weekday === 0);
    expect(monday.reduce((total, row) => total + row.count, 0)).toBeGreaterThan(
      sunday.reduce((total, row) => total + row.count, 0),
    );
  });

  it('issues only anonymous tokens - no PII anywhere in the dataset', () => {
    const serialized = JSON.stringify(dataset);
    expect(serialized).not.toMatch(/\b\d{12}\b/); // no Aadhaar-shaped numbers
    expect(serialized.toLowerCase()).not.toContain('aadhaar');
    expect(serialized.toLowerCase()).not.toContain('patientName');
    for (const token of dataset.tokens) {
      expect(token.token).toMatch(/^[A-Z]-[0-9]{2,3}$/);
    }
    const served = dataset.tokens.filter((token) => token.status === 'SERVED');
    expect(served.length).toBeGreaterThan(0);
    expect(served.every((token) => token.waitMinutes > 0)).toBe(true);
  });

  it('seeds wards, doctors, rosters and 30 days of attendance', () => {
    expect(dataset.wards.length).toBeGreaterThan(10);
    expect(dataset.doctors.length).toBeGreaterThan(10);
    expect(dataset.rosters.length).toBeGreaterThan(100);
    expect(dataset.attendance.length).toBeGreaterThan(100);
    for (const ward of dataset.wards) {
      expect(ward.occupied + ward.reserved).toBeLessThanOrEqual(ward.total);
    }
    expect(dataset.attendance.some((log) => log.late === true)).toBe(true);
    expect(dataset.attendance.some((log) => log.onLeave === true)).toBe(true);
    expect(dataset.leaves.length).toBeGreaterThan(0);
  });

  it('seeds the supply-chain workflow and an audit trail', () => {
    expect(dataset.indents.length).toBeGreaterThan(0);
    expect(dataset.transfers).toHaveLength(1);
    expect(dataset.referrals).toHaveLength(1);
    expect(dataset.audit.length).toBeGreaterThan(100);
    expect(dataset.audit.every((entry) => Boolean(entry.id) && Boolean(entry.createdAt))).toBe(true);
    expect(dataset.meta.note).toContain('no patient PII');
  });

  it('enforces a 14 day minimum history', () => {
    expect(generateDataset({ days: 3, generatedAt: '2026-10-18T05:00:00Z' }).meta.historyDays).toBe(14);
  });
});

describe('seed()', () => {
  it('loads a dataset into an injected repository', async () => {
    const repository = new InMemoryRepository();
    const result = await seed({ repository, days: 16, generatedAt: new Date('2026-10-18T05:00:00Z') });
    expect(result.written.facilities).toBe(11);
    expect(repository.count('tokens')).toBeGreaterThan(0);
    expect(result.dataset.meta.facilityCount).toBe(11);
  });
});
