import { describe, expect, it } from '@jest/globals';

import { WORKFLOW_TRANSITIONS } from '../../src/config/constants.js';
import {
  buildIndent,
  canTransition,
  indentItem,
  indentPriority,
  needsIndent,
} from '../../src/services/indent.js';

describe('needsIndent', () => {
  it('triggers below the threshold days of cover', () => {
    expect(needsIndent({ stock: 50, daysOfCover: 6 })).toBe(true);
    expect(needsIndent({ stock: 500, daysOfCover: 30 })).toBe(false);
  });

  it('triggers on an empty shelf even without a consumption rate', () => {
    expect(needsIndent({ stock: 0, daysOfCover: null })).toBe(true);
  });

  it('does not trigger when nothing is being consumed', () => {
    expect(needsIndent({ stock: 100, daysOfCover: null })).toBe(false);
  });

  it('triggers on a RED status line', () => {
    expect(needsIndent({ stock: 10, daysOfCover: null, status: 'RED' })).toBe(true);
  });
});

describe('indentPriority', () => {
  it('bands the urgency', () => {
    expect(indentPriority({ stock: 0, daysOfCover: 0 })).toBe('CRITICAL');
    expect(indentPriority({ stock: 20, daysOfCover: 2 })).toBe('CRITICAL');
    expect(indentPriority({ stock: 50, daysOfCover: 5 })).toBe('HIGH');
    expect(indentPriority({ stock: 500, daysOfCover: 20 })).toBe('MEDIUM');
  });
});

describe('indentItem', () => {
  it('normalises and rounds the requested quantity up to whole units', () => {
    const item = indentItem({
      medicineId: 'MED-ORS',
      medicineName: 'Oral Rehydration Salts (ORS)',
      stock: 40,
      perDay: 12.345,
      daysOfCover: 3.2,
      units: 199.2,
    });
    expect(item).toMatchObject({ units: 200, currentStock: 40, forecastPerDay: 12.35, priority: 'HIGH' });
  });
});

describe('buildIndent', () => {
  const lines = [
    { medicineId: 'MED-ORS', medicineName: 'ORS', stock: 10, perDay: 10, daysOfCover: 1, suggestedReorderUnits: 200 },
    { medicineId: 'MED-PARA-500', medicineName: 'Paracetamol', stock: 900, perDay: 30, daysOfCover: 30, suggestedReorderUnits: 0 },
    { medicineId: 'MED-ZINC-20', medicineName: 'Zinc', stock: 30, perDay: 8, daysOfCover: 3.7, suggestedReorderUnits: 140 },
  ];

  it('includes only the lines below the threshold, worst first', () => {
    const { needed, items, document } = buildIndent(
      { facilityId: 'FAC-PHC-RAHATA', facilityName: 'PHC Rahata', lines },
      { todayKey: '2026-10-18' },
    );

    expect(needed).toBe(true);
    expect(items.map((item) => item.medicineId)).toEqual(['MED-ORS', 'MED-ZINC-20']);
    expect(document.status).toBe('REQUESTED');
    expect(document.totalItems).toBe(2);
    expect(document.totalUnits).toBe(340);
    expect(document.history[0]).toMatchObject({ status: 'REQUESTED', by: 'system:auto-indent' });
  });

  it('returns needed=false when every line is healthy', () => {
    const result = buildIndent(
      { facilityId: 'F', facilityName: 'F', lines: [lines[1]] },
      { todayKey: '2026-10-18' },
    );
    expect(result).toMatchObject({ needed: false, document: null });
  });

  it('includes every line with units when raised manually', () => {
    const result = buildIndent(
      { facilityId: 'F', facilityName: 'F', lines: [{ ...lines[1], requestedUnits: 100 }] },
      { todayKey: '2026-10-18', source: 'MANUAL' },
    );
    expect(result.needed).toBe(true);
    expect(result.document.source).toBe('MANUAL');
  });
});

describe('canTransition', () => {
  it('allows the documented indent workflow steps', () => {
    expect(canTransition('indent', 'REQUESTED', 'APPROVED', WORKFLOW_TRANSITIONS).allowed).toBe(true);
    expect(canTransition('indent', 'APPROVED', 'DISPATCHED', WORKFLOW_TRANSITIONS).allowed).toBe(true);
    expect(canTransition('indent', 'DISPATCHED', 'RECEIVED', WORKFLOW_TRANSITIONS).allowed).toBe(true);
  });

  it('blocks impossible jumps and terminal states', () => {
    expect(canTransition('indent', 'REQUESTED', 'RECEIVED', WORKFLOW_TRANSITIONS).allowed).toBe(false);
    expect(canTransition('indent', 'RECEIVED', 'APPROVED', WORKFLOW_TRANSITIONS).allowed).toBe(false);
    expect(canTransition('indent', 'RECEIVED', 'APPROVED', WORKFLOW_TRANSITIONS).allowedNext).toEqual([]);
  });

  it('handles an unknown state safely', () => {
    expect(canTransition('indent', 'TELEPORTED', 'APPROVED', WORKFLOW_TRANSITIONS)).toEqual({
      allowed: false,
      allowedNext: [],
    });
  });
});
