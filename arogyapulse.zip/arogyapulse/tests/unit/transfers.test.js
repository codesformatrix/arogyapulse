import { describe, expect, it } from '@jest/globals';

import {
  donorSpareUnits,
  recipientNeedUnits,
  suggestExpiryRedistribution,
  suggestTransfers,
} from '../../src/services/transfers.js';
import { haversineKm, mapsUrl } from '../../src/services/geo.js';

const PUNE = { latitude: 18.5204, longitude: 73.8567 };
const NASHIK = { latitude: 19.9975, longitude: 73.7898 }; // ~165 km from Pune

describe('haversineKm', () => {
  it('measures the Pune-Nashik road-bird distance within a few km', () => {
    expect(haversineKm(PUNE, NASHIK)).toBeGreaterThan(155);
    expect(haversineKm(PUNE, NASHIK)).toBeLessThan(175);
  });

  it('returns 0 for the same point and Infinity when a geocode is missing', () => {
    expect(haversineKm(PUNE, PUNE)).toBe(0);
    expect(haversineKm(PUNE, undefined)).toBe(Number.POSITIVE_INFINITY);
  });
});

describe('mapsUrl', () => {
  it('builds a coordinates link', () => {
    expect(mapsUrl({ latitude: 19.0947, longitude: 74.7484 })).toBe(
      'https://www.google.com/maps/search/?api=1&query=19.0947%2C74.7484',
    );
  });

  it('falls back to a text query without coordinates', () => {
    expect(mapsUrl({ name: 'PHC Rahata' })).toContain('PHC%20Rahata');
  });
});

describe('donorSpareUnits / recipientNeedUnits', () => {
  it('keeps the donor above its own safety cover', () => {
    // 1000 units, 10/day, keep 21 days = 210, capped at 40% of stock = 400.
    expect(donorSpareUnits({ stock: 1000, perDay: 10 })).toBe(400);
  });

  it('never lets a donor go below its minimum cover', () => {
    // 100 units, 4/day -> keep 84, cap 40 -> spare 16.
    expect(donorSpareUnits({ stock: 100, perDay: 4 })).toBe(16);
  });

  it('computes the recipient gap to the target cover', () => {
    expect(recipientNeedUnits({ stock: 10, perDay: 10 })).toBe(60);
    expect(recipientNeedUnits({ stock: 500, perDay: 10 })).toBe(0);
  });
});

describe('suggestTransfers', () => {
  const basePolicy = { minUnits: 20 };

  it('moves surplus to the nearest deficit facility', () => {
    const suggestions = suggestTransfers(
      [
        { facilityId: 'A', medicineId: 'M1', stock: 1000, perDay: 10, daysOfCover: 100, coordinates: PUNE },
        { facilityId: 'B', medicineId: 'M1', stock: 10, perDay: 10, daysOfCover: 1, coordinates: { latitude: 18.6, longitude: 73.9 } },
      ],
      basePolicy,
    );

    expect(suggestions).toHaveLength(1);
    expect(suggestions[0]).toMatchObject({
      medicineId: 'M1',
      fromFacilityId: 'A',
      toFacilityId: 'B',
      units: 60,
      reason: 'SURPLUS_TO_DEFICIT',
    });
    expect(suggestions[0].distanceKm).toBeGreaterThan(0);
    expect(suggestions[0].recipientDaysOfCoverAfter).toBe(7);
  });

  it('refuses to ship further than the configured distance', () => {
    const suggestions = suggestTransfers(
      [
        { facilityId: 'A', medicineId: 'M1', stock: 1000, perDay: 10, daysOfCover: 100, coordinates: PUNE },
        { facilityId: 'B', medicineId: 'M1', stock: 10, perDay: 10, daysOfCover: 1, coordinates: NASHIK },
      ],
      { ...basePolicy, maxDistanceKm: 120 },
    );
    expect(suggestions).toHaveLength(0);
  });

  it('does not drain a donor below its own safety cover', () => {
    const suggestions = suggestTransfers(
      [
        { facilityId: 'A', medicineId: 'M1', stock: 100, perDay: 4, daysOfCover: 25, coordinates: PUNE },
        { facilityId: 'B', medicineId: 'M1', stock: 0, perDay: 5, daysOfCover: 0, coordinates: { latitude: 18.55, longitude: 73.88 } },
      ],
      basePolicy,
    );
    expect(suggestions).toHaveLength(0); // spare 16 < minUnits 20
  });

  it('ignores medicines nobody is short of', () => {
    const suggestions = suggestTransfers(
      [
        { facilityId: 'A', medicineId: 'M1', stock: 1000, perDay: 10, daysOfCover: 100, coordinates: PUNE },
        { facilityId: 'B', medicineId: 'M1', stock: 800, perDay: 10, daysOfCover: 80, coordinates: NASHIK },
      ],
      basePolicy,
    );
    expect(suggestions).toHaveLength(0);
  });

  it('tolerates missing geocodes without throwing', () => {
    expect(() =>
      suggestTransfers([
        { facilityId: 'A', medicineId: 'M1', stock: 1000, perDay: 10, daysOfCover: 100 },
        { facilityId: 'B', medicineId: 'M1', stock: 10, perDay: 10, daysOfCover: 1 },
      ]),
    ).not.toThrow();
  });
});

describe('suggestExpiryRedistribution', () => {
  it('moves a batch the holder cannot consume before it expires', () => {
    const suggestions = suggestExpiryRedistribution(
      [
        {
          facilityId: 'A',
          medicineId: 'M1',
          stock: 500,
          perDay: 1,
          daysOfCover: 500,
          coordinates: PUNE,
          batches: [{ id: 'b1', batchNo: 'B900', quantity: 100, expiryDate: '2026-11-17' }],
        },
        {
          facilityId: 'B',
          medicineId: 'M1',
          stock: 20,
          perDay: 8,
          daysOfCover: 2.5,
          coordinates: { latitude: 18.55, longitude: 73.88 },
        },
      ],
      { todayKey: '2026-10-18' },
    );

    expect(suggestions).toHaveLength(1);
    expect(suggestions[0]).toMatchObject({ reason: 'EXPIRY_RISK', units: 100, fromFacilityId: 'A', toFacilityId: 'B' });
    expect(suggestions[0].rationale).toContain('B900');
  });

  it('leaves stock alone when the holder can consume it in time', () => {
    const suggestions = suggestExpiryRedistribution(
      [
        {
          facilityId: 'A',
          medicineId: 'M1',
          stock: 500,
          perDay: 50,
          daysOfCover: 10,
          coordinates: PUNE,
          batches: [{ id: 'b1', quantity: 100, expiryDate: '2026-11-17' }],
        },
        { facilityId: 'B', medicineId: 'M1', stock: 20, perDay: 8, daysOfCover: 2.5, coordinates: PUNE },
      ],
      { todayKey: '2026-10-18' },
    );
    expect(suggestions).toHaveLength(0);
  });
});
