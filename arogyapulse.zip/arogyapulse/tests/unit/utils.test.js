import { describe, expect, it } from '@jest/globals';

import { cacheKey, TtlCache } from '../../src/utils/cache.js';
import { etagFor, isFresh } from '../../src/utils/etag.js';
import { AppError, BusinessRuleError, ConflictError, ForbiddenError, NotFoundError, toAppError, UnauthorizedError, UpstreamError, ValidationError } from '../../src/utils/errors.js';
import { anonymousToken, newId, randomCode, uuid } from '../../src/utils/ids.js';
import { createLogger } from '../../src/utils/logger.js';
import { clamp, clone, createRandom, groupBy, hashString, mean, mulberry32, round, slugify, sortBy, sum } from '../../src/utils/random.js';
import { addDays, addMinutes, dayKey, daysBetweenKeys, diffMinutes, formatDay, formatDateTime, fromPartsInTz, hhmmToMinutes, lastNDayKeys, minutesSinceMidnight, partsInTz, startOfDay, timeOfDay, toDate } from '../../src/utils/time.js';

describe('time helpers', () => {
  it('buckets instants into IST calendar days', () => {
    // 2026-10-17T20:00:00Z is 2026-10-18 01:30 in Asia/Kolkata.
    expect(dayKey('2026-10-17T20:00:00Z')).toBe('2026-10-18');
    expect(dayKey('2026-10-17T18:00:00Z')).toBe('2026-10-17');
    expect(partsInTz('2026-10-17T20:00:00Z')).toMatchObject({ hour: 1, minute: 30, weekday: 0 });
  });

  it('parses every accepted instant representation', () => {
    expect(toDate('2026-10-18T00:00:00Z')?.getUTCFullYear()).toBe(2026);
    expect(toDate(1_792_000_000_000)).toBeInstanceOf(Date);
    expect(toDate('nonsense')).toBeNull();
    expect(toDate(null)).toBeNull();
    expect(toDate(new Date('invalid'))).toBeNull();
  });

  it('adds days and minutes', () => {
    expect(dayKey(addDays('2026-10-18T05:00:00Z', -3))).toBe('2026-10-15');
    // timeOfDay reports the IST wall clock: 00:00Z + 90 min = 07:00 IST.
    expect(timeOfDay(addMinutes('2026-10-18T00:00:00Z', 90))).toBe('07:00');
  });

  it('resolves midnight in the configured timezone', () => {
    const midnight = startOfDay('2026-10-18T12:00:00Z');
    expect(midnight.toISOString()).toBe('2026-10-17T18:30:00.000Z'); // 00:00 IST
    expect(fromPartsInTz(2026, 10, 18, 0, 0).toISOString()).toBe('2026-10-17T18:30:00.000Z');
  });

  it('produces contiguous day keys, oldest first', () => {
    expect(lastNDayKeys(3, '2026-10-18T05:00:00Z')).toEqual(['2026-10-16', '2026-10-17', '2026-10-18']);
    expect(lastNDayKeys(0, '2026-10-18T05:00:00Z')).toEqual(['2026-10-18']);
  });

  it('converts and diffs clock times', () => {
    expect(hhmmToMinutes('09:30')).toBe(570);
    expect(hhmmToMinutes('bad')).toBe(0);
    expect(minutesSinceMidnight('2026-10-18T04:00:00Z')).toBe(570); // 09:30 IST
    expect(diffMinutes('2026-10-18T04:00:00Z', '2026-10-18T04:30:00Z')).toBe(30);
    expect(diffMinutes('bad', '2026-10-18T04:30:00Z')).toBe(0);
    expect(daysBetweenKeys('2026-10-18', '2026-10-28')).toBe(10);
    expect(daysBetweenKeys('bad', '2026-10-28')).toBe(0);
  });

  it('formats dates for humans', () => {
    expect(formatDay('2026-10-18T05:00:00Z')).toBe('18 Oct 2026');
    expect(formatDateTime('2026-10-18T05:00:00Z')).toBe('18 Oct, 10:30');
    expect(formatDay('bad')).toBe('');
    expect(formatDateTime('bad')).toBe('');
  });
});

describe('random helpers', () => {
  it('hashes deterministically', () => {
    expect(hashString('abc')).toBe(hashString('abc'));
    expect(hashString('abc')).not.toBe(hashString('abd'));
  });

  it('generates a reproducible sequence from a seed', () => {
    const a = mulberry32('seed');
    const b = mulberry32('seed');
    expect(a()).toBe(b());
    const random = createRandom('seed');
    expect(random.int(1, 6)).toBeGreaterThanOrEqual(1);
    expect(random.int(1, 6)).toBeLessThanOrEqual(6);
    expect([1, 2, 3]).toContain(random.pick([1, 2, 3]));
    expect(typeof random.chance(0.5)).toBe('boolean');
    expect(Number.isFinite(random.gaussian(10, 2))).toBe(true);
  });

  it('clamps, rounds and sums safely', () => {
    expect(clamp(15, 0, 10)).toBe(10);
    expect(round(1.005, 2)).toBe(1.01);
    expect(round(Number.POSITIVE_INFINITY)).toBe(0);
    expect(round(-0.0001, 2)).toBe(0);
    expect(sum([1, 2, 'x'])).toBe(3);
    expect(mean([])).toBe(0);
    expect(mean([2, 4])).toBe(3);
  });

  it('slugifies, clones, groups and sorts without mutating', () => {
    expect(slugify('PHC Rahata!')).toBe('PHC-RAHATA');
    const source = { a: [1, 2] };
    const copy = clone(source);
    copy.a.push(3);
    expect(source.a).toHaveLength(2);
    expect(clone(undefined)).toBeUndefined();
    expect(groupBy([{ k: 'a' }, { k: 'b' }], (item) => item.k).get('a')).toHaveLength(1);
    const input = [3, 1, 2];
    expect(sortBy(input, (a, b) => a - b)).toEqual([1, 2, 3]);
    expect(input).toEqual([3, 1, 2]);
  });
});

describe('TtlCache', () => {
  it('stores, expires and invalidates', async () => {
    let clock = 0;
    const cache = new TtlCache({ ttlMs: 100, now: () => clock });
    cache.set('a', 1);
    expect(cache.get('a')).toBe(1);
    clock = 101;
    expect(cache.get('a')).toBeUndefined();

    cache.set('b', 2);
    cache.set('c', 3);
    expect(cache.invalidate('b')).toBe(1);
    expect(cache.invalidate()).toBe(1);
    expect(cache.size).toBe(0);
    expect(cache.stats()).toMatchObject({ hits: 1, misses: 1 });

    let calls = 0;
    const value = await cache.wrap('k', () => {
      calls += 1;
      return 'computed';
    });
    expect(value).toBe('computed');
    await cache.wrap('k', () => {
      calls += 1;
      return 'computed';
    });
    expect(calls).toBe(1);
  });

  it('evicts the oldest key when full', () => {
    const cache = new TtlCache({ ttlMs: 1000, maxEntries: 2 });
    cache.set('a', 1);
    cache.set('b', 2);
    cache.set('c', 3);
    expect(cache.get('a')).toBeUndefined();
    expect(cache.size).toBe(2);
  });
});

describe('cacheKey and etag', () => {
  it('builds stable keys from arbitrary payloads', () => {
    expect(cacheKey('dash', { a: 1 })).toBe(cacheKey('dash', { a: 1 }));
    expect(cacheKey('dash', { a: 1 })).not.toBe(cacheKey('dash', { a: 2 }));
    expect(cacheKey('dash', new Date('2026-10-18T00:00:00Z'))).toContain('dash:');
  });

  it('produces weak etags and matches conditional requests', () => {
    const etag = etagFor({ a: 1 });
    expect(etag.startsWith('W/"')).toBe(true);
    expect(etagFor({ a: 1 })).toBe(etag);
    expect(isFresh(etag, etag)).toBe(true);
    expect(isFresh('*', etag)).toBe(true);
    expect(isFresh('W/"other"', etag)).toBe(false);
    expect(isFresh(undefined, etag)).toBe(false);
  });
});

describe('errors', () => {
  it('maps each error type to its status and code', () => {
    expect(new ValidationError()).toMatchObject({ statusCode: 400, code: 'VALIDATION_ERROR' });
    expect(new UnauthorizedError()).toMatchObject({ statusCode: 401 });
    expect(new ForbiddenError()).toMatchObject({ statusCode: 403 });
    expect(new NotFoundError()).toMatchObject({ statusCode: 404 });
    expect(new ConflictError()).toMatchObject({ statusCode: 409 });
    expect(new BusinessRuleError()).toMatchObject({ statusCode: 422 });
    expect(new UpstreamError()).toMatchObject({ statusCode: 503 });
  });

  it('never exposes a 500 to the client', () => {
    expect(new AppError('boom').expose).toBe(false);
    expect(new NotFoundError().expose).toBe(true);
    const wrapped = toAppError(new Error('secret internals'));
    expect(wrapped.message).toBe('Unexpected server error');
    expect(wrapped.cause.message).toBe('secret internals');
    expect(toAppError(new NotFoundError('x'))).toBeInstanceOf(NotFoundError);
  });
});

describe('ids', () => {
  it('generates readable, prefixed, unique ids', () => {
    const id = newId('stk');
    expect(id).toMatch(/^stk-[a-z0-9]{9}-[A-Z2-9]{5}$/);
    expect(newId('stk')).not.toBe(id);
    expect(randomCode(8)).toHaveLength(8);
    expect(uuid()).toHaveLength(36);
    expect(anonymousToken('A', 7)).toBe('A-007');
  });
});

describe('logger', () => {
  it('emits structured JSON and redacts secrets', () => {
    const lines = [];
    const original = process.stdout.write.bind(process.stdout);
    process.stdout.write = (chunk) => {
      lines.push(chunk);
      return true;
    };
    try {
      const log = createLogger('test');
      log.info('hello', { facilityId: 'F1', authorization: 'Bearer secret', nested: { cookie: 'x' } });
      log.debug('debug line');
      log.warn('warn line');
      log.error('error line', { error: new Error('boom') });
    } finally {
      process.stdout.write = original;
    }

    const combined = lines.join('');
    expect(combined).not.toContain('Bearer secret');
    expect(combined).toContain('[redacted]');
    expect(combined).toContain('"severity":"INFO"');
    expect(combined).toContain('"component":"test"');
  });
});
