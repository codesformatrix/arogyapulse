import { describe, expect, it } from '@jest/globals';

import {
  allocateFefo,
  batchStatus,
  daysUntilExpiry,
  expiryFromShelfLife,
  fefoOrder,
  totalUnits,
  writeOffCandidates,
} from '../../src/services/inventory.js';

const TODAY = '2026-10-18';

const batches = [
  { id: 'b-far', batchNo: 'B1', quantity: 100, expiryDate: '2027-06-01', receivedAt: '2026-01-01T00:00:00Z' },
  { id: 'b-near', batchNo: 'B2', quantity: 60, expiryDate: '2026-11-20', receivedAt: '2026-03-01T00:00:00Z' },
  { id: 'b-expired', batchNo: 'B3', quantity: 20, expiryDate: '2026-09-01', receivedAt: '2025-09-01T00:00:00Z' },
];

describe('totalUnits and daysUntilExpiry', () => {
  it('sums batch quantities', () => {
    expect(totalUnits(batches)).toBe(180);
    expect(totalUnits(undefined)).toBe(0);
  });

  it('measures days to expiry, negative when past', () => {
    expect(daysUntilExpiry('2026-10-28', TODAY)).toBe(10);
    expect(daysUntilExpiry('2026-10-08', TODAY)).toBe(-10);
    expect(daysUntilExpiry('not-a-date', TODAY)).toBeNull();
  });
});

describe('batchStatus', () => {
  it('classifies active, near-expiry and expired batches', () => {
    expect(batchStatus(batches[0], { todayKey: TODAY })).toBe('ACTIVE');
    expect(batchStatus(batches[1], { todayKey: TODAY })).toBe('NEAR_EXPIRY');
    expect(batchStatus(batches[2], { todayKey: TODAY })).toBe('EXPIRED');
  });
});

describe('fefoOrder', () => {
  it('sorts soonest expiry first and drops expired and empty batches', () => {
    const ordered = fefoOrder([...batches, { id: 'b-empty', quantity: 0, expiryDate: '2026-10-20' }], TODAY);
    expect(ordered.map((batch) => batch.id)).toEqual(['b-near', 'b-far']);
  });

  it('breaks ties by receipt date', () => {
    const ordered = fefoOrder(
      [
        { id: 'new', quantity: 5, expiryDate: '2027-01-01', receivedAt: '2026-06-01T00:00:00Z' },
        { id: 'old', quantity: 5, expiryDate: '2027-01-01', receivedAt: '2026-01-01T00:00:00Z' },
      ],
      TODAY,
    );
    expect(ordered.map((batch) => batch.id)).toEqual(['old', 'new']);
  });
});

describe('allocateFefo', () => {
  it('takes from the soonest-expiring batch first', () => {
    const result = allocateFefo(batches, 80, TODAY);
    expect(result.allocations).toEqual([
      { batchId: 'b-near', quantity: 60, expiryDate: '2026-11-20' },
      { batchId: 'b-far', quantity: 20, expiryDate: '2027-06-01' },
    ]);
    expect(result.fulfilled).toBe(80);
    expect(result.shortfall).toBe(0);
  });

  it('reports a shortfall instead of dispensing expired stock', () => {
    const result = allocateFefo(batches, 200, TODAY);
    expect(result.fulfilled).toBe(160); // expired batch is never used
    expect(result.shortfall).toBe(40);
  });

  it('handles a zero quantity request', () => {
    expect(allocateFefo(batches, 0, TODAY)).toEqual({ allocations: [], fulfilled: 0, shortfall: 0 });
  });
});

describe('writeOffCandidates', () => {
  it('lists expired and near-expiry batches, soonest first', () => {
    const candidates = writeOffCandidates(batches, { todayKey: TODAY });
    expect(candidates.map((candidate) => candidate.reason)).toEqual(['EXPIRED', 'NEAR_EXPIRY']);
    expect(candidates[0].batchNo).toBe('B3');
  });

  it('can exclude near-expiry stock', () => {
    const candidates = writeOffCandidates(batches, { todayKey: TODAY, includeNearExpiry: false });
    expect(candidates).toHaveLength(1);
  });
});

describe('expiryFromShelfLife', () => {
  it('adds the shelf life to the receipt date', () => {
    expect(expiryFromShelfLife('2026-01-01T00:00:00Z', 365)).toBe('2027-01-01');
  });
});
