import { describe, expect, it } from '@jest/globals';

import {
  consumptionStdDev,
  daysOfCover,
  expiryRisk,
  forecastLine,
  predictStockoutDate,
  rankByRisk,
  simpleDailyAverage,
  statusFor,
  suggestedReorderUnits,
  weightedMovingAverage,
} from '../../src/services/forecast.js';

const seriesOf = (quantities) =>
  quantities.map((quantity, index) => ({ date: `2026-10-${String(index + 1).padStart(2, '0')}`, quantity }));

describe('weightedMovingAverage', () => {
  it('weights recent days more heavily than older days', () => {
    // Weights [1,1,1.5,1.5,2,2,3]; (10*11.5 + 20*3) / 12.5 = 12.5.
    expect(weightedMovingAverage(seriesOf([10, 10, 10, 10, 10, 10, 20]))).toBeCloseTo(12.5, 3);
  });

  it('uses the heaviest weights when the history is shorter than the window', () => {
    // The 7-weight window is always applied in full; the 4 missing days count
    // as zero consumption, so (10+20+30+0+0+0+0 weighted) / 12.5 = 21.429.
    expect(weightedMovingAverage(seriesOf([10, 20, 30]))).toBeCloseTo(21.429, 3);
  });

  it('returns 0 for empty or missing input', () => {
    expect(weightedMovingAverage([])).toBe(0);
    expect(weightedMovingAverage(undefined)).toBe(0);
  });

  it('treats a missing day as zero consumption', () => {
    expect(weightedMovingAverage(seriesOf([7, 0, 7]))).toBeLessThan(weightedMovingAverage(seriesOf([7, 7, 7])));
  });
});

describe('simpleDailyAverage and consumptionStdDev', () => {
  it('computes the mean and 0 for empty input', () => {
    expect(simpleDailyAverage(seriesOf([4, 8]))).toBe(6);
    expect(simpleDailyAverage([])).toBe(0);
  });

  it('computes a population standard deviation', () => {
    expect(consumptionStdDev(seriesOf([10, 10, 10]))).toBe(0);
    expect(consumptionStdDev(seriesOf([8, 12]))).toBeCloseTo(2, 5);
    expect(consumptionStdDev([])).toBe(0);
  });
});

describe('daysOfCover', () => {
  it('divides stock by the forecast rate', () => {
    expect(daysOfCover(100, 10)).toBe(10);
  });

  it('returns null when nothing is being consumed', () => {
    expect(daysOfCover(100, 0)).toBeNull();
  });

  it('returns 0 for an empty shelf', () => {
    expect(daysOfCover(0, 10)).toBe(0);
  });
});

describe('statusFor', () => {
  it('maps days of cover to RED / AMBER / GREEN', () => {
    expect(statusFor({ daysOfCover: 1, stock: 10 })).toBe('RED');
    expect(statusFor({ daysOfCover: 5, stock: 50 })).toBe('AMBER');
    expect(statusFor({ daysOfCover: 30, stock: 300 })).toBe('GREEN');
  });

  it('reports an empty shelf as RED even without a consumption rate', () => {
    expect(statusFor({ daysOfCover: null, stock: 0 })).toBe('RED');
  });

  it('reports expiry risk separately from availability', () => {
    expect(statusFor({ daysOfCover: 40, stock: 4000, expiryRiskShare: 0.5 })).toBe('EXPIRY_RISK');
  });

  it('uses the reorder level when consumption is unknown', () => {
    expect(statusFor({ daysOfCover: null, stock: 40, reorderLevel: 50 })).toBe('AMBER');
  });
});

describe('predictStockoutDate', () => {
  it('projects the date from today', () => {
    expect(predictStockoutDate({ stock: 100, perDay: 10, todayKey: '2026-10-18' })).toBe('2026-10-28');
  });

  it('returns today when the shelf is already empty', () => {
    expect(predictStockoutDate({ stock: 0, perDay: 10, todayKey: '2026-10-18' })).toBe('2026-10-18');
  });

  it('returns null when stock will not deplete', () => {
    expect(predictStockoutDate({ stock: 100, perDay: 0, todayKey: '2026-10-18' })).toBeNull();
  });
});

describe('expiryRisk', () => {
  const batches = [
    { id: 'b1', batchNo: 'B1', quantity: 40, expiryDate: '2026-11-01' },
    { id: 'b2', batchNo: 'B2', quantity: 60, expiryDate: '2027-06-01' },
  ];

  it('counts units expiring inside the window', () => {
    const result = expiryRisk(batches, { todayKey: '2026-10-18' });
    expect(result.riskUnits).toBe(40);
    expect(result.share).toBeCloseTo(0.4, 5);
    expect(result.soonestExpiry).toBe('2026-11-01');
    expect(result.expiringBatches).toHaveLength(1);
  });

  it('handles empty input', () => {
    expect(expiryRisk([], { todayKey: '2026-10-18' })).toMatchObject({ riskUnits: 0, share: 0, soonestExpiry: null });
  });
});

describe('suggestedReorderUnits', () => {
  it('covers lead time plus a target cover and never goes negative', () => {
    const units = suggestedReorderUnits({ stock: 0, perDay: 10, stdDev: 0, reorderLevel: 100 });
    expect(units).toBeGreaterThanOrEqual(210); // 21 days of target cover
    expect(suggestedReorderUnits({ stock: 5000, perDay: 10, stdDev: 0 })).toBe(0);
  });

  it('respects a configured reorder level as a floor', () => {
    expect(suggestedReorderUnits({ stock: 0, perDay: 0, stdDev: 0, reorderLevel: 250 })).toBe(250);
  });
});

describe('forecastLine', () => {
  it('produces a complete, deterministic forecast record', () => {
    const result = forecastLine({
      stock: 50,
      reorderLevel: 70,
      consumptionSeries: seriesOf([10, 10, 10, 10, 10, 10, 20]),
      batches: [
        { id: 'b1', quantity: 10, expiryDate: '2026-11-01' },
        { id: 'b2', quantity: 40, expiryDate: '2027-06-01' },
      ],
      todayKey: '2026-10-18',
    });

    expect(result.forecastPerDay).toBeCloseTo(12.5, 3);
    expect(result.daysOfCover).toBe(4); // 50 units / 12.5 per day
    expect(result.status).toBe('AMBER'); // 3 <= cover < 7
    expect(result.predictedStockoutDate).toBe('2026-10-22');
    expect(result.expiryRiskShare).toBeCloseTo(0.2, 5);
    expect(result.reorderNeeded).toBe(true); // cover 4 <= auto-indent threshold 7
    expect(result.suggestedReorderUnits).toBeGreaterThan(0);
  });

  it('reports EXPIRY_RISK when stock is ample but a third of it expires soon', () => {
    const result = forecastLine({
      stock: 1000,
      consumptionSeries: seriesOf([10, 10, 10, 10, 10, 10, 20]),
      batches: [
        { id: 'b1', quantity: 400, expiryDate: '2026-11-01' },
        { id: 'b2', quantity: 600, expiryDate: '2027-06-01' },
      ],
      todayKey: '2026-10-18',
    });

    expect(result.daysOfCover).toBe(80);
    expect(result.status).toBe('EXPIRY_RISK');
    expect(result.expiryRiskShare).toBeCloseTo(0.4, 5);
    expect(result.reorderNeeded).toBe(false);
  });

  it('flags RED and triggers a reorder below three days of cover', () => {
    const result = forecastLine({
      stock: 20,
      consumptionSeries: seriesOf([10, 10, 10, 10, 10, 10, 10]),
      todayKey: '2026-10-18',
    });
    expect(result.status).toBe('RED');
    expect(result.reorderNeeded).toBe(true);
    expect(result.daysOfCover).toBe(2);
  });

  it('survives a stock line with no history at all', () => {
    const result = forecastLine({ stock: 500, consumptionSeries: [], todayKey: '2026-10-18' });
    expect(result.status).toBe('GREEN');
    expect(result.daysOfCover).toBeNull();
    expect(result.predictedStockoutDate).toBeNull();
  });
});

describe('rankByRisk', () => {
  it('sorts RED first, then by days of cover', () => {
    const ranked = rankByRisk([
      { status: 'GREEN', daysOfCover: 40 },
      { status: 'RED', daysOfCover: 2 },
      { status: 'AMBER', daysOfCover: 5 },
      { status: 'RED', daysOfCover: 0 },
    ]);
    expect(ranked.map((line) => line.status)).toEqual(['RED', 'RED', 'AMBER', 'GREEN']);
    expect(ranked[0].daysOfCover).toBe(0);
  });
});
