import { describe, expect, it } from '@jest/globals';

import {
  adviceFor,
  estimateWaitTime,
  footfallTrend,
  hourlySeries,
  loadBand,
  observedServiceMinutes,
  predictedPeakHours,
} from '../../src/services/waitTime.js';

describe('estimateWaitTime', () => {
  it('projects the wait from queue length, counters and service time', () => {
    const estimate = estimateWaitTime({ waiting: 20, activeCounters: 2, avgServiceMinutes: 8 });
    expect(estimate.estimatedWaitMinutes).toBe(80); // 20 / (2/8 per minute)
    expect(estimate.load).toBe('HIGH');
    expect(estimate.aheadOfYou).toBe(20);
  });

  it('reduces the drain rate when arrivals outrun service', () => {
    const calm = estimateWaitTime({ waiting: 10, activeCounters: 2, avgServiceMinutes: 6 });
    const surge = estimateWaitTime({ waiting: 10, activeCounters: 2, avgServiceMinutes: 6, arrivalsPerHour: 15 });
    expect(surge.estimatedWaitMinutes).toBeGreaterThan(calm.estimatedWaitMinutes);
  });

  it('handles a closed OPD without dividing by zero', () => {
    const closed = estimateWaitTime({ waiting: 5, activeCounters: 0 });
    expect(closed.estimatedWaitMinutes).toBe(0);
    expect(closed.load).toBe('HIGH');
    expect(closed.advice).toContain('No counter is open');
  });

  it('falls back to the default service time when no history exists', () => {
    const estimate = estimateWaitTime({ waiting: 4, activeCounters: 1 });
    expect(estimate.avgServiceMinutes).toBe(8);
    expect(estimate.estimatedWaitMinutes).toBe(32);
  });
});

describe('loadBand and adviceFor', () => {
  it('maps waits to LOW / MODERATE / HIGH', () => {
    expect(loadBand(5)).toBe('LOW');
    expect(loadBand(30)).toBe('MODERATE');
    expect(loadBand(120)).toBe('HIGH');
  });

  it('always returns a plain-language sentence, never medical advice', () => {
    for (const load of ['LOW', 'MODERATE', 'HIGH']) {
      expect(typeof adviceFor(load, 42)).toBe('string');
      expect(adviceFor(load, 42).length).toBeGreaterThan(10);
    }
  });
});

describe('observedServiceMinutes', () => {
  const diff = (a, b) => Number(b) - Number(a);

  it('averages completed consultations and ignores outliers', () => {
    const tokens = [
      { issuedAt: 0, servedAt: 10 },
      { issuedAt: 0, servedAt: 20 },
      { issuedAt: 0, servedAt: 900 }, // outlier: 15 hours
      { issuedAt: 0, servedAt: null },
    ];
    expect(observedServiceMinutes(tokens, diff)).toBe(15);
  });

  it('returns the default when there is no history', () => {
    expect(observedServiceMinutes([], diff)).toBe(8);
  });
});

describe('predictedPeakHours', () => {
  const history = [
    { date: '2026-10-05', weekday: 1, hour: 10, count: 40 },
    { date: '2026-10-05', weekday: 1, hour: 11, count: 20 },
    { date: '2026-10-12', weekday: 1, hour: 10, count: 60 },
    { date: '2026-10-12', weekday: 1, hour: 11, count: 20 },
    { date: '2026-10-13', weekday: 2, hour: 10, count: 500 }, // different weekday: ignored
    { date: '2026-01-05', weekday: 1, hour: 10, count: 900 }, // outside the 14-day window
  ];

  it('averages the same weekday inside the window and ranks the busiest hours', () => {
    const peaks = predictedPeakHours(history, { weekday: 1, todayKey: '2026-10-18' });
    expect(peaks[0]).toEqual({ hour: 10, avgCount: 50 });
    expect(peaks[1]).toEqual({ hour: 11, avgCount: 20 });
  });

  it('returns an empty list without history', () => {
    expect(predictedPeakHours([], { weekday: 1, todayKey: '2026-10-18' })).toEqual([]);
    expect(predictedPeakHours(history, {})).toEqual([]);
  });
});

describe('hourlySeries', () => {
  it('fills every OPD hour, including empty ones', () => {
    const series = hourlySeries([{ hour: 9, count: 5 }, { hour: 9, count: 2 }, { hour: 23, count: 9 }], 8, 12);
    expect(series).toHaveLength(5);
    expect(series[1]).toEqual({ hour: 9, count: 7 });
    expect(series[4]).toEqual({ hour: 12, count: 0 });
  });
});

describe('footfallTrend', () => {
  it('reports the percentage change against the same weekday baseline', () => {
    expect(footfallTrend(120, 100)).toEqual({ deltaPercent: 20, trend: 'UP' });
    expect(footfallTrend(80, 100)).toEqual({ deltaPercent: -20, trend: 'DOWN' });
    expect(footfallTrend(103, 100)).toEqual({ deltaPercent: 3, trend: 'FLAT' });
    expect(footfallTrend(50, 0)).toEqual({ deltaPercent: 0, trend: 'FLAT' });
  });
});
