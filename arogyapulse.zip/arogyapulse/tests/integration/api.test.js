/**
 * End-to-end HTTP integration tests.
 *
 * These exercise the real stack: helmet, CORS, compression, cookie auth, RBAC,
 * zod validation, controllers, services, the in-memory repository and the
 * rule-based AI fallback.
 */

import request from 'supertest';

import { FACILITY, OTHER_FACILITY, bootHarness, signIn } from './harness.js';

/** @type {import('express').Express} */
let app;
let repository;
/** @type {Record<string, string>} */
const cookies = {};

beforeAll(async () => {
  ({ app, repository } = await bootHarness());
  cookies.staff = await signIn(app, 'staff');
  cookies.chc = await signIn(app, 'chc');
  cookies.district = await signIn(app, 'district');
  cookies.public = await signIn(app, 'public');
}, 30_000);

const as = (who) => ({ Cookie: cookies[who] });

describe('health and platform behaviour', () => {
  it('reports a healthy service without leaking internals', async () => {
    const response = await request(app).get('/healthz').expect(200);
    expect(response.body.status).toBe('ok');
    expect(response.body.repository).toBe('memory');
    expect(response.body.ai).toHaveProperty('mode');
    expect(JSON.stringify(response.body)).not.toMatch(/apiKey|secret|password/i);
  });

  it('sets hardened security headers', async () => {
    const response = await request(app).get('/healthz').expect(200);
    const csp = response.headers['content-security-policy'];
    expect(csp).toContain("default-src 'none'");
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("script-src 'self'");
    expect(csp).toContain("frame-ancestors 'none'");
    expect(response.headers['x-content-type-options']).toBe('nosniff');
    expect(response.headers['x-powered-by']).toBeUndefined();
    expect(response.headers['referrer-policy']).toBeDefined();
  });

  it('returns ETags and honours If-None-Match', async () => {
    const first = await request(app).get('/api/medicines').set(as('staff')).expect(200);
    expect(first.headers.etag).toBeDefined();
    await request(app)
      .get('/api/medicines')
      .set(as('staff'))
      .set('If-None-Match', first.headers.etag)
      .expect(304);
  });

  it('returns a safe 404 envelope for unknown routes', async () => {
    const response = await request(app).get('/api/does-not-exist').set(as('staff')).expect(404);
    expect(response.body.error.code).toBe('NOT_FOUND');
    expect(response.body.error).not.toHaveProperty('stack');
  });

  it('rejects an oversized JSON body', async () => {
    const huge = { note: 'x'.repeat(200_000) };
    await request(app).post('/api/stock/adjust').set(as('staff')).send(huge).expect(413);
  });
});

describe('authentication and sessions', () => {
  it('describes the current actor and their permissions', async () => {
    const response = await request(app).get('/api/auth/me').set(as('chc')).expect(200);
    expect(response.body.role).toBe('chc_admin');
    expect(response.body.permissions).toContain('indent:create');
    expect(response.body.permissions).not.toContain('indent:approve');
  });

  it('falls back to the public actor without a session', async () => {
    const response = await request(app).get('/api/auth/me').expect(200);
    expect(response.body.role).toBe('public');
    expect(response.body.isPublic).toBe(true);
  });

  it('rejects a tampered session cookie', async () => {
    await request(app)
      .get('/api/dashboard/facility?facilityId=FAC-PHC-RAHATA')
      .set('Cookie', 'ap_session=not.a.real.token')
      .expect(401);
  });

  it('clears the cookie on logout', async () => {
    const response = await request(app).post('/api/auth/logout').set(as('staff')).expect(200);
    const cleared = String(response.headers['set-cookie']);
    expect(cleared).toMatch(/ap_session=;/);
  });
});

describe('role-based access control', () => {
  it('lets staff read their own facility', async () => {
    const response = await request(app)
      .get(`/api/stock?facilityId=${FACILITY}`)
      .set(as('staff'))
      .expect(200);
    expect(response.body.items.length).toBeGreaterThan(0);
    expect(response.body.counts).toHaveProperty('RED');
  });

  it('blocks staff from reading another facility', async () => {
    await request(app).get(`/api/stock?facilityId=${OTHER_FACILITY}`).set(as('staff')).expect(403);
  });

  it('allows a district officer to read any facility', async () => {
    await request(app)
      .get(`/api/stock?facilityId=${OTHER_FACILITY}`)
      .set(as('district'))
      .expect(200);
  });

  it('blocks staff from the district dashboard', async () => {
    await request(app).get('/api/dashboard/district').set(as('staff')).expect(403);
  });

  it('blocks CHC admins from approving indents', async () => {
    await request(app)
      .post('/api/indents/IND-ANY/status')
      .set(as('chc'))
      .send({ status: 'APPROVED' })
      .expect(403);
  });

  it('gives the public only read access', async () => {
    await request(app).get(`/api/stock?facilityId=${FACILITY}`).set(as('public')).expect(200);
    await request(app)
      .post('/api/stock/adjust')
      .set(as('public'))
      .send({ medicineId: 'MED-ORS', delta: 5, reason: 'RECEIPT' })
      .expect(403);
  });

  it('requires a facility for facility-scoped writes', async () => {
    const response = await request(app)
      .post('/api/stock/adjust')
      .set(as('district'))
      .send({ medicineId: 'MED-ORS', delta: 5, reason: 'RECEIPT' })
      .expect(403);
    expect(response.body.error.code).toBe('FORBIDDEN');
  });
});

describe('stock and dispensing', () => {
  let stockBefore;

  it('reads the inventory forecast for a facility', async () => {
    const response = await request(app)
      .get(`/api/stock?facilityId=${FACILITY}&limit=5`)
      .set(as('staff'))
      .expect(200);
    stockBefore = response.body.items[0];
    expect(stockBefore).toHaveProperty('daysOfCover');
    expect(stockBefore).toHaveProperty('status');
    expect(response.body.counts.RED + response.body.counts.AMBER).toBeGreaterThan(0);
  });

  it('applies a stock receipt and returns the refreshed forecast', async () => {
    const response = await request(app)
      .post('/api/stock/adjust')
      .set(as('staff'))
      .send({ medicineId: 'MED-ORS', delta: 250, reason: 'RECEIPT', note: 'District supply' })
      .expect(201);

    expect(response.body.forecast.stock).toBeGreaterThan(0);
    expect(response.body.forecast).toHaveProperty('predictedStockoutDate');
    expect(response.body.stock.units).toBeGreaterThan(0);
  });

  it('rejects a zero delta', async () => {
    await request(app)
      .post('/api/stock/adjust')
      .set(as('staff'))
      .send({ medicineId: 'MED-ORS', delta: 0, reason: 'RECEIPT' })
      .expect(400);
  });

  it('records dispensing and decrements the batch', async () => {
    const response = await request(app)
      .post('/api/dispensing')
      .set(as('staff'))
      .send({ medicineId: 'MED-ORS', quantity: 3 })
      .expect(201);
    expect(response.body.fulfilled).toBeGreaterThan(0);
    expect(Array.isArray(response.body.allocations)).toBe(true);
    expect(response.body.forecast.stock).toBeGreaterThanOrEqual(0);
  });

  it('refuses to dispense more than is on hand', async () => {
    const response = await request(app)
      .post('/api/dispensing')
      .set(as('staff'))
      .send({ medicineId: 'MED-ORS', quantity: 9_000_000 })
      .expect(400);
    expect(response.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('writes an audit row for every mutation', async () => {
    const response = await request(app)
      .get(`/api/audit?facilityId=${FACILITY}&entityType=STOCK`)
      .set(as('district'))
      .expect(200);
    expect(response.body.items.length).toBeGreaterThan(0);
    expect(response.body.items[0].actor).toBeDefined();
  });
});

describe('queue and public crowding', () => {
  it('issues a department-prefixed token', async () => {
    const response = await request(app)
      .post('/api/tokens')
      .set(as('staff'))
      .send({ department: 'OPD_GENERAL' })
      .expect(201);
    expect(response.body.token).toMatch(/^[A-M]-[0-9]{2,4}$/);
    expect(response.body.department).toBe('OPD_GENERAL');
  });

  it('reports waiting count and wait estimate', async () => {
    const response = await request(app)
      .get(`/api/queue?facilityId=${FACILITY}`)
      .set(as('staff'))
      .expect(200);
    expect(response.body.waiting).toBeGreaterThanOrEqual(0);
    expect(response.body).toHaveProperty('estimatedWaitMinutes');
    expect(['LOW', 'MODERATE', 'HIGH']).toContain(response.body.load);
    expect(typeof response.body.advice).toBe('string');
  });

  it('serves the public crowding view without identity', async () => {
    const response = await request(app)
      .get(`/api/public/crowding?facilityId=${FACILITY}`)
      .expect(200);
    expect(response.body).toHaveProperty('load');
    expect(response.body).toHaveProperty('estimatedWaitMinutes');
    expect(response.body).toHaveProperty('advice');
    expect(JSON.stringify(response.body)).not.toMatch(/sunita|doctor|patient/i);
  });
});

describe('beds, attendance and referrals', () => {
  it('updates a bed count with one tap', async () => {
    const wards = await request(app).get(`/api/beds?facilityId=${FACILITY}`).set(as('staff')).expect(200);
    const ward = wards.body.wards[0];
    const before = ward.occupied;

    const response = await request(app)
      .post(`/api/beds/${ward.id}/update`)
      .set(as('staff'))
      .send({ field: 'occupied', delta: 1 })
      .expect(200);

    const after = response.body.ward?.occupied ?? response.body.occupied;
    expect(after).toBe(before + 1);
  });

  it('rejects an impossible bed count', async () => {
    const wards = await request(app).get(`/api/beds?facilityId=${FACILITY}`).set(as('staff')).expect(200);
    await request(app)
      .post(`/api/beds/${wards.body.wards[0].id}/update`)
      .set(as('staff'))
      .send({ field: 'occupied', delta: -9_999 })
      .expect(400);
  });

  it('checks a doctor in and marks lateness against 09:30', async () => {
    const response = await request(app)
      .post('/api/attendance/check-in')
      .set(as('staff'))
      .send({ doctorId: 'DOC-PHCR-2' })
      .expect(201);
    expect(response.body).toHaveProperty('late');
    expect(response.body.alertTime).toBe('09:30');
  });

  it('reports reliability over the 30-day window', async () => {
    const response = await request(app)
      .get(`/api/attendance?facilityId=${FACILITY}`)
      .set(as('staff'))
      .expect(200);
    expect(response.body.entries.length).toBeGreaterThan(0);
    const entry = response.body.entries.find((candidate) => candidate.reliabilityPercent !== null);
    expect(entry.reliabilityPercent).toBeGreaterThanOrEqual(0);
    expect(entry.reliabilityPercent).toBeLessThanOrEqual(100);
  });

  it('lists CHC referral options with live bed availability', async () => {
    const response = await request(app)
      .get('/api/referrals/options')
      .set(as('staff'))
      .expect(200);
    expect(response.body.facilities.length).toBeGreaterThan(0);
    expect(response.body.facilities[0]).toHaveProperty('available');
    expect(response.body.facilities[0]).toHaveProperty('total');
  });

  it('creates a referral using an anonymous token only', async () => {
    const response = await request(app)
      .post('/api/referrals')
      .set(as('staff'))
      .send({ toFacilityId: 'FAC-CHC-SHRIRAMPUR', category: 'MATERNITY', patientToken: 'T-104' })
      .expect(201);
    expect(response.body.patientToken).toBe('T-104');
    expect(response.body).not.toHaveProperty('patientName');
  });
});

describe('district supply chain', () => {
  it('ranks facilities by risk', async () => {
    const response = await request(app).get('/api/dashboard/district').set(as('district')).expect(200);
    expect(response.body.facilities.length).toBeGreaterThanOrEqual(10);
    expect(response.body.facilities[0]).toHaveProperty('riskScore');
  });

  it('suggests surplus-to-deficit transfers', async () => {
    const response = await request(app)
      .get('/api/transfers/suggestions')
      .set(as('district'))
      .expect(200);
    expect(response.body).toHaveProperty('surplusToDeficit');
    expect(response.body).toHaveProperty('expiryRisk');
    expect(Array.isArray(response.body.surplusToDeficit)).toBe(true);
  });

  it('runs indent lifecycle Requested -> Approved', async () => {
    const created = await request(app)
      .post('/api/indents')
      .set(as('staff'))
      .send({ items: [{ medicineId: 'MED-ORS', units: 50 }] })
      .expect(201);
    expect(created.body.status).toBe('REQUESTED');

    const approved = await request(app)
      .post(`/api/indents/${created.body.id}/status`)
      .set(as('district'))
      .send({ status: 'APPROVED' })
      .expect(200);
    expect(approved.body.status).toBe('APPROVED');
  });

  it('refuses an illegal status jump', async () => {
    const created = await request(app)
      .post('/api/indents')
      .set(as('staff'))
      .send({ items: [{ medicineId: 'MED-ORS', units: 10 }] })
      .expect(201);

    await request(app)
      .post(`/api/indents/${created.body.id}/status`)
      .set(as('district'))
      .send({ status: 'RECEIVED' })
      .expect(409);
  });
});

describe('AI layer', () => {
  it('falls back to basic mode when Gemini is not configured', async () => {
    const response = await request(app).get('/api/ai/status').expect(200);
    expect(response.body.mode).toBe('basic');
    expect(response.body.enabled).toBe(false);
    expect(response.body.model).toBe('rule-based');
  });

  it('parses a Hindi/Hinglish stock note and asks for confirmation', async () => {
    const response = await request(app)
      .post('/api/ai/nl-entry')
      .set(as('staff'))
      .send({ text: 'paracetamol 500 ke 200 tablet aaye', language: 'hi' })
      .expect(200);

    expect(response.body.intent).toBe('STOCK_ADJUSTMENT');
    expect(response.body.medicineHint).toBe('MED-PARA-500');
    expect(response.body.meta.preview.medicineId).toBe('MED-PARA-500');
    expect(response.body.meta.preview.medicineName).toBe('Paracetamol');
    expect(response.body.quantity).toBe(200);
    expect(response.body.meta.requiresConfirmation).toBe(true);
    expect(['basic', 'gemini']).toContain(response.body.meta.mode);
  });

  it('does not save anything during parsing', async () => {
    const before = repository.count('audit');
    await request(app)
      .post('/api/ai/nl-entry')
      .set(as('staff'))
      .send({ text: 'ors 50 aaye', facilityId: FACILITY })
      .expect(200);
    expect(repository.count('audit')).toBe(before);
  });

  it('blocks a tampered confirmation', async () => {
    const response = await request(app)
      .post('/api/ai/confirm')
      .set(as('staff'))
      .send({
        intent: 'STOCK_ADJUSTMENT',
        medicineId: 'MED-ORS',
        quantity: 1_000_000,
        originalText: 'ors 10 diye',
      })
      .expect(200);
    expect(response.body.ok).toBe(false);
    expect(response.body.reason).toBe('INTENT_MISMATCH');
  });

  it('refuses clinical questions before the model is called', async () => {
    const response = await request(app)
      .post('/api/ai/ask')
      .set(as('staff'))
      .send({ question: 'What dose of paracetamol should I give a 3 year old?' })
      .expect(200);
    expect(response.body.meta.mode).toBe('guardrail');
    expect(response.body.answer).toMatch(/never gives medical|operational questions only/i);
  });

  it('answers an inventory question from the facility snapshot', async () => {
    const response = await request(app)
      .post('/api/ai/ask')
      .set(as('staff'))
      .send({ question: 'ORS kitna bacha hai?' })
      .expect(200);
    expect(response.body.answer.length).toBeGreaterThan(10);
    expect(response.body.meta.mode).toBe('basic');
  });

  it('produces a deterministic briefing in basic mode', async () => {
    const response = await request(app)
      .post('/api/ai/briefing')
      .set(as('district'))
      .send({ scope: 'district' })
      .expect(200);
    expect(response.body).toHaveProperty('headline');
    expect(Array.isArray(response.body.topRisks)).toBe(true);
    expect(response.body.meta.mode).toBe('basic');
  });

  it('rejects an empty question', async () => {
    await request(app).post('/api/ai/ask').set(as('staff')).send({ question: '   ' }).expect(400);
  });
});

describe('offline replay', () => {
  it('replays allowed operations and rejects everything else', async () => {
    const response = await request(app)
      .post('/api/offline/replay')
      .set(as('staff'))
      .send({
        operations: [
          { id: 'q1', method: 'POST', path: '/api/dispensing', body: { medicineId: 'MED-ORS', quantity: 2 } },
          { id: 'q2', method: 'POST', path: '/api/auth/login', body: {} },
        ],
      })
      .expect(200);

    expect(response.body.succeeded).toBe(1);
    expect(response.body.failed).toBe(1);
    expect(response.body.results.find((entry) => entry.id === 'q2').code).toBe('PATH_NOT_REPLAYABLE');
  });
});

describe('validation is enforced at the edge', () => {
  it.each([
    ['bad reason', { medicineId: 'MED-ORS', delta: 5, reason: 'BECAUSE' }],
    ['unknown medicine field', { medicineId: '', delta: 5, reason: 'RECEIPT' }],
    ['string delta', { medicineId: 'MED-ORS', delta: 'abc', reason: 'RECEIPT' }],
  ])('rejects %s', async (_label, body) => {
    await request(app).post('/api/stock/adjust').set(as('staff')).send(body).expect(400);
  });
});
