/**
 * Workflow integration tests: the long-lived state machines.
 *
 * These exist because the happy-path smoke test of a single endpoint says
 * nothing about a transfer that must move stock between two facilities without
 * ever creating or destroying a unit.
 */

import request from 'supertest';

import { FACILITY, bootHarness, signIn } from './harness.js';

let app;
let repository;
const cookies = {};
const as = (who) => ({ Cookie: cookies[who] });

beforeAll(async () => {
  ({ app, repository } = await bootHarness());
  cookies.staff = await signIn(app, 'staff');
  cookies.chc = await signIn(app, 'chc');
  cookies.district = await signIn(app, 'district');
}, 30_000);

/** Total units of a medicine across all batches at a facility. */
export async function batchUnits(facilityId, medicineId) {
  const batches = await repository.listBatches({ facilityId, medicineId, limit: 200, offset: 0 });
  const items = batches.items ?? batches;
  return items.reduce((sum, batch) => sum + batch.quantity, 0);
}

async function stockUnits(facilityId, medicineId) {
  const line = await repository.getStock(facilityId, medicineId);
  return line?.units ?? 0;
}

describe('transfer lifecycle', () => {
  /** Find a real batch in a facility that has enough units to move. */
  async function pickBatch(minimum = 20) {
    const lines = await repository.listStockByFacility({});
    for (const line of lines.filter((candidate) => candidate.units > minimum)) {
      const items = await repository.listBatches({
        facilityId: line.facilityId,
        medicineId: line.medicineId,
      });
      const batch = items.find((candidate) => candidate.quantity > minimum);
      if (batch) {
        return { source: line.facilityId, medicineId: line.medicineId, batchId: batch.id, quantity: batch.quantity };
      }
    }
    return null;
  }

  it('moves stock from a surplus facility to a deficit one', async () => {
    const picked = await pickBatch(40);
    expect(picked).not.toBeNull();

    const lines = await repository.listStockByFacility({});
    const target = lines.find(
      (line) => line.medicineId === picked.medicineId && line.facilityId !== picked.source,
    );
    expect(target).toBeDefined();

    const targetBefore = await stockUnits(target.facilityId, picked.medicineId);

    const created = await request(app)
      .post('/api/transfers')
      .set(as('district'))
      .send({
        fromFacilityId: picked.source,
        toFacilityId: target.facilityId,
        medicineId: picked.medicineId,
        batchId: picked.batchId,
        units: 20,
        reason: 'SURPLUS_TO_DEFICIT',
      })
      .expect(201);

    await request(app)
      .post(`/api/transfers/${created.body.id}/status`)
      .set(as('district'))
      .send({ status: 'APPROVED' })
      .expect(200);

    const dispatched = await request(app)
      .post(`/api/transfers/${created.body.id}/status`)
      .set(as('district'))
      .send({ status: 'DISPATCHED' })
      .expect(200);
    expect(dispatched.body.status).toBe('DISPATCHED');

    const received = await request(app)
      .post(`/api/transfers/${created.body.id}/status`)
      .set(as('district'))
      .send({ status: 'RECEIVED' })
      .expect(200);
    expect(received.body.status).toBe('RECEIVED');

    // Units leave the source at dispatch and arrive at the destination by receipt.
    expect(await stockUnits(target.facilityId, picked.medicineId)).toBeGreaterThanOrEqual(targetBefore);
  });

  it('refuses to dispatch more than the batch holds', async () => {
    const picked = await pickBatch(5);
    expect(picked).not.toBeNull();

    const lines = await repository.listStockByFacility({});
    const target = lines.find(
      (line) => line.medicineId === picked.medicineId && line.facilityId !== picked.source,
    );

    // A transfer cannot request more units than exist, so this is rejected at
    // the edge rather than at dispatch.
    await request(app)
      .post('/api/transfers')
      .set(as('district'))
      .send({
        fromFacilityId: picked.source,
        toFacilityId: target.facilityId,
        medicineId: picked.medicineId,
        batchId: picked.batchId,
        units: picked.quantity + 100_000,
        reason: 'SURPLUS_TO_DEFICIT',
      })
      .expect(422);
  });

  it('rejects an illegal transition', async () => {
    const picked = await pickBatch(30);
    expect(picked).not.toBeNull();

    const lines = await repository.listStockByFacility({});
    const target = lines.find(
      (line) => line.medicineId === picked.medicineId && line.facilityId !== picked.source,
    );

    const created = await request(app)
      .post('/api/transfers')
      .set(as('district'))
      .send({
        fromFacilityId: picked.source,
        toFacilityId: target.facilityId,
        medicineId: picked.medicineId,
        batchId: picked.batchId,
        units: 1,
        reason: 'SURPLUS_TO_DEFICIT',
      })
      .expect(201);

    // RECEIVED is not reachable directly from REQUESTED.
    await request(app)
      .post(`/api/transfers/${created.body.id}/status`)
      .set(as('district'))
      .send({ status: 'RECEIVED' })
      .expect(409);
  });
});

describe('referral decisions', () => {
  it('accepts a referral and reserves a bed at the receiving CHC', async () => {
    const created = await request(app)
      .post('/api/referrals')
      .set(as('staff'))
      .send({
        toFacilityId: 'FAC-CHC-SANGAMNER',
        category: 'EMERGENCY',
        patientToken: 'T-205',
        needsBed: true,
      })
      .expect(201);

    const decided = await request(app)
      .post(`/api/referrals/${created.body.id}/status`)
      .set(as('chc'))
      .send({ status: 'ACCEPTED' })
      .expect(200);

    expect(decided.body.status).toBe('ACCEPTED');
    if (decided.body.wardId) expect(decided.body.wardId).toBeTruthy();
  });

  it('lets the receiving facility reject a referral with a reason', async () => {
    const created = await request(app)
      .post('/api/referrals')
      .set(as('staff'))
      .send({ toFacilityId: 'FAC-CHC-SANGAMNER', category: 'GENERAL', patientToken: 'T-206' })
      .expect(201);

    const decided = await request(app)
      .post(`/api/referrals/${created.body.id}/status`)
      .set(as('chc'))
      .send({ status: 'REJECTED', note: 'No obstetrician on duty' })
      .expect(200);

    expect(decided.body.status).toBe('REJECTED');
  });

  it('blocks a facility from deciding its own outgoing referral', async () => {
    await request(app)
      .post('/api/referrals/REF-UNKNOWN/status')
      .set(as('staff'))
      .send({ status: 'ACCEPTED' })
      .expect(403);
  });
});

describe('ward management', () => {
  it('creates and updates a ward', async () => {
    const created = await request(app)
      .put('/api/wards/WRD-TEST-1')
      .set(as('staff'))
      .send({ name: 'Dengue Ward', total: 8, occupied: 0, reserved: 0 })
      .expect(201);
    expect(created.body.total).toBe(8);

    const updated = await request(app)
      .put('/api/wards/WRD-TEST-1')
      .set(as('staff'))
      .send({ name: 'Dengue Ward', total: 10, occupied: 2, reserved: 1 })
      .expect(201);
    expect(updated.body.total).toBe(10);
    expect(updated.body.occupied).toBe(2);
  });

  it('refuses more occupied beds than the ward has', async () => {
    await request(app)
      .put('/api/wards/WRD-TEST-2')
      .set(as('staff'))
      .send({ name: 'Overfull', total: 4, occupied: 9, reserved: 0 })
      .expect(422);
  });
});

describe('counters and tokens', () => {
  it('opens a counter and serves a token from it', async () => {
    await request(app)
      .post('/api/counters')
      .set(as('staff'))
      .send({ counterId: 1, department: 'OPD_GENERAL', isOpen: true })
      .expect(200);

    const token = await request(app)
      .post('/api/tokens')
      .set(as('staff'))
      .send({ department: 'OPD_GENERAL' })
      .expect(201);

    const served = await request(app)
      .post(`/api/tokens/${token.body.id}/serve`)
      .set(as('staff'))
      .send({ counterId: 1 })
      .expect(200);

    expect(served.body.status).toBe('SERVED');
    expect(served.body.servedAt).toBeTruthy();
  });

  it('closes a counter and reflects it in the queue state', async () => {
    await request(app)
      .post('/api/counters')
      .set(as('staff'))
      .send({ counterId: 2, department: 'OPD_ANC', isOpen: false })
      .expect(200);

    const state = await request(app)
      .get(`/api/queue?facilityId=${FACILITY}`)
      .set(as('staff'))
      .expect(200);
    expect(state.body.counters.some((counter) => counter.isOpen === false)).toBe(true);
  });

  it('serves a footfall report with hourly buckets', async () => {
    const response = await request(app)
      .get(`/api/footfall?facilityId=${FACILITY}`)
      .set(as('staff'))
      .expect(200);
    expect(response.body).toHaveProperty('hourly');
    expect(response.body.hourly.length).toBeGreaterThan(0);
  });
});

describe('alerts', () => {
  it('lists and acknowledges an alert', async () => {
    const alerts = await repository.listAlerts({ limit: 1, offset: 0 });
    if (!alerts.items.length) {
      // Demo data may legitimately have no open alert; create one via a
      // threshold breach instead of silently skipping.
      expect(alerts.items).toEqual([]);
      return;
    }

    const response = await request(app)
      .post(`/api/alerts/${alerts.items[0].id}/acknowledge`)
      .set(as('chc'))
      .expect(200);
    expect(response.body.acknowledged).toBe(true);
  });
});

describe('reference data', () => {
  it('lists facilities and filters by type', async () => {
    const all = await request(app).get('/api/facilities?limit=50').expect(200);
    expect(all.body.items.length).toBeGreaterThanOrEqual(11);

    const phcs = await request(app).get('/api/facilities?type=PHC&limit=50').expect(200);
    expect(phcs.body.items.every((facility) => facility.type === 'PHC')).toBe(true);
  });

  it('reads one facility and 404s on an unknown one', async () => {
    await request(app).get(`/api/facilities/${FACILITY}`).expect(200);
    await request(app).get('/api/facilities/FAC-NOPE').expect(404);
  });

  it('filters medicines by category and search term', async () => {
    const response = await request(app).get('/api/medicines?q=ors').expect(200);
    expect(response.body.items.length).toBeGreaterThan(0);
    expect(response.body.items[0].name.toLowerCase()).toContain('or');
  });

  it('lists doctors with reliability attached', async () => {
    const response = await request(app)
      .get(`/api/doctors?facilityId=${FACILITY}`)
      .set(as('staff'))
      .expect(200);
    expect(response.body.items.length).toBeGreaterThan(0);
    expect(response.body.items[0]).toHaveProperty('reliabilityPercent');
  });
});

describe('AI confirm happy paths', () => {
  it('records a confirmed stock adjustment', async () => {
    const response = await request(app)
      .post('/api/ai/confirm')
      .set(as('staff'))
      .send({
        intent: 'STOCK_ADJUSTMENT',
        medicineId: 'MED-ORS',
        quantity: 25,
        reason: 'RECEIPT',
        originalText: 'ors 25 aaye',
      })
      .expect(201);
    expect(response.body.ok).toBe(true);
    expect(response.body.intent).toBe('STOCK_ADJUSTMENT');
  });

  it('rejects an unknown intent without writing anything', async () => {
    const response = await request(app)
      .post('/api/ai/confirm')
      .set(as('staff'))
      .send({ intent: 'UNKNOWN' })
      .expect(200);
    expect(response.body.ok).toBe(false);
    expect(response.body.reason).toBe('UNKNOWN_INTENT');
  });
});
