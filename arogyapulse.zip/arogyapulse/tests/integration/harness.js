/**
 * Shared harness for the HTTP integration suite.
 *
 * Boots the real Express app against a seeded in-memory repository. Nothing is
 * mocked except the Gemini client, so every middleware, validator, RBAC rule
 * and service in the request path is the one that ships.
 */

import { createApp, seedIfEmpty } from '../../src/server.js';
import { createRepository, setRepository } from '../../src/repositories/index.js';
import { resetGemini } from '../../src/services/geminiService.js';

/** Demo principals used across the suite. */
export const ACCOUNTS = Object.freeze({
  staff: { role: 'facility_staff', facilityId: 'FAC-PHC-RAHATA', displayName: 'ANM Sunita' },
  chc: { role: 'chc_admin', facilityId: 'FAC-CHC-SANGAMNER', displayName: 'CHC Admin' },
  district: { role: 'district_officer', facilityId: null, displayName: 'District Officer' },
  public: { role: 'public', facilityId: null, displayName: 'Public User' },
});

export const FACILITY = 'FAC-PHC-RAHATA';
export const OTHER_FACILITY = 'FAC-PHC-PARNER';

/**
 * Boot an app with a freshly seeded repository.
 *
 * @param {object} [options]
 * @returns {Promise<{app: import('express').Express, repository: object, agent: Function}>}
 */
export async function bootHarness(options = {}) {
  const repository = await createRepository({ kind: 'memory' });
  setRepository(repository);
  await seedIfEmpty(repository, options.days ?? 21);

  const app = await createApp({ repository, enableRateLimit: false });
  return { app, repository };
}

/**
 * Issue a demo session cookie for one of the demo accounts.
 *
 * @param {import('express').Express} app
 * @param {keyof typeof ACCOUNTS} name
 * @returns {Promise<string>} A `Cookie` header value.
 */
export async function signIn(app, name) {
  const request = (await import('supertest')).default;
  const response = await request(app).post('/api/auth/login').send(ACCOUNTS[name]).expect(200);
  const raw = response.headers['set-cookie'];
  const cookies = Array.isArray(raw) ? raw : [raw];
  return cookies.map((cookie) => cookie.split(';')[0]).join('; ');
}

/**
 * Reset mutable module state between suites.
 *
 * @returns {void}
 */
export function resetAi() {
  resetGemini();
}
